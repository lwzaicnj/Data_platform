<?php

header('Location:cas_index.php?language=zh&country=CN&variant=CN');
