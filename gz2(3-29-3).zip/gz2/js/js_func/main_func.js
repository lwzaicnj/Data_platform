$(function(){
	//注销操作
  	$('#logout').click(function(){
		window.location.href = '../../cas_index.php?logout=1';
  	});
});

//初始化表格（chart.js）
function new_chart(ctx,type){
	var ins_chart = new Chart(ctx, {
		type: type,
		data:{
			labels:[],
			datasets:[{
			},{},{}],
		},
		options:{
			 scales: {
	            yAxes: [{
	                ticks: {
	                	// beginAtZero:true,
	                	// max:100,
	                    // 显示两位百分比
	                    callback: function(value, index, values) {
	                        return value.toFixed(2) + "%";
	                    }
	                }
	            }]
	        }
		}

	});

	return ins_chart;
}

//传递2017-11，返回最近的三个月份 9 10 11
function get_three_month(month){
	var time_arr = new Array();
	time_arr[0] = month.substr(5)-0;
	time_arr[1]= time_arr[0]-1==0?12:time_arr[0]-1;
	time_arr[2] = time_arr[0]-2==0?12:(time_arr[0]-2==-1?11:time_arr[0]-2);
	return time_arr;	
}


//去除最后一位（百分号）
function trim_end(arg){
	if(arg)
		return arg.substr(0, arg.length - 1);
}


//获取下标
function get_index(value,arr){

	for(var i in arr){

		if(arr[i] == value) return i;
	}
}

//颜色区分函数
function get_color(value,bol){
	if(bol==1)
		return '<i class="icon-flag icon-2x" style="color:green;white-space:nowrap;"><span style="color:#666679">'+value+'</span></i>';
	else if(bol==2)
		return '<i class="icon-flag icon-2x" style="color:#00f;white-space:nowrap;"><span style="color:#666679">'+value+'</span></i>';
	else
		return '<i class="icon-flag icon-2x" style="color:red;white-space:nowrap;"><span style="color:#666679">'+value+'</span></i>';
}


//图表参数
function options(){
	return {
  		  	tooltip: {
		        trigger: 'axis',
		        axisPointer: {
		            type: 'cross',
		            crossStyle: {
		            	color: '#999'
		            }
		        }
		    },
		    toolbox: {
		        feature: {
		            // dataView: {show: true, readOnly: false},
		            // magicType: {show: true, type: ['line', 'bar']},
		            // restore: {show: true},
		            // saveAsImage: {show: true}
		        }
		    },
		    legend: {
		        data:['柱形','折线']
		    },
		    series:[
		    	{
		            name:'柱形',
		            type:'bar',
		            barWidth : 50,//柱图宽度
		        },
		        {
		            name:'折线',
		            type:'line',
		        },
		    ],
		    xAxis: [ ],
		    yAxis: [
		        {
		            type: 'value',
		            name: '百分比',
		            // min: 0,
		            // max: 100,
		            // interval: 10,
		            axisLabel: {
		                formatter: '{value} %'
		            }
		        },
		    ],
		   
		};
}


//对应比例缩放
function get_width(container,div) {
	var div = arguments[1] ? arguments[1] : 0;
	container.style.width = (parseInt(window.innerWidth)*0.7)+'px';
	if(div!=0){
		container.style.width = (parseInt(window.innerWidth)*div)+'px';
	}
}

//求数组最大最小值
function get_m(arr,m){
	var new_a = [];
	for(var i=0;i<arr.length;i++){
		if(arr[i]){
			new_a.push(arr[i]);
		}
	}
	if(m){
		return Math.max.apply(null, new_a);
	}else return Math.min.apply(null, new_a);
}

//返回select的内容数组
function get_select_arr(id){
	var op_arr = new Array();
	$(""+id+" option").each(function(){    
          var txt = $(this).val();   //获取option值   
          if(txt!=''){  
              op_arr.push(txt); 
          }  
    });

    return op_arr;
}

//留下自己片区的分部
// function get_fb(all,part){
// 	var fb_arr = new Array();
// 	$(all).each(function(index,element){
// 		if(element['所属片区']==part){
// 			fb_arr.push(element);
// 		}
// 	});
// 	return fb_arr;
// }
