function p(s) {
    return s < 10 ? '0' + s: s;
}
//获取昨天的日期
function get_time(){
    var myDate = new Date();
    myDate.setTime(myDate.getTime()-24*60*60*1000);
    var year=myDate.getFullYear();
    var month=myDate.getMonth()+1;
    var date=myDate.getDate(); 
    return year+'-'+p(month)+"-"+p(date);
}

//去除万
function trim_w(x){
	if(x)
   	  return x.substring(0,x.length-1);
   	else
   		return x;
}

//转成万
function turn_w(x){
	if(x)
		return (parseInt(x)/10000).toFixed(2)+'万';
}


function ajaxcan(url,da,type,efun,fun,bfun,cfun){
	var bfun = arguments[5] ? arguments[5] : 0;
	var cfun = arguments[6] ? arguments[6] : 0;
	if(!da)da={};if(!type)type='POST';
	if(typeof(fun)!='function')fun=function(){};
	if(typeof(efun)!='function')efun=function(){};
	if(typeof(bfun)!='function')bfun=function(){$("#icon").addClass("fa fa-circle-o-notch fa-spin fa-3x");};
	if(typeof(cfun)!='function')cfun=function(){};
	var ajaxcan={
		type:type,
		data:da,url:url,
		beforeSend:bfun,
	    complete:cfun,
		error:efun,
		success:fun,
	};
	$.ajax(ajaxcan);
}
