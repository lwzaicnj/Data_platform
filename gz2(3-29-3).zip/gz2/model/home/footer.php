<footer id="footer" style="margin:0;white-space:nowrap;">
    <!-- .footer start -->
    <!-- ================ -->
    <div class="footer">
        <div class="container" style="padding:0;" >
                <div class="col-sm-6 col-md-2" style="margin-left: 20%;">
                    <div class="footer-content" style="margin-top: -10px;">
                        <div class="logo-footer"><img id="logo-footer" src="../../images/logo_red_footer.png" alt=""></div>
                        <nav>
                            <ul class="list-icons" style="margin-top: -10px;white-space:normal;">
                                    <li >广州数据平台是顺丰广州区开发的一个大数据分析平台，用于分析各个分点部各项数据</li></br>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-sm-6 col-md-2">
                    <div class="footer-content">
                        <h2>联系方式</h2>
                        <nav>
                            <ul class="list-icons">
                                    <li><i class="fa fa-map-marker pr-10"></i> 广州顺丰运营部高磊</li></br>
                                    <li><i class="fa fa-phone pr-10"></i>17728161004</li></br>
                                    <!-- <li><i class="fa fa-fax pr-10"></i> +00 1234567891 </li> -->
                                    <li><i class="fa fa-envelope-o pr-10"></i> gaolei21@sf-express.com</li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-sm-6 col-md-2">
                    <div class="footer-content">
                        <h2>相关链接</h2>
                        <nav>
                            <ul class="nav nav-pills">
                                <li><a href="http://bie.sf-express.com" target="_blank">多棱镜大数据平台</a></li>
                                <li><a href="http://elog-sops.sf-express.com/" target="_blank">业务决策支持平台</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
                </div>
            </div>
            <div class="space-bottom hidden-lg hidden-xs"></div>
        </div>
    </div>
    <!-- .footer end -->

    <!-- .subfooter start -->
    <!-- ================ -->
    <div class="subfooter" style="margin-top: -20px;height: 20px;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p style="padding: 0; white-space:nowrap;">Copyright &copy; 2017.All rights reserved.GuangZhou IT <a href="#" target="_blank" title="顺丰广州IT">顺丰广州IT</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- .subfooter end -->

</footer>