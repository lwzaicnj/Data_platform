<?php 


$count = rand(1555,122200000);
$arr_to_js = [
    "count" => $count,
    "bar" => "foo",
];

echo json_encode($arr_to_js);