<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>广州数据平台</title>

<!--首页引用文件-->
<?php
date_default_timezone_set('Asia/Shanghai');
include_once '../../includes/header_inner.php';
include_once '../../includes/public_inc_func.php';
include_once '../../includes/public_db_func.php';
cookie_location('../../cas_index.php');//cookie失效

$unique_id = $_COOKIE['unique_id'];
$user_info = get_user($unique_id);//获取所属片区

?>
<script type="text/javascript" src="../../js/animateBackground-plugin.js"></script>
<script type="text/javascript" src="../../js/home/home.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    //注销操作
    $('#logout').click(function(){
        window.location.href = '../../cas_index.php?logout=1';
    });
    time = get_time();//获取昨天时间
    userinfo = <?php echo html_trim(json_encode($user_info));?>;
	
    //get_ori_data();
   
    option_c1 = {
            color:['#ff8200','#2d957b'], //'#c25652','#3ff',
            tooltip: {
                trigger: 'item',
                formatter: "{c}万"
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                data: [{name:'件量',textStyle:{color:"#fff"}},{name:'收入',textStyle:{color:"#fff"}}]
            },
            calculable: true,
            series: [
                {
                    name: '件量',
                    type:'funnel',
                    width: '60%',
                    height: '45%',
                    left: '20%',
                    top: '0%',
                    label: {
                        normal: {
                            position: 'right',
                            // formatter: '达成率：{c}%',
                        }
                    },
                    data:[
                        // {value: 10, name: '日'},
                        // {value: 30, name: '月'},
                        // {value: 60, name: '年'},
                    ]
                },
                {
                    name: '收入',
                    type:'funnel',
                    width: '60%',
                    height: '45%',
                    left: '20%',
                    top: '45%',
                    bottom : '1%',
                    sort: 'ascending',
                    label: {
                        normal: {
                            position: 'right',
                            // formatter: '达成率：{c}%',
                        }
                    },
                    data:[]
                }
            ]
        };

    chart_c1 = document.getElementById("right_c1");
    echart_c1 = echarts.init(chart_c1);

    //圆环内柱状图
    //柱形图
    chart_z1 = document.getElementById("middle_z1");
    echart_z1 = echarts.init(chart_z1);
    option_z1 = {
            color: ['#3ff','#088'],
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '10%',
                containLabel: true
            },
            // legend:{
            //     x:'center',y:'bottom',
            //     data:[{name:'收入达成率',textStyle:{color:"#fff"}},{name:'件量达成率',textStyle:{color:"#fff"}}]
            // },
            xAxis : [
                {   
                    axisLine:{
                        lineStyle:{
                            color:'#fff',
                        }
                    },
                    axisTick:{
                        show:false
                    },
                    type : 'category',
                    data : ['日', '月', '年'],
                    splitLine:{show: false},
                }
            ],
            yAxis : [
                {
                     axisLine:{
                        lineStyle:{
                            color:'#fff',
                        }
                    },
                    axisLabel: {  
                      show: true,    
                      formatter: '{value}%'  
                    },
                    type : 'value',
                    axisTick:{
                        show:false
                    },
                    splitLine:{show: false},
                }
            ],
            series : [
                {
                    name:'收入达成率',
                    type:'bar',
                    // barWidth: '100%',
                    data: [ ]
                },{
                    name:'件量达成率',
                    type:'bar',
                    // barWidth: '100%',
                    data: [ 
                            // {value:10,itemStyle:{normal:{color:'#088'}}}, 
                            // {value:52,itemStyle:{normal:{color:'#088'}}}, 
                            // {value:200,itemStyle:{normal:{color:'#088'}}}, 
                        ]
                }
            ]
        };


    $("#model_select option:first").prop("selected", 'selected'); 
    r1_data = new Array();
    r1_row1 = new Array();
    r1_row2 = new Array();
    r1_row3 = new Array();
    r1_row1['时间'] = "日";
    r1_row2['时间'] = "月";
    r1_row3['时间'] = "年";
  
    ajaxcan("../../table/shichang/daily_c2.php",{"time":time,'pq':userinfo[3]},"GET",0,function(data){
           // alert(data);
            var e_data = eval("("+data+")");
            var str_data = JSON.stringify(e_data); //转为字符串
            localStorage.setItem("c1_data",str_data);//收入和件量daily_c2
            
            option_c1.series[0].data = [{value: trim_w(turn_w(e_data['当天件量'])), name:e_data['当天件量达成'],itemStyle:{normal:{color:'#ff8200'}}},{value: trim_w(e_data['当月件量']), name: e_data['当月件量达成'],itemStyle:{normal:{color:'#ff8200'}}},{value: trim_w(e_data['当年件量']), name: e_data['当年件量达成'],itemStyle:{normal:{color:'#ff8200'}}}];
            option_c1.series[1].data = [{value: trim_w(turn_w(e_data['当天折后收入'])), name: e_data['当天收入达成'],itemStyle:{normal:{color:'#2d957b'}}},{value: trim_w(e_data['当月折后收入']), name: e_data['当月收入达成'],itemStyle:{normal:{color:'#2d957b'}}},{value: trim_w(e_data['当年折后收入']), name: e_data['当年收入达成'],itemStyle:{normal:{color:'#2d957b'}}}];

            //option_c1.series[0].label.normal.formatter = "达成率：{b}";
            //option_c1.series[1].label.normal.formatter = "达成率：{b}";
	    
  	    option_c1.series[0].label.normal.formatter = function(data){
                    //data['dataIndex'] 下标
                    //data['name'] ：上面的 series里面的name
                    if(data['dataIndex']==0)
                        return "日达成:"+data['name'];
                    else if(data['dataIndex']==1)
                        return "月达成:"+data['name'];
                    else if(data['dataIndex']==2)
                        return "年达成:"+data['name'];
            };

            option_c1.series[1].label.normal.formatter = function(data){
                    if(data['dataIndex']==0)
                        return "日达成:"+data['name'];
                    else if(data['dataIndex']==1)
                        return "月达成:"+data['name'];
                    else if(data['dataIndex']==2)
                        return "年达成:"+data['name'];
            };

            echart_c1.setOption(option_c1);

            //圆环内柱形图
            option_z1.series[0].data.push({value:trim_w(e_data['当天收入达成']),itemStyle:{normal:{color:'#3ff'}}});
            option_z1.series[0].data.push({value:trim_w(e_data['当月收入达成']),itemStyle:{normal:{color:'#3ff'}}});
            option_z1.series[0].data.push({value:trim_w(e_data['当年收入达成']),itemStyle:{normal:{color:'#3ff'}}});
            option_z1.series[1].data.push({value:trim_w(e_data['当天件量达成']),itemStyle:{normal:{color:'#088'}}});
            option_z1.series[1].data.push({value:trim_w(e_data['当月件量达成']),itemStyle:{normal:{color:'#088'}}});
            option_z1.series[1].data.push({value:trim_w(e_data['当年件量达成']),itemStyle:{normal:{color:'#088'}}});
            echart_z1.setOption(option_z1);
            
            setInterval('getdata()', 3000);//每隔3秒执行一次 

            $("#icon").removeClass("fa fa-circle-o-notch fa-spin fa-3x");
       });

    //折线图
    option_r2 = {
            color: ['#6a0','#0f0','#f00'],
            tooltip : {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
            legend: {
                data:[{name:'近7日收入',textStyle:{color:"#fff"}},{name:'上月收入',textStyle:{color:"#fff"}},{name:'上年收入',textStyle:{color:"#fff"}}]
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    //坐标颜色
                     axisLine:{
                        lineStyle:{
                            color:'#fff',
                        }
                    },
                    boundaryGap : false,
                    data : []
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    name:'万',
                     axisLine:{
                        lineStyle:{
                            color:'#fff',
                        }
                    },
                    splitLine:{show: false},
                    //隐藏坐标刻度
                    axisTick:{
                        show:false
                    },
                }
            ],
            series : [
                {
                    name:'近7日收入',
                    type:'line',
                    data:[]
                }, {
                    name:'上月收入',
                    type:'line',
                    data:[]
                }, {
                    name:'上年收入',
                    type:'line',
                    data:[]
                },

              
            ]
        };
    chart_r2 = document.getElementById("right_c2");
    echart_r2 = echarts.init(chart_r2);

    //仅仅返回横坐标，
    ajaxcan("../../table/shichang/daily_week.php",{"time":time},"GET",0,function(data){
            var e_data = eval("("+data+")");
            for(var i in e_data){
                option_r2.xAxis[0].data.push(i);
            }
            echart_r2.setOption(option_r2);
    });

    ajaxcan("../../table/shichang/daily_t4.php",{"time":time,'pq':userinfo[3]},"GET",0,function(data){
            // alert(data);     
            var e_data = eval("("+data+")");
            var str_data = JSON.stringify(e_data); //转为字符串
            localStorage.setItem("t4_data",str_data);//月结和散单数据daily_t4
       });
    ajaxcan("../../table/shichang/daily_t6.php",{"time":time,'pq':userinfo[3]},"GET",0,function(data){
            // alert(data);     
            var e_data = eval("("+data+")");
            var str_data = JSON.stringify(e_data); //转为字符串
            localStorage.setItem("t6_data",str_data);//广州区的业务数据（总重货等）daily_t6 含七日数据
            //加载大盘七日数据
            var index = 0;
            option_r2.series[0].data=[e_data[index]['d0'],e_data[index]['d1'],e_data[index]['d2'],e_data[index]['d3'],e_data[index]['d4'],e_data[index]['d5'],trim_w(e_data[index]['收入'])];
            option_r2.series[1].data=[e_data[index]['dm0'],e_data[index]['dm1'],e_data[index]['dm2'],e_data[index]['dm3'],e_data[index]['dm4'],e_data[index]['dm5'],e_data[index]['dm6']];
            option_r2.series[2].data=[e_data[index]['dy0'],e_data[index]['dy1'],e_data[index]['dy2'],e_data[index]['dy3'],e_data[index]['dy4'],e_data[index]['dy5'],e_data[index]['dy6']];
            echart_r2.setOption(option_r2);

            $('.shouru1').html('收入：'+e_data[index]['收入']);
            $('.shouru2').html('收入：'+e_data[index]['d5']+'万');
            $('.shouru3').html('收入：'+e_data[index]['d4']+'万');
            $('.shouru4').html('收入：'+e_data[index]['d3']+'万');
            $('.shouru5').html('收入：'+e_data[index]['d2']+'万');
            $('.shouru6').html('收入：'+e_data[index]['d1']+'万');
            $('.shouru7').html('收入：'+e_data[index]['d0']+'万');

            $('.piaoshu1').html('票数：'+e_data[index]['日件']);
            $('.piaoshu2').html('票数：'+e_data[index]['dj5']+'万');
            $('.piaoshu3').html('票数：'+e_data[index]['dj4']+'万');
            $('.piaoshu4').html('票数：'+e_data[index]['dj3']+'万');
            $('.piaoshu5').html('票数：'+e_data[index]['dj2']+'万');
            $('.piaoshu6').html('票数：'+e_data[index]['dj1']+'万');
            $('.piaoshu7').html('票数：'+e_data[index]['dj0']+'万');

       });
    
    //模块切换
    $('#model_select').change(function(){
        r1_data = new Array();
        r1_row1 = new Array();
        r1_row2 = new Array();
        r1_row3 = new Array();
        r1_row1['时间'] = "日";
        r1_row2['时间'] = "月";
        r1_row3['时间'] = "年";
        var model = $('#model_select option:selected').text();
        //前十后十
        ajaxcan("../../table/shichang/daily_t3_top.php",{"time":time,'model':model,'pq':userinfo[3]},"GET",0,function(data){
                var top_data = eval("("+data+")");
                var r3_data = new Array();
                var r3_row1 = new Array();
                var r3_row2 = new Array();
                var r3_row3 = new Array();
                var r3_row4 = new Array();
                var r3_row5 = new Array();
                r3_row1['分部1'] = top_data[0]['分部'];
                r3_row1['分部2'] = top_data[5]['分部'];
                r3_row2['分部1'] = top_data[1]['分部'];
                r3_row2['分部2'] = top_data[6]['分部'];
                r3_row3['分部1'] = top_data[2]['分部'];
                r3_row3['分部2'] = top_data[7]['分部'];
                r3_row4['分部1'] = top_data[3]['分部'];
                r3_row4['分部2'] = top_data[8]['分部'];
                r3_row5['分部1'] = top_data[4]['分部'];
                r3_row5['分部2'] = top_data[9]['分部'];
                
                r3_data.push(r3_row1);
                r3_data.push(r3_row2);
                r3_data.push(r3_row3);
                r3_data.push(r3_row4);
                r3_data.push(r3_row5);
                
                $('#tablet1').bootstrapTable('load',r3_data);

                var r3_data1 = new Array();
                var r3_row11 = new Array();
                var r3_row22 = new Array();
                var r3_row33 = new Array();
                var r3_row44 = new Array();
                var r3_row55 = new Array();
                var l = top_data.length;
                r3_row11['分部1'] = top_data[l-10]['分部'];
                r3_row11['分部2'] = top_data[l-5]['分部'];
                r3_row22['分部1'] = top_data[l-9]['分部'];
                r3_row22['分部2'] = top_data[l-4]['分部'];
                r3_row33['分部1'] = top_data[l-8]['分部'];
                r3_row33['分部2'] = top_data[l-3]['分部'];
                r3_row44['分部1'] = top_data[l-7]['分部'];
                r3_row44['分部2'] = top_data[l-2]['分部'];
                r3_row55['分部1'] = top_data[l-6]['分部'];
                r3_row55['分部2'] = top_data[l-1]['分部'];
                
                r3_data1.push(r3_row11);
                r3_data1.push(r3_row22);
                r3_data1.push(r3_row33);
                r3_data1.push(r3_row44);
                r3_data1.push(r3_row55);

                $('#tablet2').bootstrapTable('load',r3_data1);
        });
        if(model=='月结' || model=='散单'){
            sl_index = 1;//判断大区或片区
            if(userinfo[3]=='广州区') sl_index = 0; 
	    var str_data = localStorage.getItem("t4_data");
            var e_data = JSON.parse(str_data);//转回数组      
            //没有目标值，故达成均为空
            if(model=='月结'){
		r1_row1['收入'] = e_data[sl_index]['月结入'] || 0;
                r1_row1['收入达成'] = '-';
                r1_row1['件量'] = e_data[sl_index]['月结件'] || 0;
                r1_row1['件量达成'] = '-';
                r1_row2['收入'] = e_data[sl_index]['月结月入'] ||0;
                r1_row2['收入达成'] = '-';
                r1_row2['件量'] = e_data[sl_index]['月结月件']|| 0;
                r1_row2['件量达成'] = '-';
                r1_row3['收入'] = e_data[sl_index]['月结年入']||0; 
                r1_row3['收入达成'] ='-';
                r1_row3['件量'] = e_data[sl_index]['月结年件']||0;
                r1_row3['件量达成'] = '-'; 		

                //七日数据
                option_r2.series[0].data=[e_data[sl_index]['yd0'],e_data[sl_index]['yd1'],e_data[sl_index]['yd2'],e_data[sl_index]['yd3'],e_data[sl_index]['yd4'],e_data[sl_index]['yd5'],trim_w(e_data[sl_index]['月结入'])];
                option_r2.series[1].data=[e_data[sl_index]['ydm0'],e_data[sl_index]['ydm1'],e_data[sl_index]['ydm2'],e_data[sl_index]['ydm3'],e_data[sl_index]['ydm4'],e_data[sl_index]['ydm5'],e_data[sl_index]['ydm6']];
                option_r2.series[2].data=[e_data[sl_index]['ydy0'],e_data[sl_index]['ydy1'],e_data[sl_index]['ydy2'],e_data[sl_index]['ydy3'],e_data[sl_index]['ydy4'],e_data[sl_index]['ydy5'],e_data[sl_index]['ydy6']];
                echart_r2.setOption(option_r2);

                $('.shouru1').html('收入：'+e_data[sl_index]['月结入']);
                $('.shouru2').html('收入：'+e_data[sl_index]['yd5'])+'万';
                $('.shouru3').html('收入：'+e_data[sl_index]['yd4'])+'万';
                $('.shouru4').html('收入：'+e_data[sl_index]['yd3'])+'万';
                $('.shouru5').html('收入：'+e_data[sl_index]['yd2'])+'万';
                $('.shouru6').html('收入：'+e_data[sl_index]['yd1'])+'万';
                $('.shouru7').html('收入：'+e_data[sl_index]['yd0'])+'万';

                // alert(e_data[0]['ydj5']);
                $('.piaoshu1').html('票数：'+e_data[sl_index]['月结件']);
                $('.piaoshu2').html('票数：'+e_data[sl_index]['ydj5']+'万');
                $('.piaoshu3').html('票数：'+e_data[sl_index]['ydj4']+'万');
                $('.piaoshu4').html('票数：'+e_data[sl_index]['ydj3']+'万');
                $('.piaoshu5').html('票数：'+e_data[sl_index]['ydj2']+'万');
                $('.piaoshu6').html('票数：'+e_data[sl_index]['ydj1']+'万');
                $('.piaoshu7').html('票数：'+e_data[sl_index]['ydj0']+'万'); 
            }else{
		r1_row1['收入'] = e_data[sl_index]['散单入']||0;
                r1_row1['收入达成'] = '-';
                r1_row1['件量'] = e_data[sl_index]['散单件']||0;
                r1_row1['件量达成'] = '-';
                r1_row2['收入'] = e_data[sl_index]['散单月入'] || 0;
                r1_row2['收入达成'] = '-';
                r1_row2['件量'] = e_data[sl_index]['散单月件']||0;
                r1_row2['件量达成'] = '-';
                r1_row3['收入'] = e_data[sl_index]['散单年入']||0; 
                r1_row3['收入达成'] ='-';
                r1_row3['件量'] = e_data[sl_index]['散单年件']||0;
                r1_row3['件量达成'] = '-';
		

                option_r2.series[0].data=[e_data[sl_index]['d0'],e_data[sl_index]['d1'],e_data[sl_index]['d2'],e_data[sl_index]['d3'],e_data[sl_index]['d4'],e_data[sl_index]['d5'],trim_w(e_data[sl_index]['散单入'])];
                option_r2.series[1].data=[e_data[sl_index]['dm0'],e_data[sl_index]['dm1'],e_data[sl_index]['dm2'],e_data[sl_index]['dm3'],e_data[sl_index]['dm4'],e_data[sl_index]['dm5'],e_data[sl_index]['dm6']];
                option_r2.series[2].data=[e_data[sl_index]['dy0'],e_data[sl_index]['dy1'],e_data[sl_index]['dy2'],e_data[sl_index]['dy3'],e_data[sl_index]['dy4'],e_data[sl_index]['dy5'],e_data[sl_index]['dy6']];
                echart_r2.setOption(option_r2);

                $('.shouru1').html('收入：'+e_data[sl_index]['散单入']);
                $('.shouru2').html('收入：'+e_data[sl_index]['d5']+'万');
                $('.shouru3').html('收入：'+e_data[sl_index]['d4']+'万');
                $('.shouru4').html('收入：'+e_data[sl_index]['d3']+'万');
                $('.shouru5').html('收入：'+e_data[sl_index]['d2']+'万');
                $('.shouru6').html('收入：'+e_data[sl_index]['d1']+'万');
                $('.shouru7').html('收入：'+e_data[sl_index]['d0']+'万');

                $('.piaoshu1').html('票数：'+e_data[sl_index]['散单件']);
                $('.piaoshu2').html('票数：'+e_data[sl_index]['dj5']+'万');
                $('.piaoshu3').html('票数：'+e_data[sl_index]['dj4']+'万');
                $('.piaoshu4').html('票数：'+e_data[sl_index]['dj3']+'万');
                $('.piaoshu5').html('票数：'+e_data[sl_index]['dj2']+'万');
                $('.piaoshu6').html('票数：'+e_data[sl_index]['dj1']+'万');
                $('.piaoshu7').html('票数：'+e_data[sl_index]['dj0']+'万');
            }

        }else{
            var e_data = new Array();
            var str_data = localStorage.getItem("t6_data");
            e_data = JSON.parse(str_data);
            index = 0;
            if(model=='大区/片区'){
                //非月结和散单的下标
                var str_data = localStorage.getItem("c1_data");
                var e_data1 = JSON.parse(str_data);
                r1_row1['收入'] =  turn_w(e_data1['当天折后收入']) || 0;
                r1_row1['收入达成'] = e_data1['当天收入达成'];
                r1_row1['件量'] = turn_w(e_data1['当天件量'])|| 0;
                r1_row1['件量达成'] = e_data1['当天件量达成'];
                r1_row2['收入'] = e_data1['当月折后收入']|| 0;
                r1_row2['收入达成'] = e_data1['当月收入达成'];
                r1_row2['件量'] = e_data1['当月件量']|| 0;
                r1_row2['件量达成'] = e_data1['当月件量达成'];
                r1_row3['收入'] = e_data1['当年折后收入']|| 0;
                r1_row3['收入达成'] = e_data1['当年收入达成'];
                r1_row3['件量'] = e_data1['当年件量']|| 0;
                r1_row3['件量达成'] = e_data1['当年件量达成'];

            }else if(model=='重货快运' || model=='物流普运' || model=='国际件' || model=='保价' || model=='代收服务费'){
                index = 1;
                if(model=='物流普运') index = 2;
                else if(model=='国际件') index = 3;
                else if(model=='保价') index = 4;
                else if(model=='代收服务费') index = 5;
                r1_row1['收入'] =  e_data[index]['收入'] || 0;//折后
                r1_row1['收入达成'] = e_data[index]['日入达成'];
                r1_row1['件量'] = e_data[index]['日件'] || 0;
                r1_row1['件量达成'] = '-';
                r1_row2['收入'] = e_data[index]['月累计']|| 0;
                r1_row2['收入达成'] = e_data[index]['月入达成'];
                r1_row2['件量'] = e_data[index]['月件']|| 0;
                r1_row2['件量达成'] = '-';
                r1_row3['收入'] = e_data[index]['年累计']|| 0;
                r1_row3['收入达成'] = '-';
                r1_row3['件量'] = e_data[index]['年件'] || 0;
                r1_row3['件量达成'] = '-';

            }
            //t6_data的index
            option_r2.series[0].data=[e_data[index]['d0'],e_data[index]['d1'],e_data[index]['d2'],e_data[index]['d3'],e_data[index]['d4'],e_data[index]['d5'],trim_w(e_data[index]['收入'])];
            option_r2.series[1].data=[e_data[index]['dm0'],e_data[index]['dm1'],e_data[index]['dm2'],e_data[index]['dm3'],e_data[index]['dm4'],e_data[index]['dm5'],e_data[index]['dm6']];
            option_r2.series[2].data=[e_data[index]['dy0'],e_data[index]['dy1'],e_data[index]['dy2'],e_data[index]['dy3'],e_data[index]['dy4'],e_data[index]['dy5'],e_data[index]['dy6']];;
            echart_r2.setOption(option_r2);

            $('.shouru1').html('收入：'+e_data[index]['收入']);
            $('.shouru2').html('收入：'+e_data[index]['d5']+'万');
            $('.shouru3').html('收入：'+e_data[index]['d4']+'万');
            $('.shouru4').html('收入：'+e_data[index]['d3']+'万');
            $('.shouru5').html('收入：'+e_data[index]['d2']+'万');
            $('.shouru6').html('收入：'+e_data[index]['d1']+'万');
            $('.shouru7').html('收入：'+e_data[index]['d0']+'万');

            $('.piaoshu1').html('票数：'+e_data[index]['日件']);
            $('.piaoshu2').html('票数：'+e_data[index]['dj5']+'万');
            $('.piaoshu3').html('票数：'+e_data[index]['dj4']+'万');
            $('.piaoshu4').html('票数：'+e_data[index]['dj3']+'万');
            $('.piaoshu5').html('票数：'+e_data[index]['dj2']+'万');
            $('.piaoshu6').html('票数：'+e_data[index]['dj1']+'万');
            $('.piaoshu7').html('票数：'+e_data[index]['dj0']+'万');
        }

        // alert(r1_row1['件量']);
        //图1
        option_c1.series[0].data = [{value: trim_w(r1_row1['件量']), name:r1_row1['件量达成'],itemStyle:{normal:{color:'#ff8200'}}},{value: trim_w(r1_row2['件量']), name: r1_row2['件量达成'],itemStyle:{normal:{color:'#ff8200'}}},{value: trim_w(r1_row3['件量']), name: r1_row3['件量达成'],itemStyle:{normal:{color:'#ff8200'}}}];
        option_c1.series[1].data = [{value: trim_w(r1_row1['收入']), name: r1_row1['收入达成'],itemStyle:{normal:{color:'#2d957b'}}},{value: trim_w(r1_row2['收入']), name: r1_row2['收入达成'],itemStyle:{normal:{color:'#2d957b'}}},{value: trim_w(r1_row3['收入']), name: r1_row3['收入达成'],itemStyle:{normal:{color:'#2d957b'}}}];

        //option_c1.series[0].label.normal.formatter = "达成率：{b}";
        //option_c1.series[1].label.normal.formatter = "达成率：{b}";
	option_c1.series[0].label.normal.formatter = function(data){
                    //data['dataIndex'] 下标
                    //data['name'] ：上面的 series里面的name
                    if(data['dataIndex']==0)
                        return "日达成:"+data['name'];
                    else if(data['dataIndex']==1)
                        return "月达成:"+data['name'];
                    else if(data['dataIndex']==2)
                        return "年达成:"+data['name'];
            };

        option_c1.series[1].label.normal.formatter = function(data){
                    if(data['dataIndex']==0)
                        return "日达成:"+data['name'];
                    else if(data['dataIndex']==1)
                        return "月达成:"+data['name'];
                    else if(data['dataIndex']==2)
                        return "年达成:"+data['name'];
            };	

        echart_c1.setOption(option_c1);

        $("#icon").removeClass("fa fa-circle-o-notch fa-spin fa-3x");

    });

    //top10
    $('#tablet1').bootstrapTable({
        cache: false,
        columns: [
                    {
                        field: '分部1',
                        title:'1-5',
                        align: 'center',
                        valign: 'middle',
                        // visible: false,
                    },{
                        field: '分部2',
                        title:'5-10',
                        align: 'center',
                        valign: 'middle',
                         // visible: false,
                    }
                ],
        onClickRow: function(row, element){
            $('.success').removeClass('success');//去除之前样式
            $(element).addClass('success');//添加当前选中的
            $(".success").css("background-color");//保存之前的颜色
        },
    });

    $('#tablet2').bootstrapTable({
        cache: false,
        columns: [
                    {
                        field: '分部1',
                        title:'1-5',
                        align: 'center',
                        valign: 'middle',
                        // visible: false,
                    },{
                        field: '分部2',
                        title:'5-10',
                        align: 'center',
                        valign: 'middle',
                         // visible: false,
                    }
                ],
        onClickRow: function(row, element){
            $('.success').removeClass('success');//去除之前样式
            $(element).addClass('success');//添加当前选中的
            $(".success").css("background-color");//保存之前的颜色
        },
    });
    ajaxcan("../../table/shichang/daily_t3.php",{"time":time,'pq':userinfo[3]},"GET",0,function(data){
            // alert(data);
            var e_data = eval("("+data+")");
            var str_data = JSON.stringify(e_data); //转为字符串
            localStorage.setItem("c3_data",str_data);//所有分部的数据--daily_t3

            var r3_data = new Array();
            var r3_row1 = new Array();
            var r3_row2 = new Array();
            var r3_row3 = new Array();
            var r3_row4 = new Array();
            var r3_row5 = new Array();
	    //最小单位是分部，select改变最小单位变成了显示网点
            r3_row1['分部1'] = e_data[0]['分部名称'];
            r3_row1['分部2'] = e_data[5]['分部名称'];
            r3_row2['分部1'] = e_data[1]['分部名称'];
            r3_row2['分部2'] = e_data[6]['分部名称'];
            r3_row3['分部1'] = e_data[2]['分部名称'];
            r3_row3['分部2'] = e_data[7]['分部名称'];
            r3_row4['分部1'] = e_data[3]['分部名称'];
            r3_row4['分部2'] = e_data[8]['分部名称'];
            r3_row5['分部1'] = e_data[4]['分部名称'];
            r3_row5['分部2'] = e_data[9]['分部名称'];
            
            r3_data.push(r3_row1);
            r3_data.push(r3_row2);
            r3_data.push(r3_row3);
            r3_data.push(r3_row4);
            r3_data.push(r3_row5);
            
            // alert(r3_data);
            $('#tablet1').bootstrapTable('load',r3_data);

            var r3_data1 = new Array();
            var r3_row11 = new Array();
            var r3_row22 = new Array();
            var r3_row33 = new Array();
            var r3_row44 = new Array();
            var r3_row55 = new Array();
            var l = e_data.length;
            r3_row11['分部1'] = e_data[l-10]['分部名称'];
            r3_row11['分部2'] = e_data[l-5]['分部名称'];
            r3_row22['分部1'] = e_data[l-9]['分部名称'];
            r3_row22['分部2'] = e_data[l-4]['分部名称'];
            r3_row33['分部1'] = e_data[l-8]['分部名称'];
            r3_row33['分部2'] = e_data[l-3]['分部名称'];
            r3_row44['分部1'] = e_data[l-7]['分部名称'];
            r3_row44['分部2'] = e_data[l-2]['分部名称'];
            r3_row55['分部1'] = e_data[l-6]['分部名称'];
            r3_row55['分部2'] = e_data[l-1]['分部名称'];
            
            r3_data1.push(r3_row11);
            r3_data1.push(r3_row22);
            r3_data1.push(r3_row33);
            r3_data1.push(r3_row44);
            r3_data1.push(r3_row55);

            $('#tablet2').bootstrapTable('load',r3_data1);

            $("#icon").removeClass("fa fa-circle-o-notch fa-spin fa-3x");

    });

    //环形图
    chart_h = document.getElementById("middle_h");
    echart_h = echarts.init(chart_h);
    option_h = {
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b}: {c} ({d}%)"
            },
            series: [
               
                {
                    name:'大盘收入组成',//a
                    type:'pie',
                    radius: ['80%', '90%'],
                    data:[]
                }
            ]
        };
    echart_h.setOption(option_h);
    colors = ["#cf3","#0aa","#bfe","#7fe","#3cf","#0088a8","#cbf","#fb6"];
    ajaxcan("../../table/shichang/daily_model.php",{"time":time,'pq':userinfo[3]},"GET",0,function(data){
        // alert(data);
        var e_data = eval("("+data+")");//大盘各模块占比
        for(var i=0;i<e_data.length;i++){
           option_h.series[0].data.push({value:e_data[i][1],name:e_data[i][0],itemStyle:{normal:{color:colors[i]||''}}});
        }
        echart_h.setOption(option_h);
        
    });

    //左边柱状图
    chart_l2 = document.getElementById("left_c2");
    echart_l2 = echarts.init(chart_l2);

    //alert(chart_l2.offsetWidth);
    option_l2 = {
            tooltip: {
                    formatter:'{c}%',
                },
            xAxis: {
                 axisTick:{
                    show:false
                },
                 axisLine:{
                        // show:false,
                        lineStyle:{
                            color:'#fff',
                        }
                    },
                name:'%',
                type: 'value',
                splitLine:{show: false},
                boundaryGap: [0, 0.01]
            },
            yAxis: {
                axisTick:{
                    show:false
                },
                 axisLine:{
                        // show:false,
                        lineStyle:{
                            color:'#fff',
                        }
                    },
                type: 'category',
                data: []
            },
            series: [
                {
                    name: '出仓晚点数',
                    type: 'bar',
                    data: []
                },
               
            ]
        };
    // echart_l2.setOption(option_l2);

    //左一 后面都有大盘数据，可以先取
    $('#left_c1').bootstrapTable({
        height:250,
        cache: false,
        columns: [
                    {
                        field: '指标',
                        title: '指标',
                        align: 'center',
                        valign: 'middle',
                    },{
                        field: time.substr(5,2)-1+'月',//上月
                        title: '上月达成',
                        align: 'center',
                        valign: 'middle',
                    },{
                        field: time.substr(5,2)-0+'月累计',//今月
                        title: '当月达成',
                        align: 'center',
                        valign: 'middle',
                    }
                ],
        onClickRow: function(row, element){
            $('.success').removeClass('success');//去除之前样式
            $(element).addClass('success');//添加当前选中的
            $(".success").css("background-color");//保存之前的颜色
        },
    });

    $.ajax({     
        url: "../../table/cangguan/cangguan_table.php",  
        type: "POST",        
        data:{"time":time,"area":userinfo[3],"point":""},
        error: function(){      
            alert('请求超时');  
        }, 
        success:function (data){
            // alert(data);
            var e_data = eval("("+data+")");//营运指标
            var str_data = JSON.stringify(e_data); 
            localStorage.setItem("c4_data",str_data);//存到localStorage
          
            $('#left_c1').bootstrapTable('load',e_data);

            var conts = "";
            for(var i in e_data){
                conts += "<option name='"+i+"'>"+e_data[i]['指标']+"</option>";
            }
            $('#zbs').html(conts);
            var target = $("#zbs option:selected").text();
            // alert(target);
            for(var i in e_data[0][target]){
               option_l2.yAxis.data.push(i);
		//去除百分号
               option_l2.series[0].data.push({value:trim_w(e_data[0][target][i]),itemStyle:{normal:{color:'#3fd'}}});
            }
	    chart_l2.style.width = '100%';
	    //alert(chart_l2.offsetWidth);
            echart_l2.setOption(option_l2);
        }
    });

    //左下top
    $('#tablet3').bootstrapTable({
        cache: false,
        columns: [
                    {
                        field: '分部1',
                        title:'1-5',
                        align: 'center',
                        valign: 'middle',
                        // visible: false,
                    },{
                        field: '分部2',
                        title:'5-10',
                        align: 'center',
                        valign: 'middle',
                         // visible: false,
                    }
                ],
        onClickRow: function(row, element){
            $('.success').removeClass('success');//去除之前样式
            $(element).addClass('success');//添加当前选中的
            $(".success").css("background-color");//保存之前的颜色
        },
    });

    $('#tablet4').bootstrapTable({
        // height:300,
        cache: false,
        columns: [
                    {
                        field: '分部1',
                        title:'1-5',
                        align: 'center',
                        valign: 'middle',
                    },{
                        field: '分部2',
                        title:'5-10',
                        align: 'center',
                        valign: 'middle',
                    }
                ],
        onClickRow: function(row, element){
            $('.success').removeClass('success');//去除之前样式
            $(element).addClass('success');//添加当前选中的
            $(".success").css("background-color");//保存之前的颜色
        },
    });

     $.ajax({     
        url: "../../table/cangguan/cangguan_preload.php",  
        type: "POST",        
        data:{"time":time,"pq":userinfo[3]}, 
        error: function(){      
            alert('请求超时');  
        },  
        success:function (data){
            // alert(data);
            var e_data = eval("("+data+")");
            var str_data = JSON.stringify(e_data); //转为字符串
            localStorage.setItem("c5_data",str_data);//前十和后十指标

            //默认第一个指标的前后十
            var bot10 = e_data[0]['指标后十重点网点'].split(",");

            var r5_data = new Array();
            var r5_row1 = new Array();
            var r5_row2 = new Array();
            var r5_row3 = new Array();
            var r5_row4 = new Array();
            var r5_row5 = new Array();
            r5_row1['分部1'] = bot10[0];
            r5_row1['分部2'] = bot10[5];
            r5_row2['分部1'] = bot10[1];
            r5_row2['分部2'] = bot10[6];
            r5_row3['分部1'] = bot10[2];
            r5_row3['分部2'] = bot10[7];
            r5_row4['分部1'] = bot10[3];
            r5_row4['分部2'] = bot10[8];
            r5_row5['分部1'] = bot10[4];
            r5_row5['分部2'] = bot10[9];
            
            r5_data.push(r5_row1);
            r5_data.push(r5_row2);
            r5_data.push(r5_row3);
            r5_data.push(r5_row4);
            r5_data.push(r5_row5);
            
            $('#tablet4').bootstrapTable('load',r5_data);

            var top10 = e_data[1]['指标前十重点网点'].split(",");
            var r5_data1 = new Array();
            var r5_row11 = new Array();
            var r5_row22 = new Array();
            var r5_row33 = new Array();
            var r5_row44 = new Array();
            var r5_row55 = new Array();
            r5_row11['分部1'] = top10[0];
            r5_row11['分部2'] = top10[5];
            r5_row22['分部1'] = top10[1];
            r5_row22['分部2'] = top10[6];
            r5_row33['分部1'] = top10[2];
            r5_row33['分部2'] = top10[7];
            r5_row44['分部1'] = top10[3];
            r5_row44['分部2'] = top10[8];
            r5_row55['分部1'] = top10[4];
            r5_row55['分部2'] = top10[9];
            
            r5_data1.push(r5_row11);
            r5_data1.push(r5_row22);
            r5_data1.push(r5_row33);
            r5_data1.push(r5_row44);
            r5_data1.push(r5_row55);
	    

            $('#tablet3').bootstrapTable('load',r5_data1);
	   
	    //var h3 = $('#tablet3').height();
 	    //var h4 = $('#tablet4').height();
            //if(h3>210){
                   $('#tablet3 td').css('font-size','80%');
             // }
            //if(h4>50){
                  $('#tablet4 td').css('font-size','80%');    
             // }
        }
    });

    $('#zbs').change(function(){
        option_l2.yAxis.data = [];
        option_l2.series[0].data = [];
        var index = $("#zbs option:selected").attr('name');
        var target = $("#zbs option:selected").text();
        var str_data = localStorage.getItem("c4_data");
        var c4_data = JSON.parse(str_data);//转回数组
        var arr_data = c4_data[parseInt(index)][target];
        for(var i in arr_data){
           option_l2.yAxis.data.push(i);
           option_l2.series[0].data.push({value:trim_w(arr_data[i]),itemStyle:{normal:{color:'#3fd'}}});
        }
        echart_l2.setOption(option_l2);

        var str_data = localStorage.getItem("c5_data");
        var c5_data = JSON.parse(str_data);//转回数组

        //默认第一个指标的前后十
        var bot10 = c5_data[parseInt(index)*2]['指标后十重点网点'].split(",");

        var r5_data = new Array();
        var r5_row1 = new Array();
        var r5_row2 = new Array();
        var r5_row3 = new Array();
        var r5_row4 = new Array();
        var r5_row5 = new Array();
        r5_row1['分部1'] = bot10[0];
        r5_row1['分部2'] = bot10[5];
        r5_row2['分部1'] = bot10[1];
        r5_row2['分部2'] = bot10[6];
        r5_row3['分部1'] = bot10[2];
        r5_row3['分部2'] = bot10[7];
        r5_row4['分部1'] = bot10[3];
        r5_row4['分部2'] = bot10[8];
        r5_row5['分部1'] = bot10[4];
        r5_row5['分部2'] = bot10[9];
        
        r5_data.push(r5_row1);
        r5_data.push(r5_row2);
        r5_data.push(r5_row3);
        r5_data.push(r5_row4);
        r5_data.push(r5_row5);
        
        $('#tablet4').bootstrapTable('load',r5_data);

        var top10 = c5_data[parseInt(index)*2+1]['指标前十重点网点'].split(",");
        var r5_data1 = new Array();
        var r5_row11 = new Array();
        var r5_row22 = new Array();
        var r5_row33 = new Array();
        var r5_row44 = new Array();
        var r5_row55 = new Array();
        r5_row11['分部1'] = top10[0];
        r5_row11['分部2'] = top10[5];
        r5_row22['分部1'] = top10[1];
        r5_row22['分部2'] = top10[6];
        r5_row33['分部1'] = top10[2];
        r5_row33['分部2'] = top10[7];
        r5_row44['分部1'] = top10[3];
        r5_row44['分部2'] = top10[8];
        r5_row55['分部1'] = top10[4];
        r5_row55['分部2'] = top10[9];
        
        r5_data1.push(r5_row11);
        r5_data1.push(r5_row22);
        r5_data1.push(r5_row33);
        r5_data1.push(r5_row44);
        r5_data1.push(r5_row55);
	
	$('#tablet3').bootstrapTable('load',r5_data1);

        $('#tablet3 td').css('font-size','85%');
	 $('#tablet4 td').css('font-size','85%');	

    });
	
    //窗口缩放 全部以大屏幕定位
    $(window).resize(function (){

       //今日分析
       chart_c1.offsetWidth = window.innerWidth*0.2 + 'px';
       echart_c1.resize();
       
       //一周收入
       chart_r2.offsetWidth = window.innerWidth*0.2 + 'px';
       echart_r2.resize();

       //环形
       chart_h.offsetWidth = window.innerWidth*0.5 + 'px';
       echart_h.resize();

       //环形中的图
       chart_z1.offsetWidth = window.innerWidth*0.15 + 'px';
       echart_z1.resize();

       //七天指标
       chart_l2.offsetWidth = window.innerWidth*0.2 + 'px';
       echart_l2.resize();

    });



});

function show_num(n,cla){ 
    var it = $("."+cla+" i"); 
    var len = (""+n).length; 
    for(var i=0;i<len;i++){ 
        if(it.length<=i){ 
            // alert(len);
            $("."+cla).append("<i></i>"); 
        } 
        var num= (""+n).charAt(i); 
        var y = -parseInt(num)*58; //y轴位置 
        var obj = $("."+cla+" i").eq(i); 
        obj.animate({ //滚动动画 
            backgroundPosition :'(0 '+String(y)+'px)'  
            }, 'slow','swing',function(){} 
        ); 
    } 
};

function get_ori_data(){
	var o = '00000';
	show_num(o,'t_num');
	show_num(o,'t_num1');
}


function getdata(){ 
    //都是大盘数据
    var str_data = localStorage.getItem("c1_data");
    
    var c1_data = JSON.parse(str_data);//转回数组

    var l1 = parseInt(c1_data["当天折后收入"]);
    var l2 = c1_data["当天件量"];
    var t = l1.toString().length - l2.toString().length;
    var add = '';
    for(var i=0;i<t;i++) add += '0';
    show_num(add+l2,'t_num');

    show_num(l1,'t_num1');
};

function setTab(m,n){  
  
 var tli=document.getElementById("menu"+m).getElementsByTagName("li");  
  
 var mli=document.getElementById("main"+m).getElementsByTagName("ul");  
  
 for(i=0;i<tli.length;i++){  
  
      tli[i].className=i==n?"hover":"";  
      
      mli[i].style.display=i==n?"block":"none";  
      
    }  
};

function setTab1(m,n){  
  
 var tli=document.getElementById("menu"+m).getElementsByTagName("li");  
  
 var mli=document.getElementById("main"+m).getElementsByTagName("ul");  
  
 for(i=0;i<tli.length;i++){  
  
      tli[i].className=i==n?"hover1":"";  
      
      mli[i].style.display=i==n?"block":"none";  
      
    }
}  

</script>
<style type="text/css">
    .t_num i {
        width:32px;
        height:47px;
        display: inline-block;
        background:url(../../images/number1.png) no-repeat;
        background-position: 0 0;
        text-indent: -999em;
    }
   /* .fixed-table-header{
        background-color: #0e1018;
    }*/
</style>
</head>
<body>

<?php include_once('header.php');?>

<div class='content'>
    
    <i id='icon' style="position: absolute; color: #fff;left: 50%;top:30%;"></i><!--加载提示-->
    <!--居中-->
    <div class="middle">
        <div class="middle_t">
            <h2 class="middle_h2"> <span><?php echo date('Y-m-d',strtotime('-1 day'));?></span></h2>
            <h3 class="middle_h3">收件总数</h3><span class="t_num"></span>
            <h3 class="middle_h32">收入总数</h3><span class="t_num t_num1"></span>
        </div>
        <div class="middle_m">
            <h3>月收入组成</h3>
            <div id="middle_h"></div>
            <div id="middle_z1"></div>
            <div id="middle_z2"></div>
        </div>
    </div>
    
    <!-- <div  class="col-md-3"> -->
    <div class="data-box1 right_11" id="box01">
        <i class="topL"></i>
        <i class="topR"></i>
        <i class="bottomL"></i>
        <i class="bottomR"></i>
        <div class="data-title">
            <b class="data-title-left">[</b>
            <span>今日分析</span>
            <b class="data-title-right">]</b>
        </div>
        <div id="box2" class="box-echart">
             <select id='model_select'>
                <option selected="selected">大区/片区</option>
                <option>月结</option>
                <option>散单</option>
                <option>重货快运</option>
                <option>物流普运</option>
                <option>国际件</option>
                <option>保价</option>
                <option>代收服务费</option>
             </select>
             <!-- <table id="right_c1" data-classes="table table-bordered"></table> -->
             <div id="right_c1"></div>
        </div>   
    </div>
    <div class="data-box1 right_12" id="box8-box">
        <i class="topL"></i>
        <i class="topR"></i>
        <i class="bottomL"></i>
        <i class="bottomR"></i>
        <div class="data-title">
            <b class="data-title-left">[</b>
            <span>一周收入</span>
            <b class="data-title-right">]</b>
        </div>
        <div id="box8" class="box-echart">
            <div id="right_c2"></div>
        </div>
    </div>

    <div class="data-box1 right_13">
        <i class="topL"></i>
        <i class="topR"></i>
        <i class="bottomL"></i>
        <i class="bottomR"></i>
        <div class="data-title">
            <b class="data-title-left">[</b>
            <span>月收件进度</span>
            <b class="data-title-right">]</b>
        </div>
        <div id="box9" class="box-echart">
            <div id="tabs1">  
                <div class="menu1box">  
                <ul id="menu1">  
                    <li class="hover" onmouseover="setTab(1,0)"><a>前十</a></li>
                    <li onmouseover="setTab(1,1)"><a >后十</a></li>  
                </ul>  
                </div>  
                <div class="main" id="main1">  
                    <ul class="block">
                        <div id="right_c3">
                            <table id='tablet1' data-classes="table table-bordered"></table>  
                        </div>
                    </ul>  
                    <ul>
                        <div id="right_c32">
                         <table id='tablet2' data-classes="table table-bordered"></table>  
                        </div>
                    </ul>  
                </div>   
            </div>  
        </div>
    </div>

    <div class="data-box1 left_11">
            <i class="topL"></i>
            <i class="topR"></i>
            <i class="bottomL"></i>
            <i class="bottomR"></i>
            <div class="data-title">
                <b class="data-title-left">[</b>
                <span>营运指标</span>
                <b class="data-title-right">]</b>
            </div>
            <div id="box10" class="box-echart">
                 <select>
                    <option selected="selected">仓管端</option>
                    <option>收派端</option>
                 </select>
                 <table id="left_c1" data-classes="table table-bordered"></table>
            </div>
    </div>

    <div class="data-box1 left_12">
            <i class="topL"></i>
            <i class="topR"></i>
            <i class="bottomL"></i>
            <i class="bottomR"></i>
            <div class="data-title">
                <b class="data-title-left">[</b>
                <span>七天指标展示</span>
                <b class="data-title-right">]</b>
            </div>
            <div id="box11" class="box-echart">
                 <select id='zbs'>
                 </select>
                <div id="left_c2"></div>
            </div>
    </div>

    <div class="data-box1 left_13">
            <i class="topL"></i>
            <i class="topR"></i>
            <i class="bottomL"></i>
            <i class="bottomR"></i>
            <div class="data-title">
                <b class="data-title-left">[</b>
                <span>本月指标排名</span>
                <b class="data-title-right">]</b>
            </div>
            <div id="box12" class="box-echart">
            <div id="tabs2">  
                <div class="menu1box">  
                <ul id="menu2">  
                    <li class="hover1" onmouseover="setTab1(2,0)"><a>前十</a></li>
                    <li onmouseover="setTab1(2,1)"><a>后十</a></li>  
                </ul>  
                </div>  
                <div class="main" id="main2">  
                    <ul class="block">
                        <div id="right_l3">
                            <table id='tablet3' data-classes="table table-bordered"></table>  
                        </div>
                    </ul>  
                    <ul>
                        <div id="right_l32">
                         <table id='tablet4' data-classes="table table-bordered"></table>  
                        </div>
                    </ul>  
                </div>   
            </div>  
        </div>
    </div>

    <div class="last-span">
        <div class="heading">
            <h3 class="title-name">一周简报<small>更新时间：<span class="updateTime"><?php echo date('Y-m-d H:i:s');?></span></small></h3>
        </div>
        <div class="contents">
            <div class="content1">
                <div class="content_time"><?php echo date('Y-m-d',strtotime('-1 day'));?></div>
                <div class="content_count">
                    <p class="piaoshu1">票数：0</p>
                    <p class="shouru1">收入：0</p>
                </div>
              <!--   <div class="content_count1">
                   <p class="piaoshu1">日件件量：200</p>
                    <p class="shouru1">日均收入：200</p>
                </div> -->
            </div>
            <div class="content2">
                <div class="content_time"><?php echo date('Y-m-d',strtotime('-2 day'));?></div>
                <div class="content_count">
                    <p class="piaoshu2">票数：0</p>
                    <p class="shouru2">收入：0</p>
                </div>
              <!--   <div class="content_count1">
                    <p class="piaoshu1">日件件量：200</p>
                    <p class="shouru1">日均收入：200</p>
                </div> -->
            </div>
            <div class="content3">
                <div class="content_time"><?php echo date('Y-m-d',strtotime('-3 day'));?></div>
                <div class="content_count">
                    <p class="piaoshu3">票数：0</p>
                    <p class="shouru3">收入：0</p>
                </div>
                <!-- <div class="content_count1">
                   <p class="piaoshu1">日件件量：200</p>
                    <p class="shouru1">日均收入：200</p>
                </div> -->
            </div>
            <div class="content4">
                <div class="content_time"><?php echo date('Y-m-d',strtotime('-4 day'));?></div>
                <div class="content_count">
                    <p class="piaoshu4">票数：0</p>
                    <p class="shouru4">收入：0</p>
                </div>
                <!-- <div class="content_count1">
                    <p class="piaoshu1">日件件量：200</p>
                    <p class="shouru1">日均收入：200</p>
                </div> -->
            </div>
            <div class="content5">
                <div class="content_time"><?php echo date('Y-m-d',strtotime('-5 day'));?></div>
                <div class="content_count">
                    <p class="piaoshu5">票数：0</p>
                    <p class="shouru5">收入：0</p>
                </div>
            <!--     <div class="content_count1">
                    <p class="piaoshu1">日件件量：200</p>
                    <p class="shouru1">日均收入：200</p>
                </div> -->
            </div>
            <div class="content6">
                <div class="content_time"><?php echo date('Y-m-d',strtotime('-6 day'));?></div>
                <div class="content_count">
                    <p class="piaoshu6">票数：0</p>
                    <p class="shouru6">收入：0</p>
                </div>
               <!--  <div class="content_count1">
                    <p class="piaoshu1">日件件量：200</p>
                    <p class="shouru1">日均收入：200</p>
                </div> -->
            </div>
            <div class="content7">
                <div class="content_time"><?php echo date('Y-m-d',strtotime('-7 day'));?></div>
                <div class="content_count">
                    <p class="piaoshu7">票数：0</p>
                    <p class="shouru7">收入：0</p>
                </div>
               <!--  <div class="content_count1">
                    <p class="piaoshu1">日件件量：200</p>
                    <p class="shouru1">日均收入：200</p>
                </div> -->
            </div>
        </div>
    </div>
    
</div>

<?php include_once('footer.php');?>
</body>
</html>
