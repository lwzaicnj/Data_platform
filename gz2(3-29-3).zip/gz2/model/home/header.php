<?php
@session_start();
include_once '../../includes/public_inc_func.php';
include_once '../../class/sql_class.php'; 
include_once '../../includes/public_db_func.php';
cookie_location('../../cas_index.php');//cookie失效


//读取权限表
$unique_id = addslashes($_COOKIE['unique_id']);
$db = new sql("sqlxz2012","IT_test");

// echo $unique_id;
//先读取是否管理员
//管理员默认所有菜单权限
//管理员之间不能互相更改权限

$rs = $db->query("select id,is_admin,片区 from dbo.it_users where unique_id='".$unique_id."'");
$row = $db->fetch_arr($rs);

$is_admin = $row['is_admin'];

//utf82gbk?
$auths = $db->query("select mid from dbo.it_auth where type='um' and pid='".addslashes($row['id'])."'");

//临时接口开始
// $auth_id = array('1','3','6');
// if($_COOKIE['unique_id']=='liwangzhi') $is_admin=1;
//临时接口结束

$auth_id = [];
//管理员拥有所有权限
if(!$is_admin){
    while ($rowi = $db->fetch_arr($auths)) {
        $auth_id[] = $rowi['mid'];
    }
}

//var_dump($row);
?>
<div class="header-top" style="background-color: #046;border: none;">
    <div class="container">
        <div class="row">
            <div class="col-xs-2 col-sm-6">  
                <div class="header-top-first clearfix" style="margin-top: 10px; color:#fff;">

                	<span>欢迎你,<B><?php echo html_trim(@$_SESSION['phpCAS']['user']); ?>(<?php echo html_trim($row['片区']);?>)</B></span>	
                </div>                      
            </div>
            <div class="col-xs-10 col-sm-6">

                <!-- header-top-second start -->
                <!-- ================ -->
                <div id="header-top-second"  class="clearfix">

                    <!-- header top dropdowns start -->
                    <!-- ================ -->
                    <div class="header-top-dropdown">
                        <div class="btn-group dropdown" >
                            <button style="color:#fff;" type="button" id='logout' class="btn dropdown-toggle"><i class="fa fa-user"></i>注销</button>
                        </div>
                    </div>
                    <!--  header top dropdowns end -->

                </div>
                <!-- header-top-second end -->

            </div>
        </div>
    </div>
</div>
<header class="header fixed clearfix" style="background-color: #024;border: none;">
    <div class="container">
        <div class="row" >
            <div class="col-md-3">
                    <!-- header-left start -->
                    <!-- ================ -->
                    <div class="header-left clearfix">

                        <!-- logo -->
                        <div class="logo">
                            <a href="#"><img id="logo" src="../../images/logo_red_footer.png" alt="sflogo"></a>
                        </div>

                        <!-- name-and-slogan -->
                        <!-- <div style="color:#fff;" class="site-slogan">
                            GuangZhou Business data platform
                        </div> -->

                    </div>
                    <!-- header-left end -->

                </div>
                
            <div class="col-md-9"  >

                <!-- header-right start -->
                <!-- ================ -->
                <div class="header-right clearfix"  >

                    <!-- main-navigation start -->
                    <!-- ================ -->
                    <div class="main-navigation animated" >

                        <!-- navbar start -->
                        <!-- ================ -->
                        <nav class="navbar navbar-default" role="navigation" >
                            <div class="container-fluid" >

                                <!-- Toggle get grouped for better mobile display -->
                                <div class="navbar-header"  >
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <div class="collapse navbar-collapse" id="navbar-collapse-1" >
                                    <ul class="nav navbar-nav navbar-right" >
                                        <li> <!--dropdown active-->
                                            <a " id="first" href="../../gz" >首页</a>
                                        </li>
                                    <?php if($is_admin) {?>
                                        <li class="dropdown">
                                            <a class="dropdown-toggle" data-toggle="dropdown">营运类</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="../../gz/y1">仓管端</a></li>
                                                <li><a href="">收派端</a></li>
                                                <!--<li><a href="">2</a></li>-->
                                            </ul>
                                        </li>
                                        
                                        <!-- mega-menu end -->
                                        <li class="dropdown">
                                            <a class="dropdown-toggle" data-toggle="dropdown">市场类</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="../../gz/s1">日报查看</a></li>
                                                <li><a href="../../gz/s2">月报查看</a></li>
                                                <!--<li><a href="">3</a></li>-->
                                            </ul>
                                        </li>
                                        <!--<li class="dropdown">
                                            <a href="" class="dropdown-toggle" data-toggle="dropdown">综合类</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="">1</a></li>
                                                <li><a href="">2</a></li>
                                                <li><a href="">3</a></li>
                                            </ul>
                                        </li>-->
                                       <!--  <li class="dropdown">
                                            <a href="" class="dropdown-toggle" data-toggle="dropdown">待输入</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="">1</a></li>
                                                <li><a href="">2</a></li>
                                                <li><a href="">3</a></li>
                                            </ul>
                                        </li> -->

                                         <li class="dropdown"> <!--dropdown active-->
                                            <a class="dropdown-toggle" data-toggle="dropdown" >管理</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="../../gz/m1">权限管理</a></li>
                                                <li><a href="../../gz/m2">营运指标管理</a></li>
                                                <li><a href="../../gz/m3">市场指标管理</a></li>
                                                <li><a href="../../gz/m4">网点管理</a></li>
                                                <li><a href="../../gz/m5">日志查看</a></li>
                                            </ul>
                                        </li><?php } else{ ?>
                                        <?php foreach ($auth_id as $value){ 
                                            if($value==1){
                                        ?>
                                         <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">营运类</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="../../gz/y1">仓管端</a></li>
                                                <li><a href="">收派端</a></li>
                                                <!--<li><a href="">2</a></li>-->
                                            </ul>
                                        </li><?php } elseif($value==3){ ?>
                                        <!-- mega-menu end -->
                                        <li class="dropdown">
                                            <a href="" class="dropdown-toggle" data-toggle="dropdown">市场类</a>
                                             <ul class="dropdown-menu">
                                                <li><a href="../../gz/s1">日报查看</a></li>
                                                <li><a href="../../gz/s2">月报查看</a></li>
                                                <!--<li><a href="">3</a></li>-->
                                            </ul>
                                        </li><?php }} ?>

                                        <?php } ?>
                                    </ul>
                                </div>

                            </div>
                        </nav>
                        <!-- navbar end -->

                    </div>
                    <!-- main-navigation end -->

                </div>
                <!-- header-right end -->

            </div>

            
        </div>
    </div>
</header>

<!-- header end -->
