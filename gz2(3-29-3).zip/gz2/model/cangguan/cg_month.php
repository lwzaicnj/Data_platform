<?php 
require '../../includes/public_inc_func.php';
cookie_location('../../cas_index.php');

include_once '../../includes/public_db_func.php';
$rs_arr = get_targets();
$wd_details = get_infos(); 
// var_dump($wd_details);

$unique_id = addslashes($_COOKIE['unique_id']);
$user_info = get_user($unique_id);

$auth_de = @get_pqfb($wd_details,$user_info[3]);

//var_dump($auth_de);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>广州数据平台</title>
<?php 
require '../../includes/header_inner.php';
?>
<script type="text/javascript" src="../../js/home/home.js"></script>
<script type="text/javascript" >
$(function(){ 
 	index = location.href; //取得整个地址栏
   	var num=index.indexOf("?")
   	index=decodeURI(index.substr(num+1)); 
   	index = index.split("=")[1]; //获取对应的行参数
   	if(!index) index = "滞留件解决率";

   	// var ob_datas = new Array();
 	areas = <?php echo html_trim(json_encode($auth_de));?>;
 	userinfo = <?php echo html_trim(json_encode($user_info));?>;

 	var prams = <?php echo html_trim(json_encode($rs_arr)); ?>;

 	target = prams[index][6];//取得目标值


 	//第三次跳转
    $('#table').on('click','th:nth-child(3)',function(){

    	window.location.href='y3?index='+encodeURI(index);
    	// alert($('th:nth-child(3)').attr("data-field"));
    });

	$('#btn').click(function(){
		var time = $("#time").val();
		ajaxcan("../../table/cangguan/cangguan_month_table.php",{"time":time.toString(),"index":index.toString(),"pq":userinfo[3]},"POST",0,function(data){
 				var de_json;
				// alert(data);
				if(data) de_json=eval("("+data+")");
				for(var i in de_json){
					for(var k in de_json[i])
						areas[i][k] = de_json[i][k];
				}
				$('#table').bootstrapTable('load', areas); 
 		},function(){
		 		$("#btn").attr({ disabled: "disabled" });  
		 		 $("#icon").addClass("fa fa-circle-o-notch fa-spin");
		 },function(){
			$("#icon").removeClass("fa fa-circle-o-notch fa-spin");
	 		$("#btn").removeAttr("disabled");
		});

	});
	
	$('#time').jeDate({
        isinitVal:true,
        format: 'YYYY-MM',
        //点击确定的回调
        okfun:function(elem, val) {
        	choosefun(elem,val);
        },
        //选中日期的回调
        choosefun:function(elem, val) {
        	$("#table").bootstrapTable('destroy'); 
			show(areas);
			//月份改变再次统计不达标数
			ajaxcan("../../table/cangguan/cangguan_achieve.php",{"time":val,"pq":userinfo[3]},"POST",0,function(data){
					var de_json;
					// alert(data);
					if(data) de_json=eval("("+data+")");  
					for(var i in de_json){
						for(var k in de_json[i])
							areas[i][k] = de_json[i][k];
					}
					$('#table').bootstrapTable('load', areas);
			},function(){});
        },
    });

	//初始化时间后加载数据
    show(areas);

    //初始化显示不达标数量 初始化月份的
    var time = $("#time").val();
    ajaxcan("../../table/cangguan/cangguan_achieve.php",{"time":time,"pq":userinfo[3]},"POST",0,function(data){
    		var de_json;
			// alert(data);
			if(data) de_json=eval("("+data+")");  
			for(var i in de_json){
				for(var k in de_json[i])
					areas[i][k] = de_json[i][k];
			}
			$('#table').bootstrapTable('load', areas);
    },function(){});

	//导出动作
	$('div.export').click(function(){
		 ajaxcan("../../table/download/download_action.php",{"action":"【下载"+index+"周数据】"},"POST",0,function(data){
		 		var de_json;
				if(data) de_json=eval("("+data+")");
		 },function(){});
	});
});

function show(datas){
	var time = $("#time").val();
	time_arr = get_three_month(time);

	$('#table').bootstrapTable({
		pagination: true,pageSize:12,
		// height: 750,
		search:true,searchAlign:'left',
		showExport: true,
		exportDataType: "all",
		buttonsAlign:"right",
		exportOptions:{
			fileName: index+'数据', 
			excelstyles: ['background-color', 'color', 'font-size', 'font-weight'],  
		},
		exportTypes:['excel'], 
		cache: false, striped: true,
		sidePagination: "client", 
	    columns: [
		    		[ {
			    			field: '分部代码',
					        title: '分部代码',
					        align: 'center',
					        valign: 'middle',
					        rowspan: 2,
					        colspan: 1,
		    			},
		    			{
		    				field: '分部名称',
					        title: '分部名称',
					        align: 'center',
					        valign: 'middle',
					        rowspan: 2,
					        colspan: 1
		    			},
		    			{
			    			field: index,
					        // title: '<a class="arrow"></a><a style="cursor:pointer;">'+index+'</a>',
					        title: '<a style="text-decoration:underline;cursor:pointer;">'+index+'</a>',
					        align: 'center',
					        valign: 'middle',
					        rowspan: 1,
					        colspan: 7,
					        class : 'jump',
		    			},
		    			{
		    				field: '不达标指标数量',
					        title: '不达标指标数量',
					        align: 'center',
					        valign: 'middle',
					        rowspan: 2,
					        colspan: 1,

		    			},
				    ],
				    [	{
				    		field: time_arr[1]+'月',
					        title: time_arr[1]+'月',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,

				    	},{
				    		field: time_arr[0]+'月第一周',
					        title: time_arr[0]+'月第一周',
					        align: 'center',
					        valign: 'middle',
							formatter:cellformat,
				    	},{
				    		field: time_arr[0]+'月第二周',
					        title: time_arr[0]+'月第二周',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,
				    	},{
				    		field: time_arr[0]+'月第三周',
					        title: time_arr[0]+'月第三周',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,
				    	},{
				    		field: time_arr[0]+'月第四周',
					        title: time_arr[0]+'月第四周',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,
				    	},{
				    		field: '周环比',
					        title: '周环比',
					        align: 'center',
					        valign: 'middle',
				    	},{
				    		field: '月累计',
					        title: '月累计',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,
				    	}
				    ]
			      ],
		data: datas ,
	});
	function cellformat(value,row,index){  
		if(!value|| value=='-') return '';
		if(target>0.3){
		    if(parseFloat(value.replace(/%/, "")/100)>=target){  
		    	return get_color(value,1);
		    }else if(parseFloat(value.replace(/%/, "")/100)>=target*0.9){ 
		    	return get_color(value,2);
		    }else{
		    	return get_color(value,0);
		    }
		}else{
			if(parseFloat(value.replace(/%/, "")/100)<=target){  
		    	return get_color(value,1);
		    }else if(parseFloat(value.replace(/%/, "")/100)>=target*1.1){ 
		    	return get_color(value,2);
		    }else{ 
		    	return get_color(value,0);
		    }
		}
	};
};

</script>
</head>
<body>
<?php require '../home/header.php';?>
<div id="search-field" align="center">
 <span>目标:<?php echo html_trim($rs_arr[urldecode($_GET['index'])][6]*100).'%';?></span>
<i class="icon-flag icon-2x" style="color:red;"></i>: 小于90%目标值
<i class="icon-flag icon-2x" style="color:#00f;"></i>: 90%目标~目标值
<i class="icon-flag icon-2x" style="color:green;"></i><span class="icons">: 大于等于目标值</span>
 <input type="text"  id="time"/>&nbsp;&nbsp;
 <input type="button" id='btn' value="查询">&nbsp;&nbsp;
 <i id='icon'></i>
</div>
<table id="table" data-classes="table table-bordered"></table> 

<?php include_once('../home/footer.php');?>
</body>
</html>

