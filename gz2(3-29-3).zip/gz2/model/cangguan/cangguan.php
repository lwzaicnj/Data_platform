<?php 
include_once '../../includes/public_inc_func.php';
cookie_location('../../cas_index.php');
include_once '../../class/manageClass.php';
include_once '../../includes/public_db_func.php';
session_start();

$wd_details = get_pq_fb();

// $wd_details = get_infos();

$unique_id = addslashes($_COOKIE['unique_id']);
$user_info = get_user($unique_id);

// var_dump($user_info);

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>广州数据平台</title>
<?php 
include_once '../../includes/header_inner.php';
?>
<script type="text/javascript" src="../../js/home/home.js"></script>
<script type="text/javascript" >
$(function(){ 
 	//处理区域选择
 	var area = <?php echo html_trim(json_encode($wd_details));?>;//数组
 	ob_datas = new Array();

 	//用户信息，来判断大区和分部
 	infos = <?php echo html_trim(json_encode($user_info));?>;

 	//获取所有指标
 	ajaxcan("../../table/datafromdb/get_target.php",{"time":""},"POST",0,function(data){
 			if(data) ob_datas=eval("("+data+")");  
			// alert(ob_datas[0]['指标维度']);
			$('#table').bootstrapTable('load', ob_datas);
 	},function(){});


	$('#btn').click(function(){
		var time = $("#time").val();
    	var are = $("#select2 option:selected").text();
    	var point = $("#select3 option:selected").text();
    	ajaxcan("../../table/cangguan/cangguan_table.php",{"time":time.toString(),"area":are.toString(),"point":point.toString()},"POST",0,function(data){
 				//默认显示第一个数据
				var selected_id = $("#select option:selected").attr("id");

				var de_json;
				// alert(data);
				if(data) de_json=eval("("+data+")");  //eval()可以执行字符串中的js代码！ 转string成object
				for(var i in de_json){
					for(var k in de_json[i])
						ob_datas[i][k] = de_json[i][k];
				}
				$('#table').bootstrapTable('load', ob_datas);  
 		},function(){
		 		$("#btn").attr({ disabled: "disabled" });  
		 		 $("#icon").addClass("fa fa-circle-o-notch fa-spin");
		 },function(){
			$("#icon").removeClass("fa fa-circle-o-notch fa-spin");
	 		$("#btn").removeAttr("disabled");
		});
	});

	//渲染片区
	// var cont="<option>大盘区</option>";
 // 	for(var ids in area){
 // 		cont += "<option>"+ids+"</option>";
 // 	}
 // 	$("#select2").html(cont);

 	$("#select1 option:first").prop("selected", 'selected'); 
	$("#select2").change(function(){
		var select_area = $("#select2 option:selected").text();
	 	var content="<option></option>";
	 	for(var index in area[select_area]){
	 		content += "<option>"+area[select_area][index]['分部代码']+"</option>";
	 	}
	 	$("#select3").html(content);
		
	});

	//权限判断
	var a = get_select_arr('#select2');

	var indx =  $.inArray(infos[3], a);
	if(infos[3]!='广州区' && indx>=0){
		$("#select2 option:eq("+indx+")").attr('selected','selected');
		//锁死
		$("#select2").attr('disabled','disabled');
		var content="<option></option>";
	 	for(var index in area[infos[3]]){
	 		content += "<option>"+area[infos[3]][index]['分部代码']+"</option>";
	 	}
	 	$("#select3").html(content);

	 	var da = get_select_arr('#select3');
	 	var indx_da =  $.inArray(infos[4], da);
	 	if(indx_da>=0){
	 		$("#select3 option:eq("+indx_da+")").attr('selected','selected');
	 		$("#select3").attr('disabled','disabled');
	 	}
	}
		

	$('#time').jeDate({
        isinitVal:true,
        format: 'YYYY-MM',
        //点击确定的回调
        okfun:function(elem, val) {
        	choosefun(elem,val);
        },
        //选中日期的回调
        choosefun:function(elem, val) {
        	$("#table").bootstrapTable('destroy'); 
			show(ob_datas);
			ajaxcan("../../table/cangguan/cangguan_preload.php",{"time":val,"pq":infos[3]},"POST",0,function(data){
 				var de_json;
					// alert(data);
				if(data) de_json=eval("("+data+")");  
				for(var i in de_json){
					if(i<12)
						ob_datas[i]['指标后十重点网点'] = de_json[i*2]['指标后十重点网点'];
				}
				$('#table').bootstrapTable('load', ob_datas);
	 		},function(){});

        	//$.ajax({
			// 	contentType: "application/x-www-form-urlencoded; charset=utf-8", 
			// 	url: "../../table/cangguan/cangguan_preload.php",  
			// 	type: "POST",       
			// 	traditional: true,  
			// 	data:{"time":val},  
			// 	error: function(){      
			// 		alert('请求超时');  
			// 	},  
			// 	success:function (data){  //
			// 		var de_json;
			// 		// alert(data);
			// 		if(data) de_json=eval("("+data+")");  
			// 		for(var i in de_json){
			// 			if(i<12)
			// 				ob_datas[i]['指标后十重点网点'] = de_json[i*2]['指标后十重点网点'];
			// 		}
			// 		$('#table').bootstrapTable('load', ob_datas);
			// 	}    
			// });
        },
    });

    show(ob_datas);
    //加载页面显示默认月份的最后十大
    var val = $("#time").val();
    ajaxcan("../../table/cangguan/cangguan_preload.php",{"time":val,"pq":infos[3]},"POST",0,function(data){
		var de_json;
		// alert(data);
		if(data) de_json=eval("("+data+")");  
		for(var i in de_json){
			if(i<12){
				// alert(de_json[i*2]['指标后十重点网点']);
				ob_datas[i]['指标后十重点网点'] = de_json[i*2]['指标后十重点网点'];
			}
		}
		$('#table').bootstrapTable('load', ob_datas);
	},function(){});

	//导出动作
	$('div.export').click(function(){
		ajaxcan("../../table/download/download_action.php",{"action":"【下载仓管指标数据】"},"POST",0,function(data){
				var de_json;
				if(data) de_json=eval("("+data+")");
		},function(){});
	});
});

function show(datas){
	var time = $("#time").val();
	time_arr = get_three_month(time);

	$('#table').bootstrapTable({
		// url:"data.json",
		// pagination: true,pageSize:15,
		// search:true,searchAlign:'left',
		// height: 450,
		showExport: true,
		exportDataType: "all",
		exportTypes:['excel'], 
		exportOptions:{
			fileName: '指标数据', 
			excelstyles: ['background-color', 'color', 'font-size', 'font-weight'],  
		},
		cache: false, striped: true,
		sidePagination: "client", 
	    columns: [
		    		[	{
					        field: '指标项',
					        // <span style="color:red">指标项</span>
					        title: '指标项',
					        align: 'center',
					        valign: 'middle',
				       		rowspan: 2,
				       		colspan: 1,
				       		formatter: function(value,row,index){
				       			return '<a style="text-decoration:underline;cursor:pointer;">'+value+'</a>';
				       		},
					    },{
					        field: '指标维度',
					        title: '指标维度',
					        align: 'center',
					        valign: 'middle',
					        rowspan: 2,
					        colspan: 1
					    },{
					        field: '月汇总',
					        title: '月汇总',
					        align: 'center',
					        valign: 'middle',
					        colspan: 5,
					        rowspan: 1
					    },{
					        field: '周汇总',
					        title: '周汇总',
					        align: 'center',
					        valign: 'middle',
					        colspan: 5,
					        rowspan: 1
					    },{
					        field: '指标后十重点网点',
					        title: '指标后十重点网点',
					        align: 'center',
					        valign: 'middle',
					        rowspan: 2,
					        colspan: 1
					    }
					],
				    [	{
					        field: '目标值',
					        title: '目标值',
					        align: 'center',
					        valign: 'middle',
					    },{
					        field: time_arr[2]+'月',
					        title: time_arr[2]+'月',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat
					    },{
					        field: time_arr[1]+'月',
					        title: time_arr[1]+'月',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,
					    },{
					        field: time_arr[0]+'月累计',
					        title: time_arr[0]+'月累计',
					        align: 'center',
					        valign: 'middle',
				     		formatter:cellformat,
						    		     
					    },{
					        field: '环比'+time_arr[1]+'月',
					        title: '环比'+time_arr[1]+'月',
					        align: 'center',
					        valign: 'middle',
					    },{
					        field: time_arr[0]+'月第一周',
					        title: time_arr[0]+'月第一周',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,
					    },{
					        field: time_arr[0]+'月第二周',
					        title: time_arr[0]+'月第二周',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,
					    },{
					        field: time_arr[0]+'月第三周',
					        title: time_arr[0]+'月第三周',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,
					    },{
					   		field: time_arr[0]+'月第四周',
					        title: time_arr[0]+'月第四周',
					        align: 'center',
					        valign: 'middle',
					        formatter:cellformat,
					   },{
					   		field: '周环比趋势',
					        title: '周环比趋势',
					        align: 'center',
					        valign: 'middle',
					   }
				    ]
			      ],
		data: datas ,
		onClickRow: function(row, element){
			$('.success').removeClass('success');//去除之前样式
			$(element).addClass('success');//添加当前选中的
			$(".success").css("background-color");//保存之前的颜色
		},
		onClickCell:function(field,value,row,element){
			if(field=='指标项'){
				window.location.href='y2?index='+encodeURI(row['指标项']);
			}
		},
		
	});
	function cellformat(value,row,index){  
		if(!value|| value=='-') return '';
		if(row['指标维度']=='正向'){
		    if(parseFloat(value.replace(/%/, ""))>=row['目标值'].replace(/%/,"")){  
		    	return get_color(value,1);
		    }else if(parseFloat(value.replace(/%/, ""))>=(row['目标值'].replace(/%/,""))*0.9){ 
		    	return get_color(value,2);
		    }else{
		    	return get_color(value,0);
		    }
		}else{
			if(parseFloat(value.replace(/%/, ""))<=row['目标值'].replace(/%/,"")){  
				return get_color(value,1);
		    }else if(parseFloat(value.replace(/%/, ""))<=(row['目标值'].replace(/%/,""))*1.1){ 
		    	return get_color(value,2);
		    }else{ 
		    	return get_color(value,0);
		    }
		}
	};

	$(".show_detail").hover(function(){
    	$('.detail').css("display","block");
    },function(){
    	$('.detail').css("display","none");
  	});
};

</script>
</head>
<body>
<?php require '../home/header.php';?>
<div id="search-field">
	<i class="icon-flag icon-2x" style="color:red;"></i>: 小于90%目标值
	<i class="icon-flag icon-2x" style="color:#00f;"></i>: 90%目标~目标值
	<i class="icon-flag icon-2x" style="color:green;"></i><span class="icons">: 大于等于目标值</span>
	
	<input type="text"  id="time" />&nbsp;&nbsp;
	<select id="select1">
		<option>广州区</option>
	</select>&nbsp;&nbsp;
	<select id="select2">
		  <option  selected="selected">广州区</option>
		  <option>小友战队</option>
		  <option>成钦战队</option>
		  <option>海山战队</option>
		  <option>浩昌战队</option>
		  <option>永超战队</option>
		  <option>张悦战队</option>
	</select>&nbsp;&nbsp;
	<select id="select3">
	</select>&nbsp;&nbsp;
 	<input type="button" id='btn' value="查询">&nbsp;&nbsp;
 	<i id='icon'></i>
</div>
<table id="table"  data-classes="table table-bordered" ></table> 

<?php include_once('../home/footer.php');?>

</html>

