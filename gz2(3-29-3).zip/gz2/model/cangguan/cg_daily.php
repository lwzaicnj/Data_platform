<?php 
require '../../includes/public_inc_func.php';
cookie_location('../../cas_index.php');

include_once '../../includes/public_db_func.php';
$rs_arr = get_targets();//获取指标信息

$unique_id = addslashes($_COOKIE['unique_id']);
$user_info = get_user($unique_id);

$wd_details = get_infos(); //获取点部信息
$auth_de = get_pqfb($wd_details,$user_info[3]);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>广州数据平台</title>
<?php 
require '../../includes/header_inner.php';
?>
<script type="text/javascript" >
$(function(){ 
	type = <?php echo html_trim(json_encode($rs_arr));?>;
 	index = location.href; //取得整个地址栏
   	var num=index.indexOf("?")
   	index=decodeURI(index.substr(num+1)).split("=")[1]; //获取对应的行参数
  	if(!index) index = "滞留件解决率";

  	target = type[index][6];

   	// var ob_datas = new Array();
 	var areas = <?php echo html_trim(json_encode($auth_de));?>;

 	userinfo = <?php echo html_trim(json_encode($user_info));?>;
  	
	$('#btn').click(function(){
		var time = $("#time").val();
		var time1 = $("#time1").val();
		$.ajax({ 
			contentType: "application/x-www-form-urlencoded; charset=utf-8", 
			url: "../../table/cangguan/cangguan_daily_table.php",  
			type: "POST",       
			traditional: true,  
			data:{"time":time.toString(),"time1":time1.toString(),"index":index.toString(),"pq":userinfo[3]},  
			error: function(){      
				alert('请求超时');  
			},
			beforeSend:function(){
				$("#btn").attr({ disabled: "disabled" });  
				 $("#icon").addClass("fa fa-circle-o-notch fa-spin");
			},
			complete:function(){
				$("#icon").removeClass("fa fa-circle-o-notch fa-spin");
				$("#btn").removeAttr("disabled");
			},
			success:function (data){  //
				var de_json;
				// alert(data);
				if(data) de_json=eval("("+data+")");  
				for(var i in de_json){
					for(var k in de_json[i])
						areas[i][k] = de_json[i][k];
				}
				$('#table').bootstrapTable('load', areas);
			}    
		});

	});
	
	$('#time').jeDate({
        isinitVal:true,
        format: 'YYYY-MM-DD',
        //点击确定的回调
        okfun:function(elem, val) {
        	$("#table").bootstrapTable('destroy'); 
			show(areas);
        },
        //选中日期的回调
        choosefun:function(elem, val) {
        	$("#table").bootstrapTable('destroy'); 
			show(areas);
        },
    });

    $('#time1').jeDate({
        isinitVal:true,
        format: 'YYYY-MM-DD',
        initAddVal: {DD:"-2"},
        //点击确定的回调
        okfun:function(elem, val) {
        	$("#table").bootstrapTable('destroy'); 
			show(areas);
        },
        //选中日期的回调
        choosefun:function(elem, val) {
        	$("#table").bootstrapTable('destroy'); 
			show(areas);
        },
    });
	//初始化时间后加载数据
    show(areas);

    //导出动作
	$('div.export').click(function(){
		 var time = $("#time").val();
		 var time1 = $("#time1").val();
		 $.ajax({
			url: "../../table/download/download_action.php",  
			type: "POST",        
			data:{"action":"【下载"+index+"下"+time1+"到"+time+"数据】"},  
			error: function(){      
				alert('请求超时');  
			},  
			success:function (data){ 
				var de_json;
				if(data) de_json=eval("("+data+")");
			}    
		});
	});

});

function get_pre_day(now){
	var select=new Date(now);
	var t=select.getTime()-1000*60*60*24;
	var yesterday=new Date(t);
	var time_1 = yesterday.getFullYear()+'-'+(yesterday.getMonth()+1)+'-'+(yesterday.getDate()>9?yesterday.getDate():'0'+yesterday.getDate());
	return time_1;
}

function show(datas){
	var time = $("#time").val();
	var time1 = $("#time1").val();
	var month = time.substr(5,2)-0;//去0
	var month1 = time1.substr(5,2)-0;//去0
	if(month!=month1){
		alert("必须统一月份!");
		// window.location.href = 'cg_daily.php?index='+index;
	}

	var day = time.substr(8,2)-0;
	var day1 = time1.substr(8,2)-0;
	// var select=new Date(time);
	// var time_1 = get_pre_day(time);

	var date_inter = day-day1;
	//创建日期长度的数组
	if(date_inter<=0){
		alert('时间选择错误');
		window.location.href = 'y3.php?index='+encodeURI(index);
	}
	var a = new Array(date_inter+1);
	var date_len = a.length;

	var row_1 = new Array();
	row_1[0] = {
	    			field: '',
			        title: '',
			        align: 'center',
			        valign: 'middle',
			        rowspan: 1,
			        colspan: 2,
				};

	var row_2 = [	{
			    		field: '分部代码',
				        title: '分部代码',
				        align: 'center',
				        valign: 'middle',
				         rowspan: 1,
			        	colspan: 1,

			    	},{
			    		field: '分部名称',
				        title: '分部名称',
				        align: 'center',
				        valign: 'middle',
				        rowspan: 1,
			        	colspan: 1,
			    	}
				];

	var dte = time;
	var row_index = day-date_len;
	for(var i=date_len;i>0;i--){
		row_1[i] = {
	    			field: dte,
			        title: dte,
			        align: 'center',
			        valign: 'middle',
			        rowspan: 1,
			        colspan: 3,
				};
		row_2[i*3-1] = {
			    		field: type[index][0]+(row_index+i),
				        title: type[index][0],
				        align: 'center',
				        valign: 'middle',
				        rowspan: 1,
			        	colspan: 1,
				    	};
		row_2[i*3] = {
			    			field: type[index][1]+(row_index+i),
					        title: type[index][1],
					        align: 'center',
					        valign: 'middle',
					        rowspan: 1,
			        		colspan: 1,
				    	};
		row_2[i*3+1] = {
			    			field: index+(row_index+i),//区分
					        title: index,
					        align: 'center',
					        valign: 'middle',
					        rowspan: 1,
			        		colspan: 1,
			        		formatter:cellformat,
				    	};

		dte = get_pre_day(dte);
	}

	// alert(type[index][0]+(day+1));
	var cols = date_len +1;//最后累计
	row_1[cols] = {
						field: month+'月累计',
				        title: month+'月累计',
				        align: 'center',
				        valign: 'middle',
				        rowspan: 1,
				        colspan: 3,
					};

	row_2[cols*3-1] = {
			    		field: type[index][0]+(day+1),//比最大日期多1
				        title: type[index][0],
				        align: 'center',
				        valign: 'middle',
				        rowspan: 1,
			        	colspan: 1,
				    	};
	row_2[cols*3] = {
		    			field: type[index][1]+(day+1),
				        title: type[index][1],
				        align: 'center',
				        valign: 'middle',
				         rowspan: 1,
			        	colspan: 1,
			    	};
	row_2[cols*3+1] = {
		    			field: index+(day+1),//区分
				        title: index,
				        align: 'center',
				        valign: 'middle',
				         rowspan: 1,
			        	colspan: 1,
			        	formatter:cellformat,
			    	};


	$('#table').bootstrapTable({
		showExport: true,
		search:true,searchAlign:'left',
		pagination: true,pageSize:15,
		height:800,striped: true,
		exportDataType: "all",
		buttonsAlign: 'right',
		exportTypes:['excel'], 
	    columns: [
		    		row_1,
				    row_2,
			      ],
		data: datas ,
	});
	function cellformat(value,row,index){  
		if(!value|| value=='-') return '';
		if(target>0.3){
		    if(parseFloat(value.replace(/%/, "")/100)>=target){  
		    	return get_color(value,1);
		    }else if(parseFloat(value.replace(/%/, "")/100)>=target*0.9){ 
		    	return get_color(value,2);
		    }else{
		    	return get_color(value,0);
		    }
		}else{
			if(parseFloat(value.replace(/%/, "")/100)<=target){  
		    	return get_color(value,1);
		    }else if(parseFloat(value.replace(/%/, "")/100)>=target*1.1){ 
		    	return get_color(value,2);
		    }else{ 
		    	return get_color(value,0);
		    }
		}
	};
};

</script>
</head>
<body>
<?php require '../home/header.php';?>
<div id="search-field" align="center">
<span>目标:<?php echo html_trim($rs_arr[urldecode($_GET['index'])][6]*100).'%';?></span>
<i class="icon-flag icon-2x" style="color:red;"></i>: 小于90%目标值
<i class="icon-flag icon-2x" style="color:#00f;"></i>: 90%目标~目标值
<i class="icon-flag icon-2x" style="color:green;"></i><span class="icons">: 大于等于目标值</span>
 
 <input type="text"  id="time1" />&nbsp;-&nbsp;
 <input type="text"  id="time" />&nbsp;&nbsp;
 <input type="button" id='btn' value="查询">&nbsp;&nbsp;
 <i id='icon'></i> <!--显示加载进度-->
</div>

<!-- style="display: none;"-->
<table id="table"  data-classes="table table-bordered"></table> 
<div style="height: 20px;"></div>
<?php include_once('../home/footer.php');?>
</body>
</html>

