<?php 
require '../../includes/public_inc_func.php';
cookie_location('../../cas_index.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>广州数据平台</title>
<?php
require '../../includes/header_inner.php';
?>
<link rel="stylesheet" type="text/css" href="../../css/manage.css">

<script type="text/javascript">
	$(function(){
		
		$('#table_b').bootstrapTable({
			height: 730,
			cache: false,
		    columns: [
			    		[  {
						        field: '工号',
						        title: '工号',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '姓名',
						        title: '姓名',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '部门',
						        title: '部门',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '操作',
						        title: '操作',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '浏览器',
						        title: '浏览器',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '时间',  
				                title: '时间',  
				                align: 'center', 
				                valign: 'middle',
				                sortable:true,
				            } 
						]
					],
			onClickRow: function(row, element){
				$('.success').removeClass('success');//去除之前样式
				$(element).addClass('success');//添加当前选中的
				$(".success").css("background-color");//保存之前的颜色

			},
		});

		//获取数据
		$.ajax({
			url: "../../table/manage/manage_log.php",  
			type: "POST",       
			error: function(){      
				alert('读取指标信息失败'); 
			},  
			success:function (data){  
				// alert(data);
				var de_json;
				if(data) de_json=eval("("+data+")");  
				$('#table_b').bootstrapTable('load', de_json);
			},   

		});
	});



</script>

</head>
<body>
<?php require '../home/header.php';?>

<div id='content'>
<div id="table3">
	<table id="table_b" data-classes="table table-bordered"></table>
</div>

<?php include_once('../home/footer.php');?>
</body>
</html>
