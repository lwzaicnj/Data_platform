<?php 
include_once '../../includes/public_inc_func.php';
include_once '../../PHPExcel/Classes/PHPExcel/IOFactory.php';
include_once '../../includes/public_db_func.php';
include_once '../../class/manageClass.php';

ini_set('date.timezone','UTC');

cookie_location('../../cas_index.php');

$allowedExts = array("xlsx", "xls");// 允许上传的文件后缀

//可以分离成为一个下载和上传文件模块
if(isset($_FILES['myfile'])){
	if($_SERVER['REQUEST_METHOD'] == 'POST' && $_FILES['myfile']['error']==0){
	    $temp = explode(".", $_FILES["myfile"]["name"]);
	    $extension = addslashes(end($temp));
	    if(in_array($extension, $allowedExts)){
		
		$file_name2='tmp.xlsx';		

	        // 如果 upload 目录不存在该文件则将文件上传到 upload 目录下 777权限
	        // echo "文件临时存储的位置: " . $_FILES["myfile"]["tmp_name"] . "<br>";
	        move_uploaded_file($_FILES["myfile"]["tmp_name"], "../../upload/".$file_name2);

	        $inputFileName = "../../upload/".$file_name2;
	        try {
				$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
				$objReader = PHPExcel_IOFactory::createReader($inputFileType);
				$objPHPExcel = $objReader->load($inputFileName);
			} catch(Exception $e) {
				die('加载文件发生错误：'.pathinfo($inputFileName,PATHINFO_BASENAME).':' .$e->getMessage());
			}

			// 确定要读取的sheet
			$sheet = $objPHPExcel->getSheet(0);
			$highestRow = $sheet->getHighestRow();
			$highestColumn = $sheet->getHighestColumn();

			// 获取一行的数据
			for ($row = 1; $row <= $highestRow; $row++){
				// Read a row of data into an array
				$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);

				$rowData = sql_trim($rowData[0]);//取第一个数据

				if(count($rowData)==15 && $rowData[3]!="分部代码"){
					//这里得到的rowData都是一行的数据，得到数据后处理
					$sql_db = new sql("sqlxz2012","IT_test");
					
					$sql_c = "SELECT TOP 1 * FROM dbo.it_report WHERE 分部代码='".sql_trim($rowData[3])."'";
					$result_c = $sql_db->query($sql_c);
					$rs = $sql_db->fetch_arr($result_c);//第一个

					if($rs){
						$rss = '重复指标';
					}else{
						$sql = "INSERT INTO dbo.it_report (分类,[18年片区],[18年新片区],分部代码,分部名称,收件量,净收入,年收件量,年净收入,重货快运,物流普运,国际件,保价,代收服务费,代收运费,时间) VALUES ('".$rowData[0]."','".$rowData[1]."','".$rowData[2]."','".$rowData[3]."','".$rowData[4]."','".$rowData[5]."','".$rowData[6]."','".$rowData[7]."','".$rowData[8]."','".$rowData[9]."','".$rowData[10]."','".$rowData[11]."','".$rowData[12]."','".$rowData[13]."','".$rowData[14]."','".date('Y-m-d H:i:s')."')";
						$result = $sql_db->query($sql);
						@session_start();
						$_SESSION['manage']->useraction = "增加[市场指标管理]里面[{$rowData[3]}]";
						$_SESSION['manage']->saveAction();
					}
				}
				
			}

			//删除文件
			unlink($inputFileName);
	    }
	}
}

function downfile() {  
         $filename=realpath("../../template/template.xlsx"); //文件名  
         Header( "Content-type:  application/octet-stream ");   
         Header( "Accept-Ranges:  bytes ");   
         Header( "Accept-Length: " .filesize($filename));  
         header( "Content-Disposition:  attachment;  filename= temp.xlsx");   
         readfile($filename);   
 }  
if(isset($_POST['down']) && $_POST['down']=="111"){
	downfile();  
}



?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>广州数据平台</title>
<?php
require '../../includes/header_inner.php';
?>
<link rel="stylesheet" type="text/css" href="../../css/manage.css">
<script type="text/javascript" src="../../js/home/home.js"></script>
<!--bootstrap-->
<!-- <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet"> -->
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>  

<link rel="stylesheet" type="text/css" href="../../x-editable/dist/bootstrap-editable/css/bootstrap-editable.css">
<script src="../../x-editable/dist/bootstrap-editable/js/bootstrap-editable.js"></script>

<script type="text/javascript">
	$(function(){
		filed_name = "";//保存修改的列field名		
		$('#table_p').bootstrapTable({
			pagination: true,pageSize:15,
			cache: false,
		    columns: [
			    		[  {
						        field: '分类',
						        title: '分类',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '18年片区',
						        title: '18年片区',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '18年新片区',
						        title: '18年新片区',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '分部代码',
						        title: '分部代码',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '分部名称',
						        title: '分部名称',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '收件量',
						        title: '收件量',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中时间字段\">" + value + "</a>";
				                }
						    },{
						        field: '净收入',
						        title: '净收入',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中点部字段\">" + value + "</a>";}
						    },{
						        field: '年收件量',
						        title: '年收件量',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中时间字段\">" + value + "</a>";
				                }
						    },{
						        field: '年净收入',
						        title: '年净收入',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中点部字段\">" + value + "</a>";}
						    },{
						        field: '重货快运',
						        title: '重货快运',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中点部字段\">" + value + "</a>";}
						    },{
						        field: '物流普运',
						        title: '物流普运',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中点部字段\">" + value + "</a>";}
						    },{
						        field: '国际件',
						        title: '国际件',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中点部字段\">" + value + "</a>";}
						    },{
						        field: '保价',
						        title: '保价',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中点部字段\">" + value + "</a>";}
						    },{
						        field: '代收服务费',
						        title: '代收服务费',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中点部字段\">" + value + "</a>";}
						    },{
						        field: '代收运费',
						        title: '代收运费',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中点部字段\">" + value + "</a>";}
						    },{
						        field: 'operate',  
				                title: '操作',  
				                align: 'center',  
				                events: operateEvents,  
				                formatter: operateFormatter  
						    }
						]
					],
			onClickRow: function(row, element,field){
				filed_name = field;
				$('.success').removeClass('success');//去除之前样式
				$(element).addClass('success');//添加当前选中的
				$(".success").css("background-color");//保存之前的颜色

			},
		});

		//获取数据
		ajaxcan("../../table/manage/manage_report.php",{},"POST", function(){      
				alert('读取指标信息失败'); 
			},function(data){
				var de_json;
				if(data) de_json=eval("("+data+")");  
				$('#table_p').bootstrapTable('load', de_json);
		});

		//新增
		$('#btn').click(function(){
			document.getElementById('light').style.display='block';
		});

	});

	function operateFormatter(value, row, index) {  
	        return [  
	        	'<a class="edits" href="javascript:void(0)" title="修改">',  
	            '<i class="glyphicon glyphicon-edit"></i>',  
	            '</a>  ',
	            '<a class="remove" href="javascript:void(0)" title="删除">',  
	            '<i class="glyphicon glyphicon-remove"></i>',  
	            '</a>  ',  
	            '<a class="save" href="javascript:void(0)" title="保存">',  
	            '<i class="glyphicon glyphicon-ok"></i>',  
	            '</a>'  
	        ].join('');  
	};
	window.operateEvents = {  
	    'click .remove': function (e, value, row, index) { 
	      var d = window.confirm("确定要删除?");
	      if(d){
		      //确认删除项设定 
		      $('#table_p').bootstrapTable('remove', {field: '分部代码', values: [row['分部代码']]});
		      ajaxcan("../../table/manage/delete_report.php",{'data':row['分部代码']},"POST", function(){      
				alert('删除失败'); 
			},function(data){
				var de_json;
				if(data) de_json=eval("("+data+")");
				if(de_json['rs']=='true'){
					//刷新表格
					alert('删除成功');
				}
				else{
					alert(de_json['rs']);
				}

			});
		   }
	    }, 
	    'click .edits': function (e, value, row, index) {
	    	$("#table_p a.edit").editable({
					type: 'text',
				    title: 'Enter username',
				    success: function(response, newValue) {
				   	row[filed_name] = newValue;
				    	$("#table_p").bootstrapTable('updateRow', {index: index, row: row}); 
				   } 
				});
	    	// $("#table_b a.edit").editable('enable');
	    },
	    //x-edit后进行保存
	    'click .save': function (e, value, row, index) {
	    	var data = new Array();
	    	$.each(row, function(idx, obj) {  
					data.push(obj);
			});

	    	ajaxcan("../../table/manage/update_report.php",{'data':data},"POST", function(){ 
				alert('保存失败'); 
			},function(data){
				var de_json;
				// alert(data);
				if(data) de_json=eval("("+data+")");
				if(de_json['rs']=='true'){
					//刷新表格
					alert('保存成功');
				}
				else{
					alert(de_json['rs']);
				}
			});
	    }  
	}; 

	function CheckPost(){
		post_form = [addForm.t1.value,addForm.t2.value,addForm.t3.value,addForm.t4.value,addForm.t5.value,addForm.t6.value,addForm.t7.value,addForm.t8.value,addForm.t9.value,addForm.t10.value,addForm.t11.value,addForm.t12.value,addForm.t13.value,addForm.t14.value,addForm.t15.value];

		for(var i=0;i<post_form.length;i++){
		    if (post_form[i]==""){
		          alert("请填写完整数据！");
		          return false;
		     }
		}
		ajaxcan("../../table/manage/save_report.php",{'data':post_form},"POST", function(){ 
				alert('添加失败');
				$("#msgview").html('<span style="color:red">保存失败</span>');
				window.location.href = 'm3';
			},function(data){
				if(data) de_json=eval("("+data+")");
				if(de_json['rs']=='true'){
					//刷新表格
					$("#msgview").html('<span style="color:green">保存成功</span>');
					window.location.href = 'm3';
				}
				else{
					alert(de_json['rs']);
					// alert('数据添加失败！');
				}
		});
	    return false;
	};

	function cancle(){
		window.location.href = 'm3';
	}

</script>

</head>
<body>
<?php require '../home/header.php';?>

<div id='content'>
<div id='btn'><span id="msgview"></span>&nbsp;<button class="btn1" type="button">新增</button></div>
<div id="table3">
	<table id="table_p" data-classes="table table-bordered"></table>
</div>
<div id="light" class="window_content">
	<form action="m3" method="post" name="download">
		<input type="text" name="down" value="111" style="display: none">
		<input type="submit" name="submit" value="模板下载">
	</form>
	<form action="m3" method="post" enctype="multipart/form-data" >
		<input type="file" name="myfile" id="file">
		<input type="submit" name="submit" value="上传">
	</form>
	-------------------------------------------------------------------------------------
	<form action="m3" method="post" name="addForm"  onsubmit="return CheckPost();">
     	<div><span class='ivalue'>分类:</span><input class='ip' type="text" name="t1" maxlength="20"/></div>
     <div><span class='ivalue'>18年片区:</span><input class='ip' type="text" name="t2" maxlength="50"/></div>
     <div><span class='ivalue'>18年新片区:</span><input class='ip' type="text" name="t3" maxlength="50"/></div>
     <div><span class='ivalue'>分部代码:</span><input class='ip' type="text" name="t4" maxlength="50"/></div>
     <div><span class='ivalue'>分部名称:</span><input class='ip' type="text" name="t5" maxlength="50"/></div>
     <div><span class='ivalue'>收件量:</span><input class='ip' type="text" name="t6" maxlength="50"/></div>
     <div><span class='ivalue'>净收入:</span><input class='ip' type="text" name="t7" maxlength="50"/></div>
     <div><span class='ivalue'>年收件量:</span><input class='ip' type="text" name="t8" maxlength="50"/></div>
     <div><span class='ivalue'>年净收入:</span><input class='ip' type="text" name="t9" maxlength="50"/></div>
     <div><span class='ivalue'>重货快运:</span><input class='ip' type="text" name="t10" maxlength="50"/></div>
     <div><span class='ivalue'>物流普运:</span><input class='ip' type="text" name="t11" maxlength="50"/></div>
     <div><span class='ivalue'>国际件:</span><input class='ip' type="text" name="t12" maxlength="50"/></div>
     <div><span class='ivalue'>保价:</span><input class='ip' type="text" name="t13" maxlength="50"/></div>
     <div><span class='ivalue'>代收服务费:</span><input class='ip' type="text" name="t14" maxlength="50"/></div>
     <div><span class='ivalue'>代收运费:</span><input class='ip' type="text" name="t15" maxlength="50"/></div>
	<div>
           <input type="submit" name="submit" value="确定"/>
           <input type="button" onclick="cancle()" value="取消"/>
     </div>
     
</form>
</div> 

<?php include_once('../home/footer.php');?>
</body>
</html>
