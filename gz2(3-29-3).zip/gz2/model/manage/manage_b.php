<?php 
require '../../includes/public_inc_func.php';
cookie_location('../../cas_index.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>广州数据平台</title>
<?php
require '../../includes/header_inner.php';
?>
<link rel="stylesheet" type="text/css" href="../../css/manage.css">
<script type="text/javascript" src="../../js/home/home.js"></script>

<!--bootstrap-->
<!-- <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet"> -->
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>  

<link rel="stylesheet" type="text/css" href="../../x-editable/dist/bootstrap-editable/css/bootstrap-editable.css">
<script src="../../x-editable/dist/bootstrap-editable/js/bootstrap-editable.js"></script>

<script type="text/javascript">
	$(function(){
		filed_name  = "";		
		$('#table_b').bootstrapTable({
			height: 730,
			cache: false,
		    columns: [
			    		[  {
						        field: '指标项',
						        title: '指标项',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '目标值',
						        title: '目标值',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中时间字段\">" + value + "</a>";
				                }
						    },{
						        field: '指标分子',
						        title: '指标比例分子',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '指标分母',
						        title: '指标比例分母',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '表名',
						        title: '指标数据源表名',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '时间',
						        title: '表中时间字段',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中时间字段\">" + value + "</a>";
				                }
						    },{
						        field: '分部',
						        title: '表中点部字段',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中点部字段\">" + value + "</a>";}
						    },{
						        field: 'operate',  
				                title: '操作',  
				                align: 'center',  
				                events: operateEvents,  
				                formatter: operateFormatter  
						    }
						]
					],
			onClickRow: function(row, element,field){
				filed_name = field;
				$('.success').removeClass('success');//去除之前样式
				$(element).addClass('success');//添加当前选中的
				$(".success").css("background-color");//保存之前的颜色

			},
		});

		

		//获取数据
		ajaxcan("../../table/manage/manage_target.php",{},"POST",0,function(data){
			var de_json;
			if(data) de_json=eval("("+data+")");  
			$('#table_b').bootstrapTable('load', de_json);
		});

		//新增
		$('#btn').click(function(){
			document.getElementById('light').style.display='block';
		});

	});

	function operateFormatter(value, row, index) {  
	        return [  
	        	'<a class="edits" href="javascript:void(0)" title="修改">',  
	            '<i class="glyphicon glyphicon-edit"></i>',  
	            '</a>  ',
	            '<a class="remove" href="javascript:void(0)" title="删除">',  
	            '<i class="glyphicon glyphicon-remove"></i>',  
	            '</a>  ',  
	            '<a class="save" href="javascript:void(0)" title="保存">',  
	            '<i class="glyphicon glyphicon-ok"></i>',  
	            '</a>'  
	        ].join('');  
	};
	window.operateEvents = {  
	    'click .remove': function (e, value, row, index) { 
	      var d = window.confirm("确定要删除?");
	      if(d){	
		      //确认删除项设定 
		      $('#table_b').bootstrapTable('remove', {field: '指标项', values: [row['指标项']]});
		      ajaxcan("../../table/manage/delete_target.php",{'data':row['指标项']},"POST",0,function(data){
		      		var de_json;
					if(data) de_json=eval("("+data+")");
					if(de_json['rs']=='true'){
						//刷新表格
						alert('删除成功');
					}
					else{
						alert(de_json['rs']);
					}
		      });
		   }
	    }, 
	    'click .edits': function (e, value, row, index) {
			// alert(index);
	    	$("#table_b a.edit").editable({
					type: 'text',
				    title: 'Enter username',
				    success: function(response, newValue) {
					row[filed_name] = newValue;
				    	$("#table_b").bootstrapTable('updateRow', {index: index, row: row});				
				    } 
				});
	    	// $("#table_b a.edit").editable('enable');
	    },
	    //x-edit后进行保存
	    'click .save': function (e, value, row, index) {
	    	// var a = $('#table_b a.edit').editable('getValue');
	    	// $("#table_b a.edit").editable('disable');
	    	var data = new Array();
	    	$.each(row, function(idx, obj) {  
					data.push(obj);
			});

	    	// alert(data);
	    	ajaxcan("../../table/manage/update_target.php",{'data':data},"POST",function(){ 
				alert('保存失败');},function(data){
	    			var de_json;
					// alert(data);
					if(data) de_json=eval("("+data+")");
					if(de_json['rs']=='true'){
						//刷新表格
						alert('保存成功');
					}
					else{
						alert(de_json['rs']);
					}
	    	});
	    }  
	}; 

	function CheckPost(){
		post_form = [addForm.t1.value,addForm.t2.value,addForm.t3.value,addForm.t4.value,addForm.t5.value,addForm.t6.value,addForm.t7.value];

		for(var i=0;i<post_form.length;i++){
		    if (post_form[i]==""){
		          alert("请填写完整数据！");
		          // addForm.username.focus();
		          return false;
		     }
		}
		ajaxcan("../../table/manage/save_target.php",{'data':post_form},"POST",function(){ 
				alert('添加失败');
				$("#msgview").html('<span style="color:cokor">保存失败</span>');
				window.location.href = 'm2';},
		function(data){
			var de_json;
			if(data) de_json=eval("("+data+")");
			if(de_json['rs']=='true'){
				//刷新表格
				$("#msgview").html('<span style="color:green">保存成功</span>');
				window.location.href = 'm2';
			}
			else{
				alert(de_json['rs']);
				// alert('数据添加失败！');
			}
		});
	  //   $.ajax({
	  //    	url: "../../table/manage/save_target.php",  
			// type: "POST", 
			// data:{'data':post_form},   
			// error: function(){      
			// 	alert('添加失败');
			// 	$("#msgview").html('<span style="color:cokor">保存失败</span>');
			// 	window.location.href = 'manage_b.php';
			// },  
			// success:function (data){ 
			// 	var de_json;
			// 	if(data) de_json=eval("("+data+")");
			// 	if(de_json['rs']=='true'){
			// 		//刷新表格
			// 		$("#msgview").html('<span style="color:green">保存成功</span>');
			// 		window.location.href = 'manage_b.php';
			// 	}
			// 	else{
			// 		alert(de_json['rs']);
			// 		// alert('数据添加失败！');
			// 	}
			// },  
	  //    });
	    return false;
	};

	function cancle(){
		window.location.href = 'm2';
	}

</script>

</head>
<body>
<?php require '../home/header.php';?>

<div id='content'>
<div id='btn'><span id="msgview"></span>&nbsp;<button class="btn1" type="button">新增</button></div>
<div id="table3">
	<table id="table_b" data-classes="table table-bordered"></table>
</div>
<div id="light" class="window_content">
	<form action="m2" method="post" name="addForm"  onsubmit="return CheckPost();">
     	<div><span class='ivalue'>指标项:</span><input class='ip' type="text" name="t1" maxlength="20"/></div>
     <div><span class='ivalue'>目标值:</span><input class='ip' type="text" name="t2" maxlength="50"/></div>
     <div><span class='ivalue'>指标比例分子:</span><input class='ip' type="text" name="t3" maxlength="50"/></div>
     <div><span class='ivalue'>指标比例分母:</span><input class='ip' type="text" name="t4" maxlength="50"/></div>
     <div><span class='ivalue'>指标数据源表名:</span><input class='ip' type="text" name="t5" maxlength="50"/></div>
     <div><span class='ivalue'>表中时间字段名:</span><input class='ip' type="text" name="t6" maxlength="50"/></div>
     <div><span class='ivalue'>表中点部字段名:</span><input class='ip' type="text" name="t7" maxlength="50"/></div>
	<div>
           <input type="submit" name="submit" value="确定"/>
           <input type="button" onclick="cancle()" value="取消"/>
     </div>
</form>
</div> 

<?php include_once('../home/footer.php');?>
</body>
</html>
