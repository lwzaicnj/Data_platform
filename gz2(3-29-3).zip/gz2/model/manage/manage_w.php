<?php 
require '../../includes/public_inc_func.php';
cookie_location('../../cas_index.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>广州数据平台</title>
<?php
require '../../includes/header_inner.php';
?>
<link rel="stylesheet" type="text/css" href="../../css/manage.css">
<script type="text/javascript" src="../../js/home/home.js"></script>

<!-- <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet"> -->
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>  

<link rel="stylesheet" type="text/css" href="../../x-editable/dist/bootstrap-editable/css/bootstrap-editable.css">
<script src="../../x-editable/dist/bootstrap-editable/js/bootstrap-editable.js"></script>
<script type="text/javascript">
	$(function(){
		filed_name = "";	
		$('#table_b').bootstrapTable({
			height: 730,
			pagination: true,pageSize:17,
			cache: false,
		    columns: [
			    		[  {
						        field: '分部名称',
						        title: '分部名称',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '分部简称',
						        title: '分部简称',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '分部代码',
						        title: '分部代码',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '所属片区',
						        title: '所属片区',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"所属片区\">" + value + "</a>";}
						    },{
						        field: '上级代码',//暂时是点部和分部，上级都是广州大区
						        title: '上级代码',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"上级代码\">" + value + "</a>";}
						    },{
						        field: 'operate',  
				                title: '操作',  
				                align: 'center',  
				                events: operateEvents,  
				                formatter: operateFormatter  
						    }
						]
					],
			onClickRow: function(row, element,field){
				filed_name = field;
				$('.success').removeClass('success');//去除之前样式
				$(element).addClass('success');//添加当前选中的
				$(".success").css("background-color");//保存之前的颜色

			},
		});

		//获取数据
		ajaxcan("../../table/manage/manage_wangdian.php",{},"POST", function(){     
					alert('读取指标信息失败');
			},function(data){
				var de_json;
				if(data) de_json=eval("("+data+")");  
				$('#table_b').bootstrapTable('load', de_json);
		});

		//新增
		$('#btn').click(function(){
			document.getElementById('light').style.display='block';
		});

	});

	function operateFormatter(value, row, index) {  
	        return [  
	        	'<a class="edits" href="javascript:void(0)" title="修改">',  
	            '<i class="glyphicon glyphicon-edit"></i>',  
	            '</a>  ',
	            '<a class="remove" href="javascript:void(0)" title="删除">',  
	            '<i class="glyphicon glyphicon-remove"></i>',  
	            '</a>  ',  
	            '<a class="save" href="javascript:void(0)" title="保存">',  
	            '<i class="glyphicon glyphicon-ok"></i>',  
	            '</a>'  
	        ].join('');  
	};
	window.operateEvents = {  
	    'click .remove': function (e, value, row, index) { 
	      var d = window.confirm("确定要删除?");
	      if(d){	
		      //确认删除项设定 
		      $('#table_b').bootstrapTable('remove', {field: '分部名称', values: [row['分部名称']]});
		      ajaxcan("../../table/manage/delete_wangdian.php",{'data':row['分部名称']},"POST", function(){     
					alert('删除失败');
			 },function(data){
			 		var de_json;
					if(data) de_json=eval("("+data+")");
					if(de_json['rs']=='true'){
						//刷新表格
						alert('删除成功');
					}
					else{
						alert(de_json['rs']);
					}
			 });
		   }
	    }, 
	    'click .edits': function (e, value, row, index) {
			// alert(index);
	    	$("#table_b a.edit").editable({
					type: 'text',
				    title: 'Enter username',
				    success: function(response, newValue) {
				        row[filed_name] = newValue;
				    	$("#table_b").bootstrapTable('updateRow', {index: index, row: row});
				    } 
				});
	    },
	    //x-edit后进行保存
	    'click .save': function (e, value, row, index) {
	    	// var a = $('#table_b a.edit').editable('getValue');
	    	// $("#table_b a.edit").editable('disable');
	    	var data = new Array();
	    	$.each(row, function(idx, obj) {  
					data.push(obj);
			});
	    	// alert(data);
	    	ajaxcan("../../table/manage/update_wangdian.php",{'data':data},"POST", function(){
					alert('保存失败');
			 },function(data){
			 		var de_json;
					if(data) de_json=eval("("+data+")");
					if(de_json['rs']=='true'){
						//刷新表格
						alert('保存成功');
					}
					else{
						alert(de_json['rs']);
					}
			 });
	    }  
	}; 

	function CheckPost(){
		// alert(addForm.t4.value);
		post_form = [addForm.t1.value,addForm.t2.value,addForm.t3.value,addForm.t4.value,addForm.t5.value];

		for(var i=0;i<post_form.length;i++){
		    if (post_form[i]==""){
		          alert("请填写完整数据！");
		          // addForm.username.focus();
		          return false;
		     }
		}
		ajaxcan("../../table/manage/save_wangdian.php",{'data':post_form},"POST", function(){
					alert('添加失败');
					window.location.href = 'm4';
			 },function(data){
			 	var de_json;
				if(data) de_json=eval("("+data+")");
				if(de_json['rs']=='true'){
					alert('新增成功');
					//刷新表格
					window.location.href = 'm4';
				}
				else{
					alert(de_json['rs']);
					// alert('数据添加失败！');
				}
		});
	    return false;
	};

	function cancle(){
		window.location.href = 'm4';
	}

</script>

</head>
<body>
<?php require '../home/header.php';?>

<div id='content'>
<div id='btn'><span id="msgview">&nbsp;</span><button class="btn1" type="button">新增</button></div>
<div id="table3">
	<table id="table_b" data-classes="table table-bordered"></table>
</div>
<div id="light" class="window_content">
	<form action="m4" method="post" name="addForm"  onsubmit="return CheckPost();">
     <div>分部名称:   <input type="text" name="t1" maxlength="50"/></div>
     <div>分部简称:  <input type="text" name="t2" maxlength="50"/></div>
     <div>分部代码:  <input type="text" name="t3" maxlength="50"/></div>
     <div>所属片区:  <select name="t4">
					  	  <option>大盘区</option>
						  <option>小友战队</option>
						  <option>成钦战队</option>
						  <option>海山战队</option>
						  <option>浩昌战队</option>
						  <option>永超战队</option>
						  <option>张悦战队</option>
						</select></div>
     <div>上级代码:  <input type="text" name="t5" maxlength="50"/></div>
     <div>
           <input type="submit" name="submit" value="确定"/>
           <input type="button" onclick="cancle()" value="取消"/>
     </div>
</form>
</div> 

<?php include_once('../home/footer.php');?>
</body>
</html>
