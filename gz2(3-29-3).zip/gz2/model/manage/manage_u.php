<?php 
require '../../includes/public_inc_func.php';
cookie_location('../../cas_index.php');


?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>广州数据平台</title>
<?php
require '../../includes/header_inner.php';
?>
<link rel="stylesheet" type="text/css" href="../../css/manage.css">

<script type="text/javascript" src="../../js/home/home.js"></script>

<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>  

<link rel="stylesheet" type="text/css" href="../../x-editable/dist/bootstrap-editable/css/bootstrap-editable.css">
<script src="../../x-editable/dist/bootstrap-editable/js/bootstrap-editable.js"></script>
<script type="text/javascript">
	$(function(){
		filed_name = "";//保存修改的列field名
		//存放选中用户的id
		user_id = "";
		//获取数据库的用户信息 和所有菜单信息
		ajaxcan("../../table/manage/manage_u.php",{},"POST", function(){      
				alert('读取用户信息失败'); 
			},function(data){
				var de_json;
				if(data) de_json=eval("("+data+")");  
				$('#table_u').bootstrapTable('load', de_json[0]);
				$('#table_m').bootstrapTable('load', de_json[1]);
		});
		$('#table_u').bootstrapTable({
			height: 730,
			cache: false,
		    columns: [
			    		[	{
						        field: 'checkStatus',
						        radio: true,
						        visible:false,
						    },{
						        field: '编号',
						        title: '编号',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '工号',
						        title: '工号',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '姓名',
						        title: '姓名',
						        align: 'center',
						        valign: 'middle',
							formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"表中时间字段\">" + value + "</a>";}
						    },{
						        field: '片区',//还是组？
						        title: '片区',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+1+"\" data-type=\"text\" data-pk=\""+row.Id+"\" data-title=\"所属片区\">" + value + "</a>";}
						    },{
						        field: '分部',//还是组？
						        title: '分部',
						        align: 'center',
						        valign: 'middle',
						        formatter: function (value, row, index,field) {
				                    return "<a class=\"edit\" href=\"#\" name=\""+value+2+"\" data-type=\"text\" data-title=\"所属片区\">" + value+"</a>";}
						    },{
						        field: 'operate',  
				                title: '操作',  
				                align: 'center',  
				                events: operateEvents,  
				                formatter: operateFormatter  
						    }
						]
					],
			onClickRow: function(row, element,field){
				filed_name = field;
				//双击行显示对应用户的权限菜单
				//选中当前用户
				$('#table_u').bootstrapTable('checkBy', {field:'编号', values:[row['编号']]});
				
				$('.success').removeClass('success');//去除之前样式
				$(element).addClass('success');//添加当前选中的
				$(".success").css("background-color");//保存之前的颜色

				user_id  = row['编号'];
				ajaxcan("../../table/manage/manage_u.php",{'id':row['编号']},"POST", function(){      
					alert('读取菜单信息失败'); 
				},function(data){
					//返回拥有权限的id,对应的编号上面的菜单打钩
					var de_json;
					//alert(data);
					if(data)
						de_json=eval("("+data+")");
					if(de_json.length!=0){
						$('#table_m').bootstrapTable('uncheckAll');	
						$('#table_m').bootstrapTable('checkBy', {field:'编号', values:de_json});
					}
					else
						$('#table_m').bootstrapTable('uncheckAll');	
				});
			},
		});

		//菜单
		$('#table_m').bootstrapTable({
			height: 730,
			// pagination: true,pageSize:20,
			cache: false, striped: true,
		    columns: [
			    		[	{
						        field: 'checkStatus',
						        checkbox: true,
						    },{
						        field: '编号',
						        title: '编号',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '菜单名',
						        title: '菜单名',
						        align: 'center',
						        valign: 'middle',
						    }
						]
					],
		});

		$('#btn').click(function(){
			//重复会一直保持之前的选中的顺序，最后一个就不是想要的
			// var selected_u = $('#table_u').bootstrapTable('getSelections');
			// alert(user_id);
			if(!user_id) {
				alert("请先选中用户");
				return false;//停止事件
			}
			var selected_m = $('#table_m').bootstrapTable('getAllSelections');
			var m_arr = [];
			for(var i in selected_m)
				m_arr[i] = selected_m[i]['编号'];//所有选中菜单编号
			//对应um存库
			ajaxcan("../../table/manage/save_um.php",{'uid':user_id,'mid':m_arr},"POST", function(){      
					$("#msgview").html('<span style="color:red">保存失败</span>');
			},function(data){
				//返回拥有权限的id,对应的编号上面的菜单打钩
				var de_json;
				//alert(data);
				$("#msgview").html('<span style="color:green">保存成功</span>');
			});
				
		});
		//新增
		$('#btn1').click(function(){
			document.getElementById('light').style.display='block';
		});

	});
	

	function operateFormatter(value, row, index) {  
	        return [  
	        	'<a class="edits" href="javascript:void(0)" title="修改">',  
	            '<i class="glyphicon glyphicon-edit"></i>',  
	            '</a>  ', 
	            '<a class="save" href="javascript:void(0)" title="保存">',  
	            '<i class="glyphicon glyphicon-ok"></i>',  
	            '</a>'  
	        ].join('');  
	};
	window.operateEvents = {  
	    'click .edits': function (e, value, row, index) {
	    	$("#table_u a.edit").editable({
					type: 'text',
				    title: 'Enter username',
				    success: function(response, newValue) {
					row[filed_name] = newValue;
				    	$("#table_u").bootstrapTable('updateRow', {index: index, row: row});		
				    } 
				});
	    },
	    //x-edit后进行保存
	    'click .save': function (e, value, row, index) {
	    	var data = new Array();
	    	$.each(row, function(idx, obj) {  
					data.push(obj);
			});
	    	ajaxcan("../../table/manage/update_user.php",{'data':data},"POST", function(){     
					alert('保存失败');
			},function(data){
				var de_json;
				if(data) de_json=eval("("+data+")");
				if(de_json['rs']=='true'){
					//刷新表格
					alert('保存成功');
				}
				else{
					alert(de_json['rs']);
				}
			});
	    }  
	}; 
	function CheckPost(){
		post_form = [addForm.t1.value,addForm.t2.value,addForm.t3.value,addForm.t4.value,addForm.t5.value,addForm.t6.value,addForm.t7.value];

		for(var i=0;i<post_form.length;i++){
		    if (post_form[i]==""){
		          alert("请填写完整数据！");
		          return false;
		     }
		}
  		ajaxcan("../../table/manage/save_u_m.php",{'data':post_form},"POST", function(){      
					alert('添加失败');
					$("#msgview").html('<span style="color:red">保存失败</span>');
					window.location.href = 'm1';
				},function(data){
				var de_json;
				if(data) de_json=eval("("+data+")");
				if(de_json['rs']=='true'){
					//刷新表格
					$("#msgview").html('<span style="color:green">保存成功</span>');
					window.location.href = 'm1';
				}
				else{
					alert(de_json['rs']);
					// alert('数据添加失败！');
				}		
		});
	    return false;
	};

	function cancle(){
		window.location.href = 'm1';
	}	

</script>
</head>
<body>
<?php require '../home/header.php';?>

<div id='content'>
<div id='btn'><button class="btn1" type="button">保存设置</button>&nbsp;<span id="msgview"></span></div>
<div id='btn1'><button class="btn1" type="button">新增用户</button>&nbsp;<span id="msgview"></span></div>
<div id="table1">
	<table id="table_u" data-classes="table table-bordered"></table>
</div>
<div id="table2">
	<table id="table_m" data-classes="table table-bordered"></table>
</div>
<div id="light" class="window_content">
	<!-- <form action="manage_u.php" method="post" name="download">
		<input type="text" name="down" value="111" style="display: none">
		<input type="submit" name="submit" value="模板下载">
	</form>
	<form action="manage_u.php" method="post" enctype="multipart/form-data" >
		<input type="file" name="myfile" id="file">
		<input type="submit" name="submit" value="上传">
	</form> -->
	-------------------------------------------------------------------------------------
	<form action="m1" method="post" name="addForm"  onsubmit="return CheckPost();">
     <div>工号:  <input type="text" name="t1" maxlength="50"/></div>
     <div>姓名: <input type="text" name="t2" maxlength="50"/></div>
     <div>片区:	<input type="text" name="t3" maxlength="50"/></div>
     <div>分部:	<input type="text" name="t4" maxlength="50"/></div>
     <div>营运:	<input type="text" name="t5" placeholder="1有权限，0无权限" maxlength="50"/></div>
     <div>市场:	<input type="text" name="t6" placeholder="1有权限，0无权限" maxlength="50"/></div>
     <div>综合: <input type="text" name="t7" placeholder="1有权限，0无权限" maxlength="50"/></div>
     <div>
           <input type="submit" name="submit" value="确定"/>
           <input type="button" onclick="cancle()" value="取消"/>
     </div>
     
</form>
</div> 

</div>

<?php include_once('../home/footer.php');?>
</body>
</html>
