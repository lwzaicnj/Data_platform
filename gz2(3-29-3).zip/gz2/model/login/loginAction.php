<?php 
class loginAction{
	
	public $main;
	public $smartydata	= array();	//模版数据
	public $date;
	public $jm;
	
	public function __construct()
	{
		$this->main		= $GLOBALS['main'];
		$this->jm		= $this->main->jm;
	}

	public function defaultAction()
	{
		$this->smartydata['walkerman']	= $this->getcookie('walkerman');
		$this->smartydata['keytowalk']	= $this->jm->uncrypt($this->getcookie('keytowalk'));
	}
	
	public function saveInfo()
	{
		$user 	= $this->jm->base64decode($this->post('adminuser'));
		$user	= str_replace(' ','',$user);
		$pass	= $this->jm->base64decode($this->post('adminpass'));
		$rempass= $this->post('rempass');//记住密码
	}

	public function getcookie($name, $dev='')
	{
		return $this->main->cookie($name, $dev);
	}

	public function post($na, $dev='', $lx=0)
	{
		return $this->main->post($na, $dev, $lx);
	}
}