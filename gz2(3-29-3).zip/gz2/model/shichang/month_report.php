<?php
date_default_timezone_set('Asia/Shanghai');
include_once '../../includes/public_inc_func.php';
cookie_location('../../cas_index.php');

include_once '../../includes/public_db_func.php';

$unique_id = addslashes($_COOKIE['unique_id']);
$user_info = get_user($unique_id);

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>广州数据平台</title>
<?php 
require '../../includes/header_inner.php';
?>
<link rel="stylesheet" type="text/css" href="../../css/shichang.css">
<script type="text/javascript" src="../../js/home/home.js"></script>
<script type="text/javascript">

	t6_data = new Array();

	//用户信息
	userinfo = <?php echo html_trim(json_encode($user_info));?>;

	$(function(){
	 	$('.ts').jeDate({
	        isinitVal:true,
	        format: 'YYYY-MM',
	        initAddVal: {MM:"-1"},
	        //点击确定的回调
	        okfun:function(elem, val) {
	        	choosefun(elem,val);
	        },
	        //选中日期的回调
	        choosefun:function(elem, val) {
	        	var select = $("#select option:selected").text();
	        	showData(val,select);
	        },		
	    });

	 	 //页面切换
	    $('.a1').click(function(){
	    	var a = ['1','2','3','4'];
	    	var i = $(this).attr('name');
	    	a.splice(a.indexOf(i),1);
			$('.datas'+ i).css("display",'block');
		
			//剩余隐藏
			for(var i=0;i<a.length;i++){
				$('.datas'+a[i]).css("display",'none');
			}
			$('.l1').css("border-bottom",'none');
			$(this).parent().css("border-bottom",'2px solid #337ab7');
		});



		//初始化
		// $("#select option:first").prop("selected", 'selected'); 
		var time = $(".ts").val();

		//第二个页面宽度需要设定
		$('#y2').css('width',(parseInt(window.innerWidth)*0.95)+'px');
		$('#y3').css('width',(parseInt(window.innerWidth)*0.90)+'px');

		//分部
		$("#select").change(function(){
			var time = $(".ts").val();
			var select = $("#select option:selected").text();
		 	showData(time,select);
			 
		});

		var a = get_select_arr('#select');

		var indx =  $.inArray(userinfo[3], a);
		if(userinfo[3]!='广州区' && indx>=0){
			$("#select option:eq("+indx+")").attr('selected','selected');
			//锁死
			$("#select").attr('disabled','disabled');
		}else{
			$("#select option:first").prop("selected", 'selected'); 
		}

		

		//table取数据
		showData(time,userinfo[3]);
	     
	});

	function showData(time,pq){
		//整体分析
		ajaxcan("../../table/shichang/month_t1.php",{"time":time,'pq':pq},"GET",0,function(data){	
				var t1_data = eval("("+data+")");
				$('#tb1 td:nth-child(1)').text(t1_data['月收入']);
				$('#tb1 td:nth-child(2)').text(t1_data['收入达成率']);
				$('#tb11 td:nth-child(1)').text(t1_data['收入同比']);
				$('#tb11 td:nth-child(2)').text(t1_data['收入环比']);
				$('#tb11 td:nth-child(3)').text(t1_data['收入达成进度']);
				$('#tb11 td:nth-child(4)').text(t1_data['收入同比进度差']);

				$('#tb2 td:nth-child(1)').text(t1_data['月票数']);
				$('#tb2 td:nth-child(2)').text(t1_data['票数达成率']);
				$('#tb21 td:nth-child(1)').text(t1_data['票数同比']);
				$('#tb21 td:nth-child(2)').text(t1_data['票数环比']);
				$('#tb21 td:nth-child(3)').text(t1_data['票数达成进度']);
				$('#tb21 td:nth-child(4)').text(t1_data['票数同比进度差']);
		},function(){},function(){});


		//月结散单
		ajaxcan("../../table/shichang/month_t3.php",{"time":time,'pq':pq},"GET",0,function(data){	
				var t3_data = eval("("+data+")");
				$('#tb3 td:nth-child(1)').text(t3_data['月结收入']);
				$('#tb3 td:nth-child(2)').text(t3_data['月结收入达成率']);
				$('#tb31 td:nth-child(1)').text(t3_data['月结收入同比']);
				$('#tb31 td:nth-child(2)').text(t3_data['月结收入环比']);
				$('#tb31 td:nth-child(3)').text(t3_data['月结收入达成进度']);

				$('#tb4 td:nth-child(1)').text(t3_data['散客收入']);
				$('#tb4 td:nth-child(2)').text(t3_data['散客收入达成率']);
				$('#tb41 td:nth-child(1)').text(t3_data['散客收入同比']);
				$('#tb41 td:nth-child(2)').text(t3_data['散客收入环比']);
				$('#tb41 td:nth-child(3)').text(t3_data['散客收入达成进度']);

				$('#tb5 td:nth-child(1)').text(t3_data['月结票数']);
				$('#tb51 td:nth-child(1)').text(t3_data['月结票数同比']);
				$('#tb6 td:nth-child(1)').text(t3_data['散客票数']);
				$('#tb61 td:nth-child(1)').text(t3_data['散客票数同比']);
		},function(){},function(){});

		var colors = ['#5793f3', '#d14a61','#90d7f9','#5793f3'];
	    option = {
			    color: colors,
			    tooltip: {
			        trigger: 'axis',
			        axisPointer: {
			            type: 'cross'
			        },
			    },
			    legend: {
			        data:['收入','目标','达成率','同比']
			    },
			    xAxis: [
			        {	
			            type: 'category',
			            axisTick: {
			                alignWithLabel: true
			            },
			            offset: 40,
			            data:[]
			        }
			    ],
			    yAxis: [
			        {	
			        	// show : false, 
			        	splitLine:{show: false},
			            type: 'value',
			            name: '数值(万)',
			            min: 0,
			            position: 'left',
			            axisLabel: {
			                formatter: '{value}'
			            },
			            axisLine:{
			            	show:false,//隐藏坐标轴显示数值
	                        lineStyle:{
	                            color:'#000',
	                        }
                    	},
			        }, {	
			        	splitLine:{show: false},
			            type: 'value',
			            name: '比率',
			            min: 0,
			            position: 'right',
			            axisLabel: {
			                formatter: '{value}%'
			            },
			            axisLine:{
			            	show:false,//隐藏坐标轴显示数值
	                        lineStyle:{
	                            color:'#000',
	                        }
                    	},
                    	axisTick:{
	                        show:false
	                    },
			        }
			    ],
			    series: [
			        {
			            name:'收入',
			            type:'bar',
			            yAxisIndex: 0,
			            barWidth: 20,  //柱宽度
		                barMaxWidth:100,   //最大柱宽度
			            data:[]
			        },
			        {
			            name:'目标',
			            type:'bar',
			            yAxisIndex: 0,
			            barWidth: 20,  //柱宽度
		                barMaxWidth:100,   //最大柱宽度
		                data:[]
			        },
			        {
			            name:'达成率',
			            type:'line',
			            yAxisIndex: 1,
			            data:[]
			        },
			         {
			            name:'同比',
			            type:'line',
			            yAxisIndex: 1,
			            data:[]
			        },
			       
			    ]
			};
		chart1 = document.getElementById('y1');
		myChart = echarts.init(chart1);
		myChart.setOption(option);
		window.onresize = function () {
	            //重置容器高宽
	            get_width(chart1,0.98);
	            myChart.resize();
	        };

	    ajaxcan("../../table/shichang/month_t2.php",{"time":time,'pq':pq},"GET",0,function(data){	
				var t2_data = eval("("+data+")");
				for(var i in t2_data){
	        		option.xAxis[0].data.push(i);
	        		option.series[0].data.push(t2_data[i][0]);
	        		option.series[1].data.push(t2_data[i][1]);
	        		option.series[2].data.push(t2_data[i][2]);
	        		option.series[3].data.push(t2_data[i][3]);	
	        	}
	        	myChart.clear();
				myChart.setOption(option);
			
		},function(){},function(){});

	    //月结散单chart
	    option1 = {
			    color: colors,
			    tooltip: {
			        trigger: 'axis',
			        axisPointer: {
			            type: 'cross'
			        }
			    },
			    legend: {
			        data:['月结收入','散客收入','月结同比','散客同比']
			    },
			    xAxis: [
			        {	
			            type: 'category',
			            axisTick: {
			                alignWithLabel: true
			            },
			            offset: 40,
			            data:[]
			        }
			    ],
			    yAxis: [
			        {	
			        	// show : false, 
			        	splitLine:{show: false},
			            type: 'value',
			            name: '数值(万)',
			            min: 0,
			            position: 'left',
			            axisLabel: {
			                formatter: '{value}'
			            },
			            axisLine:{
			            	show:false,//隐藏坐标轴显示数值
	                        lineStyle:{
	                            color:'#000',
	                        }
                    	},
			        }, {	
			        	splitLine:{show: false},
			            type: 'value',
			            name: '比率',
			            min: 0,
			            position: 'right',
			            axisLabel: {
			                formatter: '{value}%'
			            },
			            axisLine:{
			            	show:false,//隐藏坐标轴显示数值
	                        lineStyle:{
	                            color:'#000',
	                        }
                    	},
                    	axisTick:{
	                        show:false
	                    },
			        }
			    ],
			    series: [
			        {
			            name:'月结收入',
			            type:'bar',
			            yAxisIndex: 0,
			            barWidth: 20,  //柱宽度
		                barMaxWidth:100,   //最大柱宽度
			            data:[]
			        },
			        {
			            name:'散客收入',
			            type:'bar',
			            yAxisIndex: 0,
			            barWidth: 20,  //柱宽度
		                barMaxWidth:100,   //最大柱宽度
		                data:[]
			        },
			        {
			            name:'月结同比',
			            type:'line',
			            yAxisIndex: 1,
			            data:[]
			        },
			         {
			            name:'散客同比',
			            type:'line',
			            yAxisIndex: 1,
			            data:[]
			        },
			       
			    ]
			};

	    chart2 = document.getElementById('y2');
		myChart2 = echarts.init(chart2);
		myChart2.setOption(option1);
		window.onresize = function () {
	            //重置容器高宽
	            get_width(chart2,0.98);
	            myChart2.resize();
	        };

	    ajaxcan("../../table/shichang/month_t4.php",{"time":time,'pq':pq},"GET",0,function(data){	
				var t2_data = eval("("+data+")");
				for(var i in t2_data){
	        		option1.xAxis[0].data.push(i);
	        		option1.series[0].data.push(t2_data[i][0]);
	        		option1.series[1].data.push(t2_data[i][1]);
	        		option1.series[2].data.push(t2_data[i][2]);
	        		option1.series[3].data.push(t2_data[i][3]);	
	        	}
	        	myChart2.clear();
				myChart2.setOption(option1);
			
		},function(){},function(){});

	    //产品分析
	    ajaxcan("../../table/shichang/month_t5.php",{"time":time,'pq':pq},"GET",0,function(data){	
				var t5_data = eval("("+data+")");
		
				$('#tb7 .tr1 td:nth-child(2)').text(t5_data[0]['折扣率']);
				$('#tb7 .tr1 td:nth-child(3)').text(t5_data[1]['折扣率']);
				$('#tb7 .tr1 td:nth-child(4)').text(t5_data[2]['折扣率']);
				$('#tb7 .tr1 td:nth-child(5)').text(t5_data[3]['折扣率']);
				$('#tb7 .tr1 td:nth-child(6)').text(t5_data[4]['折扣率']);
				$('#tb7 .tr1 td:nth-child(7)').text(t5_data[5]['折扣率']);
				$('#tb7 .tr1 td:nth-child(8)').text(t5_data[6]['折扣率']);
				$('#tb7 .tr1 td:nth-child(9)').text(t5_data[7]['折扣率']);

				$('#tb7 .tr2 td:nth-child(2)').text(t5_data[0]['收入同比']);
				$('#tb7 .tr2 td:nth-child(3)').text(t5_data[1]['收入同比']);
				$('#tb7 .tr2 td:nth-child(4)').text(t5_data[2]['收入同比']);
				$('#tb7 .tr2 td:nth-child(5)').text(t5_data[3]['收入同比']);
				$('#tb7 .tr2 td:nth-child(6)').text(t5_data[4]['收入同比']);
				$('#tb7 .tr2 td:nth-child(7)').text(t5_data[5]['收入同比']);
				$('#tb7 .tr2 td:nth-child(8)').text(t5_data[6]['收入同比']);
				$('#tb7 .tr2 td:nth-child(9)').text(t5_data[7]['收入同比']);

				$('#tb7 .tr3 td:nth-child(2)').text(t5_data[0]['收入达成率']);
				$('#tb7 .tr3 td:nth-child(3)').text(t5_data[1]['收入达成率']);
				$('#tb7 .tr3 td:nth-child(4)').text(t5_data[2]['收入达成率']);
				$('#tb7 .tr3 td:nth-child(5)').text(t5_data[3]['收入达成率']);
				$('#tb7 .tr3 td:nth-child(6)').text(t5_data[4]['收入达成率']);
				$('#tb7 .tr3 td:nth-child(7)').text(t5_data[5]['收入达成率']);
				$('#tb7 .tr3 td:nth-child(8)').text(t5_data[6]['收入达成率']);
				$('#tb7 .tr3 td:nth-child(9)').text(t5_data[7]['收入达成率']);
		},function(){},function(){});

		//各种产品chart
	    option2 = {
			    color: ['#4876ff','#43cd80','#388e8e','#008b8b','#458b74','#008b00','#1874cd','#00bfff'],
			    tooltip: {
			        trigger: 'axis',
			        axisPointer: {
			            type: 'cross'
			        }
			    },
			    legend: {
			        data:[{name:'整体',icon:'stack'},{name:'月结',icon:'stack'},{name:'散客',icon:'stack'},{name:'重货快运',icon:'stack'},{name:'物流普运',icon:'stack'},{name:'国际件',icon:'stack'},{name:'保价',icon:'stack'},{name:'代收服务费',icon:'stack'}]
			    },
			    xAxis: [
			        {	
			            type: 'category',
			            axisTick: {
			                alignWithLabel: true
			            },
			            offset: 40,
			            data:[]
			        }
			    ],
			    yAxis: [
			        {	
			        	// show : false, 
			        	splitLine:{show: false},
			            type: 'value',
			            name: '数值(万)',
			            // min: 0,
			            position: 'left',
			            axisLabel: {
			                formatter: '{value}'
			            },
			            axisLine:{
			            	show:false,//隐藏坐标轴显示数值
	                        lineStyle:{
	                            color:'#000',
	                        }
                    	},
			        }
			    ],
			    series: [
			        {
			            name:'整体',
			            type:'line',
			            data:[]
			        },{
			            name:'月结',
			            type:'line',
			            data:[]
			        },{
			            name:'散客',
			            type:'line',
			            data:[]
			        },{
			            name:'重货快运',
			            type:'line',
			            data:[]
			        },{
			            name:'物流普运',
			            type:'line',
			            data:[]
			        },{
			            name:'国际件',
			            type:'line',
			            data:[]
			        },{
			            name:'保价',
			            type:'line',
			            data:[]
			        },{
			            name:'代收服务费',
			            type:'line',
			            data:[]
			        }
			       
			    ]
			};

		$(".select3 option:first").prop("selected", 'selected'); 
	    chart3 = document.getElementById('y3');
		myChart3 = echarts.init(chart3);
		myChart3.setOption(option2);
		window.onresize = function () {
	            //重置容器高宽
	            get_width(chart3,0.98);
	            myChart3.resize();
	        };
	    ajaxcan("../../table/shichang/month_t6.php",{"time":time,'pq':pq},"GET",0,function(data){	
				t6_data = eval("("+data+")");
				for(var i in t6_data){
	        		option2.xAxis[0].data.push(i);
	        		option2.series[0].data.push(t6_data[i][0]['收入']);
	        		option2.series[1].data.push(t6_data[i][1]['收入']);
	        		option2.series[2].data.push(t6_data[i][2]['收入']);
	        		option2.series[3].data.push(t6_data[i][3]['收入']);
	        		option2.series[4].data.push(t6_data[i][4]['收入']);
	        		option2.series[5].data.push(t6_data[i][5]['收入']);
	        		option2.series[6].data.push(t6_data[i][6]['收入']);
	        		option2.series[7].data.push(t6_data[i][7]['收入']);
	        	}
	        	myChart3.clear();
				myChart3.setOption(option2);
			
		},function(){},function(){});

		$('.select3').change(function(){
			var select_text = $(".select3 option:selected").text();
			if(select_text=='达成率' || select_text=='同比'){
				option2.yAxis[0].name = '比例(%)';
				option2.yAxis[0].axisLabel.formatter = '{value}%';
			}else{
				option2.yAxis[0].name = '数值(万)';
				option2.yAxis[0].axisLabel.formatter = '{value}';
			}
			option2.xAxis[0].data = [];
			option2.series[0].data = [];
			option2.series[1].data = [];
			option2.series[2].data = [];
			option2.series[3].data = [];
			option2.series[4].data = [];
			option2.series[5].data = [];
			option2.series[6].data = [];
			option2.series[7].data = [];
			for(var i in t6_data){
        		option2.xAxis[0].data.push(i);
        		option2.series[0].data.push(t6_data[i][0][select_text]);
        		option2.series[1].data.push(t6_data[i][1][select_text]);
        		option2.series[2].data.push(t6_data[i][2][select_text]);
        		option2.series[3].data.push(t6_data[i][3][select_text]);
        		option2.series[4].data.push(t6_data[i][4][select_text]);
        		option2.series[5].data.push(t6_data[i][5][select_text]);
        		option2.series[6].data.push(t6_data[i][6][select_text]);
        		option2.series[7].data.push(t6_data[i][7][select_text]);
        	}
        	myChart3.clear();
		myChart3.setOption(option2);
			
		});
	}

	function insertData(row,col,data){
		row.insertCell(col).innerHTML = data;
	}

	//定时监控
	var int=window.setInterval("clock()",10000);
	function clock(){
		var yes = get_time();
		var time = $(".ts").val();
		var select = $("#select option:selected").text();

	}


	//展示所在片区
	function get_home(arr,pq){
		var fb_arr = new Array();
		if(pq!='广州区'){
			$(arr).each(function(index,element){
				if(element['片区']=='广州区')fb_arr.push(element);
				else if(element['片区']==pq){
					fb_arr.push(element);
				}
			});
		}else fb_arr = arr;
		
		return fb_arr;
	}

    //返回select的内容数组
	function get_select_arr(id){
	    var op_arr = new Array();
	    $(""+id+" option").each(function(){    
	          var txt = $(this).val();   //获取option值   
	          if(txt!=''){  
	              op_arr.push(txt); 
	          }  
	    });

	    return op_arr;
	}

</script>

</head>
<body>
<?php require '../home/header.php';?>
<!-- <i id='icon' style="position: absolute; color: black;left: 60%;top:19%;"></i> -->
<div class="main_content mainy">
	<div class="row1">
		<span>市场监控月报</span>
		<input type="text" class="ts" />
		<select class="selectss" style="display: block;" id="select">
		  <option  selected="selected">广州区</option>
		  <option>小友战队</option>
		  <option>成钦战队</option>
		  <option>海山战队</option>
		  <option>浩昌战队</option>
		  <option>永超战队</option>
		  <option>张悦战队</option>
		</select>
	</div>

	<div class="data">
		<div class="header headery">
			<ul>
				<li class="l1"><a name='1' class="a1">整体分析</a></li>
				<li class="l1"><a name='2' class="a1">客户分析</a></li>
				<li class="l1"><a name='3' class="a1">产品分析</a></li>
			</ul>
		</div>
	</div>
	<div class="datas1">
		<h2 class="titley">业务总览</h2>
		<div class="chart t1 ty1">
			<p class="header1">收入</p>
			<div class="contenty">
				<p class='header2'>整体</p>
				<table class="tabley">
				 <tbody class="tbodyy1" id='tb1'>
				    <tr>
				      <th>收入(万元)</th>
				      <th>收入达成率</th>
				    </tr>
				    <tr>
				      <td>-</td>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table>
				<table class="tabley1">
				 <tbody class="tbodyy11" id='tb11'>
				    <tr>
				      <th>同比</th>
				      <th>环比</th>
				      <th>达成进度</th>
				      <th>同比进度差</th>
				    </tr>
				    <tr>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table> 
			</div>
		</div>
		<div class="chart t2 ty2">
			<p class="header1">件量</p>
			<div class="contenty">
				<p class='header2'>整体</p>
				<table class="tabley">
				 <tbody class="tbodyy2" id='tb2'>
				    <tr>
				      <th>件量(万件)</th>
				      <th>件量达成率</th>
				    </tr>
				    <tr>
				      <td>-</td>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table>
				<table class="tabley1">
				  <tbody class="tbodyy21" id='tb21'>
				    <tr>
				      <th>同比</th>
				      <th>环比</th>
				      <th>达成进度</th>
				      <th>同比进度差</th>
				    </tr>
				    <tr>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table>
			</div>
		</div>
		<h2 class="titley">业务趋势</h2>
		<div class="chart t5 ty5">
			<div id="y1"></div>
		</div>
	</div>
	<div class="datas2">
		<h2 class="titley">业务总览</h2>
		<div class="chart t1 ty1">
			<p class="header1">收入</p>
			<div class="contenty">
				<p class='header2'>月结</p>
				<table class="tabley">
				 <tbody class="tbodyy1" id='tb3'>
				    <tr>
				      <th>收入(万元)</th>
				      <th>收入达成率</th>
				    </tr>
				    <tr>
				      <td>-</td>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table>
				<table class="tabley1">
				 <tbody class="tbodyy11" id='tb31'>
				    <tr>
				      <th>同比</th>
				      <th>环比</th>
				      <th>达成进度</th>
				    </tr>
				    <tr>
				      <td>--</td>
				      <td>--</td>
				      <td>--</td>
				    </tr>
				  </tbody>
				</table> 
			</div>
			<div class="contenty contentys">
				<p class='header2'>散客</p>
				<table class="tabley">
				 <tbody class="tbodyy1" id='tb4'>
				    <tr>
				      <th>收入(万元)</th>
				      <th>收入达成率</th>
				    </tr>
				    <tr>
				      <td>-</td>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table>
				<table class="tabley1">
				 <tbody class="tbodyy11" id='tb41'>
				    <tr>
				      <th>同比</th>
				      <th>环比</th>
				      <th>达成进度</th>
				    </tr>
				    <tr>
				      <td>--</td>
				      <td>--</td>
				      <td>--</td>
				    </tr>
				  </tbody>
				</table> 
			</div>
		</div>
		<div class="chart t2 ty2">
			<p class="header1">件量</p>
			<div class="contenty">
				<p class='header2'>月结</p>
				<table class="tabley">
				 <tbody class="tbodyy2" id='tb5'>
				    <tr>
				      <th>件量(万票)</th>
				    </tr>
				    <tr>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table>
				<table class="tabley1">
				  <tbody class="tbodyy21" id='tb51'>
				    <tr>
				      <th>同比</th>
				    </tr>
				    <tr>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table>
			</div>
			<div class="contenty contentys">
				<p class='header2'>散客</p>
				<table class="tabley">
				 <tbody class="tbodyy2" id='tb6'>
				    <tr>
				      <th>件量(万票)</th>
				    </tr>
				    <tr>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table>
				<table class="tabley1">
				 <tbody class="tbodyy21" id='tb61'>
				    <tr>
				      <th>同比</th>
				    </tr>
				    <tr>
				      <td>--</td>
				    </tr>
				  </tbody>
				</table> 
			</div>
		</div>
		<h2 class="titley">业务趋势</h2>
		<div class="chart t5 ty5">
			<div id="y2"></div>
		</div>
	</div>
	<div class="datas3">
		<h2 class="titley">业务总览</h2>
		<div class="chart t1 ty3">
			<div class="contenty3">
				<table class="tabley3">
				 <tbody  id='tb7'>
				    <tr>
				      <th></th>
				      <th>整体</th>
				      <th>月结</th>
				      <th>散客</th>
				      <th>重货快运</th>
				      <th>物流普运</th>
				      <th>国际件</th>
				      <th>保价</th>
				      <th>代收服务费</th>
				    </tr>
				    <tr class='tr1'>
				      <td>折扣率</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				    </tr>
				    <tr class='tr2'>
				      <td>收入同比</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				    </tr>
				    <tr class='tr3'>
				      <td>收入达成率</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				      <td>-</td>
				    </tr>
				  </tbody>
				</table>
			</div>
		</div>
		<h2 class="titley">业务趋势</h2>
		<div class="chart t5 ty5">
			<select class="select3">
				<option>收入</option>
				<option>收入目标</option>
				<option>达成率</option>
				<option>同比</option>
			</select>
			<div id="y3"></div>
		</div>
	</div>

</div>

<?php include_once('../home/footer.php');?>
</body>
</html>


