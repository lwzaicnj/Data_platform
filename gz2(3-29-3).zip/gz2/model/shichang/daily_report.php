<?php 
date_default_timezone_set('Asia/Shanghai');
include_once '../../includes/public_inc_func.php';
cookie_location('../../cas_index.php');

include_once '../../includes/public_db_func.php';

$wd_details = get_infos(); 


//session_start();
//var_dump($_SESSION['phpCAS']);

$unique_id = addslashes($_COOKIE['unique_id']);
$user_info = get_user($unique_id);

$auth_de = @get_pqfb($wd_details,$user_info[3]);
// var_dump($auth_de);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>广州数据平台</title>
<?php 
require '../../includes/header_inner.php';
?>
<link rel="stylesheet" type="text/css" href="../../css/shichang.css">
<script type="text/javascript" src="../../js/home/home.js"></script>
<script type="text/javascript">
	String.prototype.stripHTML = function() {
	    var reTag = /<(?:.|\s)*?>/g;
	    return this.replace(reTag,"");
	  }

	t2_data = new Array();
	t3_data = new Array();
	t4_data = new Array();
	t5_data = new Array();
	t6_data = new Array();
	t7_data = new Array();
	//选项卡全局变量
	sel_g = 1;

	//用户信息
	userinfo = <?php echo html_trim(json_encode($user_info));?>;

	area_info = <?php echo html_trim(json_encode($wd_details));?>;
	$(function(){

	 	$('.ts').jeDate({
	        isinitVal:true,
	        format: 'YYYY-MM-DD',
	        initAddVal: {DD:"-1"},
	        //点击确定的回调
	        okfun:function(elem, val) {
	        	choosefun(elem,val);
	        },
	        //选中日期的回调
	        choosefun:function(elem, val) {
	        	showData(val);
	        },		
	    });
	    //页面切换
	    $('.a1').click(function(){
	    	var a = ['1','2','3','4'];
	    	var i = $(this).attr('name');
	    	a.splice(a.indexOf(i),1);
			$('.datas'+ i).css("display",'block');
			if(i!=4)
				$('.selectss').css("display",'none');
			else 
				$('.selectss').css("display",'block');

			//剩余隐藏
			for(var i=0;i<a.length;i++){
				$('.datas'+a[i]).css("display",'none');
			}
			$('.l1').css("border-bottom",'none');
			$(this).parent().css("border-bottom",'2px solid #337ab7');
		});

	    //图表
	    $('.table21').bootstrapTable({
			// height: 1000,
			pagination: true,pageSize:15,
			cache: false,
		    columns: [
			    		[  {
						        field: '片区',
						        title: '片区',
						        rowspan: 2,
					       		colspan: 1,
						        align: 'center',
						        valign: 'middle',
						        sortable:true,
						    },{
						        field: '分部',
						        title: '分部',
						        rowspan: 2,
					       		colspan: 1,
						        align: 'center',
						        valign: 'middle',
						        sortable:true,
						    },{
						        title: '当日',
						        rowspan: 1,
					       		colspan: 4,
						        align: 'center',
						        valign: 'middle',
						    },{
						        title: '当月',
						        rowspan: 1,
					       		colspan: 7,
						        align: 'center',
						        valign: 'middle',
						    },{
						        title: '当年',
						        rowspan: 1,
					       		colspan: 7,
						        align: 'center',
						        valign: 'middle',
						    }
						],[{
						        field: '日入',
						        title: '当日收入',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '日件',  
				                title: '当日收件',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '日入率',  
				                title: '收入达成率',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '日件率',  
				                title: '收件达成率',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月入',  
				                title: '月累计收入',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月件',  
				                title: '月累计件量',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月入同比',  
				                title: '月累计收入同比',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月件同比',  
				                title: '月累计件量同比',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月入进度',  
				                title: '收入达成进度',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月件进度',  
				                title: '收件达成进度',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月进度排名',  
				                title: '收件进度排名',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '年入',  
				                title: '年累计收入',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '年件',  
				                title: '年累计件量',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '年入同比',  
				                title: '年累计收入同比',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '年件同比',  
				                title: '年累计件量同比',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '年入进度',  
				                title: '收入达成进度',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '年件进度',  
				                title: '收件达成进度',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '年进度排名',  
				                title: '收件进度排名',  
				                align: 'center', 
				                valign: 'middle',
				            }
						]
					],
			onClickRow: function(row, element){
				$('.success').removeClass('success');//去除之前样式
				$(element).addClass('success');//添加当前选中的
				$(".success").css("background-color");//保存之前的颜色
			},
		});

		$('.table41').bootstrapTable({
			pagination: true,pageSize:20,
			cache: false,
		    columns: [
			    		[  {
						        field: '片区',
						        title: '片区',
						        rowspan: 2,
					       		colspan: 1,
						        align: 'center',
						        valign: 'middle',
						        sortable:true,
						    },{
						        field: '分部',
						        title: '分部',
						        rowspan: 2,
					       		colspan: 1,
						        align: 'center',
						        valign: 'middle',
						        sortable:true,
						    },{
						        title: '本月散单',
						        rowspan: 1,
					       		colspan: 5,
						        align: 'center',
						        valign: 'middle',
						    },{
						        title: '本月月结',
						        rowspan: 1,
					       		colspan: 5,
						        align: 'center',
						        valign: 'middle',
						    }
						],[{
						        field: '散单入',
						        title: '当日收入',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '散单件',  
				                title: '当日件量',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '散单月入',  
				                title: '月累计收入',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '散单月件',  
				                title: '月累计件量',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '散单收入占比',  
				                title: '收入占比',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月结入',  
				                title: '当日收入',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月结件',  
				                title: '当日件量',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月结月入',  
				                title: '月累计收入',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月结月件',  
				                title: '月累计件量',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月结收入占比',  
				                title: '收入占比',  
				                align: 'center', 
				                valign: 'middle',
				            }
						]
					],
			onClickRow: function(row, element){
				$('.success').removeClass('success');//去除之前样式
				$(element).addClass('success');//添加当前选中的
				$(".success").css("background-color");//保存之前的颜色
			},
		});

		$('.table61').bootstrapTable({
			pagination: true,pageSize:20,
			cache: false,
		    columns: [
			    		[  {
						        field: '类型',
						        title: '类型',
						        rowspan: 2,
					       		colspan: 1,
						        align: 'center',
						        valign: 'middle',
						        sortable:true,
						    },{
						        title: '业务收入情况',
						        rowspan: 1,
					       		colspan: 5,
						        align: 'center',
						        valign: 'middle',
						    },{
						        title: '业务对比情况',
						        rowspan: 1,
					       		colspan: 3,
						        align: 'center',
						        valign: 'middle',
						    },{
						        title: '业务占比情况',
						        rowspan: 1,
					       		colspan: 3,
						        align: 'center',
						        valign: 'middle',
						    }
						],[{
						        field: '收入',
						        title: '当日收入',
						        align: 'center',
						        valign: 'middle',
						    },{
						        field: '月累计',  
				                title: '月累计',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月累计进度',  
				                title: '月累计达成进度',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '进度差额',  
				                title: '进度差额',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '月累计日均',  
				                title: '月累计日均',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '日均环比上周',  
				                title: '日均环比上周',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '日均同期环比',  
				                title: '日均同期环比',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '日均同期同比',  
				                title: '日均同期同比',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '收入占比',  
				                title: '收入占比',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '环比上周差额',  
				                title: '环比上周差额',  
				                align: 'center', 
				                valign: 'middle',
				            },{
						        field: '环比上月差额',  
				                title: '环比上月差额',  
				                align: 'center', 
				                valign: 'middle',
				            }
						]
					],
			onClickRow: function(row, element){
				$('.success').removeClass('success');//去除之前样式
				$(element).addClass('success');//添加当前选中的
				$(".success").css("background-color");//保存之前的颜色
			},
		});


		//初始化
		// $("#select option:first").prop("selected", 'selected'); 
		var time = $(".ts").val();

		//分部
		$("#select").change(function(){
			var time = $(".ts").val();
			var select = $("#select option:selected").text();
		    get_t6(time,select);

		    var content="";
		 	for(var index in area_info){
		 		if(area_info[index]['所属片区']==select)
		 			content += "<option>"+area_info[index]['分部代码']+"</option>";
		 	}
		 	$("#select1").html(content);
		 	var select1 = $("#select1 option:selected").text();
		 	if(select!='广州区')
				get_t7(time,select,select1);
		});

		$('#select1').change(function(){
			var select = $("#select option:selected").text();
			var select1 = $("#select1 option:selected").text();
		 	if(select!='广州区')
				get_t7(time,select,select1);
		});

		var a = get_select_arr('#select');

		var indx =  $.inArray(userinfo[3], a);
		if(userinfo[3]!='广州区' && indx>=0){
			$("#select option:eq("+indx+")").attr('selected','selected');
			//锁死
			$("#select").attr('disabled','disabled');
			var content="";
		 	for(var index in area_info){
		 		if(area_info[index]['所属片区']==userinfo[3])
		 			content += "<option>"+area_info[index]['分部代码']+"</option>";
		 	}
		 	$("#select1").html(content);

		 	var da = get_select_arr('#select1');
		 	var indx_da =  $.inArray(userinfo[4], da);
		 	if(indx_da>=0){
		 		$("#select1 option:eq("+indx_da+")").attr('selected','selected');
		 		$("#select1").attr('disabled','disabled');
		 	}
		}else{
			$("#select option:first").prop("selected", 'selected'); 
		}

		 //选项卡
	    $('.sel').click(function(){
	    	$('.sel').css('background-color','#286090');
	    	$(this).css('background-color','#046');
	    	var name = $(this).attr('name');
	    	if(name=='sel1'){
	    		sel_g = 1;
	    	}else if(name=='sel2'){
	    		sel_g = 2;
	    	}
	    });  

		//table取数据
		showData(time);
	     
	});

	function showData(time){
		var colors = ['#5793f3', '#d14a61','#90d7f9'];
	    option = {
			    color: colors,
			    tooltip: {
			        trigger: 'axis',
			        axisPointer: {
			            type: 'cross'
			        }
			    },
			    legend: {
			        data:['差额','18折后收入','17折后收入','18目标收入']
			    },
			    xAxis: [
			        {	
			            type: 'category',
			            axisTick: {
			                alignWithLabel: true
			            },
			            offset: 40,
			            data:[]
			        }
			    ],
			    yAxis: [
			        {	
			        	show : false, 
			        	splitLine:{show: false},
			            type: 'value',
			            name: '差额',
			            min: 0,
			            position: 'left',
			            axisLabel: {
			                formatter: '{value}'
			            }
			        },
			    ],
			    series: [
			        {
			            name:'差额',
			            type:'bar',
			            barWidth: 20,  //柱宽度
		                barMaxWidth:100,   //最大柱宽度
			            data:[]
			        },
			        {
			            name:'18折后收入',
			            type:'line',
			            // yAxisIndex: 1,
			            data:[]
			        },
			        {
			            name:'17折后收入',
			            type:'line',
			            // yAxisIndex: 1,
			            data:[]
			        },
			         {
			            name:'18目标收入',
			            type:'line',
			            // yAxisIndex: 1,
			            data:[]
			        },
			       
			    ]
			};
		chart1 = document.getElementById('c1');
		myChart = echarts.init(chart1);
		// option.xAxis[0].data = ['1月','2月','3月','4月','5月','6月','7月','8月'];
		myChart.setOption(option);
		window.onresize = function () {
	            //重置容器高宽
	            get_width(chart1,0.98);
	            myChart.resize();
	        };
	    ajaxcan("../../table/shichang/daily_c5.php",{"time":time,'pq':userinfo[3]},"GET",function(){      
	            alert('请求超时');},function(data){
	            var t_data = eval("("+data+")");
	        	for(var i in t_data){
	        		option.xAxis[0].data.push(i);
	        		option.series[0].data.push(t_data[i][0]);
	        		option.series[1].data.push(t_data[i][2]);
	        		option.series[2].data.push(t_data[i][3]);
	        		option.series[3].data.push(t_data[i][1]);
	        	}
	        	myChart.clear();
				myChart.setOption(option);
	    });

	    //c1/c2合并
		var tb1=document.getElementById('tbody1');
		if(tb1.rows.length==4){
			tb1.deleteRow(1);//删除3次，会上移
			tb1.deleteRow(1); 
			tb1.deleteRow(1); 
		}
		r11=tb1.insertRow(1); 
		r12=tb1.insertRow(2);  
		r13=tb1.insertRow(3); 
		r11.insertCell(0).innerHTML = "折后收入"; 
		r12.insertCell(0).innerHTML = "收入达成率";
		r13.insertCell(0).innerHTML = "收入达成进度"; 

		var tb2=document.getElementById('tbody2');
		if(tb2.rows.length==4){
			tb2.deleteRow(1);
			tb2.deleteRow(1); 
			tb2.deleteRow(1); 
		}
		r21=tb2.insertRow(1); 
		r22=tb2.insertRow(2);  
		r23=tb2.insertRow(3);
		r21.insertCell(0).innerHTML = "件量"; 
		r22.insertCell(0).innerHTML = "预算达成率";
		r23.insertCell(0).innerHTML = "预算达成进度"; 

		var yes = get_time();//昨日

		if(yes==time){
			//都是大盘数据
			//var str_data = localStorage.getItem("c1_data");
			var str_data = localStorage.c1_data.stripHTML();;	
			var c1_data = JSON.parse(str_data);//转回数组

		    insertData(r11,1,(parseInt(c1_data["当天折后收入"])/10000).toFixed(2)+'万');
		    insertData(r11,2,c1_data["当月折后收入"]);
		    insertData(r11,3,c1_data["当年折后收入"]);

		    insertData(r12,1,c1_data["当天收入达成"]);
		    insertData(r12,2,c1_data["当月收入达成"]);
		    insertData(r12,3,c1_data["当年收入达成"]); 
			
		    insertData(r13,1,c1_data["当天达成进度"]);
		    insertData(r13,2,c1_data["当月达成进度"]);
		    insertData(r13,3,c1_data["当年达成进度"]);		    

		    progress(c1_data["当天收入达成"],'#l1',c1_data["当日收入目标"]);
		    progress(c1_data["当月收入达成"],'#l2',c1_data["当月收入目标"]);
		    progress(c1_data["当年收入达成"],'#l3',c1_data["当年收入目标"]);

		    //c2
		    insertData(r21,1,(parseInt(c1_data["当天件量"])/10000).toFixed(2)+'万');
		    insertData(r21,2,c1_data["当月件量"]);
		    insertData(r21,3,c1_data["当年件量"]);

	     	    insertData(r22,1,c1_data["当天件量达成"]);
		    insertData(r22,2,c1_data["当月件量达成"]);
		    insertData(r22,3,c1_data["当年件量达成"]);

		    insertData(r23,1,c1_data["当天件量进度"]);
		    insertData(r23,2,c1_data["当月件量进度"]);
		    insertData(r23,3,c1_data["当年件量进度"]);			

		    progress(c1_data["当天件量达成"],'#l4',c1_data["当日件量目标"]);
		    progress(c1_data["当月件量达成"],'#l5',c1_data["当月件量目标"]);
		    progress(c1_data["当年件量达成"],'#l6',c1_data["当年件量目标"]);

		}else{
			ajaxcan("../../table/shichang/daily_c2.php",{"time":time,'pq':userinfo[3]},"GET",0,function(data){
				var c1_data = eval("("+data+")");
			insertData(r11,1,(parseInt(c1_data["当天折后收入"])/10000).toFixed(2)+'万');
			insertData(r11,2,c1_data["当月折后收入"]);
			insertData(r11,3,c1_data["当年折后收入"]);

			insertData(r12,1,c1_data["当天收入达成"]);
			insertData(r12,2,c1_data["当月收入达成"]);
			insertData(r12,3,c1_data["当年收入达成"]);

			insertData(r13,1,c1_data["当天达成进度"]);
			insertData(r13,2,c1_data["当月达成进度"]);
			insertData(r13,3,c1_data["当年达成进度"]);

			    progress(c1_data["当天收入达成"],'#l1',c1_data["当日收入目标"]);
			    progress(c1_data["当月收入达成"],'#l2',c1_data["当月收入目标"]);
			    progress(c1_data["当年收入达成"],'#l3',c1_data["当年收入目标"]);

			    //c2
			insertData(r21,1,(parseInt(c1_data["当天件量"])/10000).toFixed(2)+'万');
			insertData(r21,2,c1_data["当月件量"]);
			insertData(r21,3,c1_data["当年件量"]);

			insertData(r22,1,c1_data["当天件量达成"]);
			insertData(r22,2,c1_data["当月件量达成"]);
			insertData(r22,3,c1_data["当年件量达成"]);

			insertData(r23,1,c1_data["当天件量进度"]);
			insertData(r23,2,c1_data["当月件量进度"]);
			insertData(r23,3,c1_data["当年件量进度"]);


			    progress(c1_data["当天件量达成"],'#l4',c1_data["当日件量目标"]);
			    progress(c1_data["当月件量达成"],'#l5',c1_data["当月件量目标"]);
			    progress(c1_data["当年件量达成"],'#l6',c1_data["当年件量目标"]);
			});
		}

	  
	    //c3/c4合并
	    var tb3=document.getElementById('tbody3');
		if(tb3.rows.length==6){
			tb3.deleteRow(1);
			tb3.deleteRow(1); 
			tb3.deleteRow(1); 
			tb3.deleteRow(1); 
			tb3.deleteRow(1); 
		}
		r31=tb3.insertRow(1); 
		r32=tb3.insertRow(2);  
		r33=tb3.insertRow(3);
		r34=tb3.insertRow(4);  
		r35=tb3.insertRow(5);
		insertData(r31,0,"日均收入");
		insertData(r32,0,"日均同比");
		insertData(r33,0,"日均环比");
		insertData(r34,0,"票均收入");
		insertData(r35,0,"票均同比");

		var tb4=document.getElementById('tbody4');
		if(tb4.rows.length==4){
			tb4.deleteRow(1);
			tb4.deleteRow(1); 
			tb4.deleteRow(1); 
		}
		r41=tb4.insertRow(1); 
		r42=tb4.insertRow(2);  
		r43=tb4.insertRow(3);
		insertData(r41,0,"日均件量");
		insertData(r42,0,"日均同比");
		insertData(r43,0,"日均环比");
		
		ajaxcan("../../table/shichang/daily_c4.php",{"time":time,'pq':userinfo[3]},"GET",function(){      
	            alert('请求超时');},function(data){
	            	var t_data = eval("("+data+")");
		        	insertData(r41,1,t_data['件量当月日均件量']);
		        	insertData(r41,2,t_data['件量当年日均件量']);
		        	insertData(r42,1,t_data['件量当月日均同比']);
		        	insertData(r42,2,t_data['件量当年日均同比']);
		        	insertData(r43,1,t_data['件量当月日均环比']);
		        	insertData(r43,2,t_data['件量当年日均环比']);

		        	insertData(r31,1,t_data['当月日均收入']);
		        	insertData(r31,2,t_data['当年日均收入']);
		        	insertData(r32,1,t_data['当月日均同比']);
		        	insertData(r32,2,t_data['当年日均同比']);
		        	insertData(r33,1,t_data['当月日均环比']);
		        	insertData(r33,2,t_data['当年日均环比']);
		        	insertData(r34,1,t_data['当月票均收入']);
		        	insertData(r34,2,t_data['当年票均收入']);
		        	insertData(r35,1,t_data['当月票均同比']);
		        	insertData(r35,2,t_data['当年票均同比']);
		});


		//判断时间变化
		// var yes = get_time();
		// alert(yes);

		//初始化 片区的  name=='sel1'
		//datas2
		var select = $("#select option:selected").text();
		var select1 = $("#select1 option:selected").text();	
	    get_t2(time);
	    get_t3(time,userinfo[3]);
	    get_t4(time,userinfo[3]);
	    get_t5(time,userinfo[3]);
	    get_t6(time,select);
	    if(select!='广州区')
	    	get_t7(time,select,select1);

	}

	function insertData(row,col,data){
		//row.insertCell(col).innerHTML = data;
		$(row.insertCell(col)).text(data.stripHTML());
	}

	function progress(percent,li,target){
		var x =parseFloat(percent.replace(/%/, ""))/100;
		if(x>=1){
	    	$(li).css('width','40%');
		}
	    else{
	    	var d = 40*x;
	    	$(li).css('width',d.toString()+'%');
	    }
	    $(li).text(percent+'('+target+')');

	}

	//定时监控
	var int=window.setInterval("clock()",1000);
	function clock(){
		var yes = get_time();
		var time = $(".ts").val();
		var select = $("#select option:selected").text();
		if(yes==time){
			if(sel_g==1){
				$('.table21').bootstrapTable('hideColumn',"分部");
				var pq = get_home(t2_data,userinfo[3]);
				$('.table21').bootstrapTable('load', pq);

				var str_data1 = localStorage.getItem("t4_data");
		        var t4_data_s = JSON.parse(str_data1);
		        $('.table41').bootstrapTable('hideColumn',"分部");
		        var pq4 = get_home(t4_data_s,userinfo[3]);
				$('.table41').bootstrapTable('load', pq4);

				if(select=='广州区'){
					var str_data2 = localStorage.getItem("t6_data");
		        	var t6_data_s = JSON.parse(str_data2);
		        	$('.table61').bootstrapTable('load', t6_data_s);
				}else
					$('.table61').bootstrapTable('load', t6_data);
			}else if(sel_g==2){
				var str_data3 = localStorage.getItem("c3_data");
		        var t3_data_s = JSON.parse(str_data3);
		        var pq = get_home(t3_data_s,userinfo[3]);
		        $('.table21').bootstrapTable('showColumn',"分部");
				$('.table21').bootstrapTable('load', pq);

				$('.table41').bootstrapTable('showColumn',"分部");
				var pq4 = get_home(t5_data,userinfo[3]);
				$('.table41').bootstrapTable('load', pq4);

				if(select=='广州区')//无分部
					$('.table61').bootstrapTable('load', t6_data);
				else{
					//不停判断分点部改变，不用select1的change来判断
					$('.table61').bootstrapTable('load', t7_data);
				}
			}
		}else{
			if(sel_g==1){
				$('.table21').bootstrapTable('hideColumn',"分部");
				var pq = get_home(t2_data,userinfo[3]);
				$('.table21').bootstrapTable('load', pq);

				$('.table41').bootstrapTable('hideColumn',"分部");
		        var pq4 = get_home(t4_data,userinfo[3]);
				$('.table41').bootstrapTable('load', pq4);

				$('.table61').bootstrapTable('load', t6_data);

			}else if(sel_g==2){
				$('.table21').bootstrapTable('showColumn',"分部");
				var pq = get_home(t3_data,userinfo[3]);
				$('.table21').bootstrapTable('load', pq);

				$('.table41').bootstrapTable('showColumn',"分部");
				var pq4 = get_home(t5_data,userinfo[3]);
				$('.table41').bootstrapTable('load', pq4);

				if(select=='广州区')//无分部
					$('.table61').bootstrapTable('load', t6_data);
				else{
					$('.table61').bootstrapTable('load', t7_data);
				}
			}
		}
		
	}


	//展示所在片区
	function get_home(arr,pq){
		var fb_arr = new Array();
		if(pq!='广州区'){
			$(arr).each(function(index,element){
				if(element['片区']=='广州区')fb_arr.push(element);
				else if(element['片区']==pq){
					fb_arr.push(element);
				}
			});
		}else fb_arr = arr;
		
		return fb_arr;
	}

	function get_t2(time){
		ajaxcan("../../table/shichang/daily_t2.php",{"time":time},"GET",0,function(data){
				t2_data = eval("("+data+")");
				// if(sel_g==1){
				// 	$('.table21').bootstrapTable('hideColumn',"分部");
				// 	var pq = get_home(t2_data,userinfo[3]);
				// 	$('.table21').bootstrapTable('load', pq);
				// }
	        	
		});
	}

	function get_t3(time,pq){
		ajaxcan("../../table/shichang/daily_t3.php",{"time":time,'pq':pq},"GET",0,function(data){
				t3_data = eval("("+data+")");
				// if(sel_g==2){
				// 	var pq = get_home(t3_data,userinfo[3]);
			 //        $('.table21').bootstrapTable('showColumn',"分部");
				// 	$('.table21').bootstrapTable('load', pq);
				// }

		});
	}

	function get_t4(time,pq){
		ajaxcan("../../table/shichang/daily_t4.php",{"time":time,'pq':pq},"GET",0,function(data){
				t4_data = eval("("+data+")");
				// if(sel_g==1){
				// 	$('.table41').bootstrapTable('hideColumn',"分部");
				// 	var pq4 = get_home(t4_data,userinfo[3]);//可能get_t5还没加载完
				// 	$('.table41').bootstrapTable('load', pq4);
				// }
		});
	}

	function get_t5(time,pq){
		ajaxcan("../../table/shichang/daily_t5.php",{"time":time,'pq':pq},"GET",0,function(data){
				t5_data = eval("("+data+")");
				// if(sel_g==2){
				// 	$('.table41').bootstrapTable('showColumn',"分部");
				// 	var pq4 = get_home(t5_data,userinfo[3]);//可能get_t5还没加载完
				// 	$('.table41').bootstrapTable('load', pq4);
				// }
		});
	}

	function get_t6(time,pq){
		ajaxcan("../../table/shichang/daily_t6.php",{"time":time,'pq':pq},"GET",0,function(data){	
				t6_data = eval("("+data+")");
				// if(sel_g==1){
		  //       	$('.table61').bootstrapTable('load', t6_data);
		  //       }
		});
	}


	function get_t7(time,pq,fb){
		ajaxcan("../../table/shichang/daily_t7.php",{"time":time,'pq':pq,'fb':fb},"GET",0,function(data){
			t7_data = eval("("+data+")");
			// if(sel_g==2)
			// 	$('.table61').bootstrapTable('load', t7_data);
		});
	}

	 //返回select的内容数组
	function get_select_arr(id){
	    var op_arr = new Array();
	    $(""+id+" option").each(function(){    
	          var txt = $(this).val();   //获取option值   
	          if(txt!=''){  
	              op_arr.push(txt); 
	          }  
	    });

	    return op_arr;
	}



</script>

</head>
<body>
<?php require '../home/header.php';?>
<!-- <i id='icon' style="position: absolute; color: black;left: 60%;top:19%;"></i> -->
<div class="main_content">
	<div class="row1">
		<span>市场监控日报</span>
		<input type="text" class="ts" />
		<select class="selectss" id="select">
		  <option  selected="selected">广州区</option>
		  <option>小友战队</option>
		  <option>成钦战队</option>
		  <option>海山战队</option>
		  <option>浩昌战队</option>
		  <option>永超战队</option>
		  <option>张悦战队</option>
		</select>
		<select class="selectss" id="select1">
		</select>
	</div>
	<div class="data">
		<div class="header">
			<ul>
				<li class="l1"><a name='1' class="a1">整体业务</a></li>
				<li class="l1"><a name='2' class="a1">片区业务</a></li>
				<li class="l1"><a name='3' class="a1">月结散单业务</a></li>
				<li class="l1"><a name='4' class="a1">产品业务</a></li>
			</ul>
		</div>
		<div class="datas1">
			<div class="r1">
				<h2 class="title">大区业务总览</h2>
				<div class="chart t1">
					<p>收入</p>
					<table class="table">
					 <tbody id="tbody1">
					    <tr>
					      <th></th>
					      <th>当天</th>
					      <th>当月</th>
					      <th>当年</th>
					    </tr>
					  </tbody>
					</table>
					<div class="m2">
						<p>当日<spn class="s1">x</spn><i class="i1" id="l1">50% (目标100,达成50,差额-50)</i></p>
						<p>当月<spn class="s1">x</spn><i class="i1" id="l2">50% (目标100,达成50,差额-50)</i></p>
						<p>当年<spn class="s1">x</spn><i class="i1" id="l3">50% (目标100,达成50,差额-50)</i></p>
					</div>
				</div>
				<div class="chart t2">
					<p>件量</p>
					<table class="table">
					 <tbody id="tbody2">
					    <tr>
					      <th></th>
					      <th>当天</th>
					      <th>当月</th>
					      <th>当年</th>
					    </tr>
					  </tbody>
					</table>
					<div class="m2">
						<p>当日<spn class="s1">x</spn><i class="i1" id="l4">50%(目标：100 达成：50，差额-50)</i></p>
						<p>当月<spn class="s1">x</spn><i class="i1" id="l5">50%(目标：100 达成：50，差额-50)</i></p>
						<p>当年<spn class="s1">x</spn><i class="i1" id="l6">50%(目标：100 达成：50，差额-50)</i></p>
					</div>
				</div>
			</div>
			<div class="r2">
				<h2 class="title">大区业务过程</h2>
				<div class="chart t3">
					<p>收入</p>
					<table class="table">
					 <tbody id="tbody3">
					    <tr>
					      <th></th>
					      <th>当月</th>
					      <th>当年</th>
					    </tr>
					  </tbody>
					</table>
				</div>
				<div class="chart t4">
					<p>件量</p>
					<table class="table">
					 <tbody id="tbody4">
					    <tr>
					      <th></th>
					      <th>当月</th>
					      <th>当年</th>
					    </tr>
					  </tbody>
					</table>
				</div>
			</div>
			<div class="r3">
				<h2 class="title">整体业务趋势</h2>
				<div class="chart t5">
					<div id="c1"></div>
				</div>
			</div>
		</div>
		<div class="datas2 dq">
			<h2>收入达成率</h2>
			<div class="select"><span name='sel1' class="btn btn-primary sel">片区</span><span name='sel2' class="btn btn-primary sel">分部</span></div>
			<table class="table21" data-classes="table table-bordered"></table>
		</div>
		<!-- <div class="datas2 pq">
			<h2>截止<?php echo date('m-d');?>,XX点部本月收入达成率最低</h2>
			<div class="select"><span class="btn btn-primary sel">分部</span><span class="btn btn-primary sel">分部下属</span></div>
			<table class="table31" data-classes="table table-bordered"></table>
		</div> -->
		<div class="datas3 dq3">
			<h2>月结散单大区</h2>
			<div class="select"><span name='sel1' class="btn btn-primary sel">片区</span><span class="btn btn-primary sel" name='sel2'>分部</span></div>
			<table class="table41" data-classes="table table-bordered"></table>
		</div>
		<!-- <div class="datas3 pq3">
			<h2>月结散单片区</h2>
			<div class="select"><span class="btn btn-primary sel">分部</span><span class="btn btn-primary sel">分部下属</span></div>
			<table class="table51" data-classes="table table-bordered"></table>
		</div> -->

		<div class="datas4 dq4">
			<h2>大区业务数据</h2>
			<div class="select"><span name='sel1' class="btn btn-primary sel">片区</span><span class="btn btn-primary sel" name='sel2'>分部</span></div>
			<table class="table61" data-classes="table table-bordered"></table>
		</div>
		<!-- <div class="datas4 pq4">
			<h2>点部业务数据</h2>
			<div class="select"><span class="btn btn-primary sel">分部</span><span class="btn btn-primary sel">分部下属</span></div>
			<table class="table71" data-classes="table table-bordered"></table>
		</div> -->
	</div>
	
</div>

<?php include_once('../home/footer.php');?>
</body>
</html>

