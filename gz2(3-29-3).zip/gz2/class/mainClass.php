<?php

class mainClass{
	public $ip;
	public $host;
	public $url;
	public $now;
	public $date;
	public $jm;
	

	public $adminid;
	public $adminuser;
	public $adminname;


	public function __construct(){
		$this->ip		= isset($_SERVER['REMOTE_ADDR'])	? $_SERVER['REMOTE_ADDR']	: '' ;
		$this->host		= isset($_SERVER['HTTP_HOST'])		? $_SERVER['HTTP_HOST']		: '' ;
		// $this->now		= $this->now();
		$this->date		= date('Y-m-d');
		$this->lvlaras  = explode(',','select ,alter table,delete ,drop ,update ,insert into,load_file,outfile,select*from,select*,select%20,delete%20,drop%20,and%20');
	}

	public function init(){
		//引用加密模块
		$this->jm = new jmClass();
		$this->adminid	= (int)$this->session('adminid',0);
		$this->adminname= $this->session('adminname');
		$this->adminuser= $this->session('adminuser');

	}


	public function get($name,$dev='', $lx=0)
	{
		$val=$dev;
		if(isset($_GET[$name]))$val=$_GET[$name];
		if($this->isempt($val))$val=$dev;
		return $this->jmuncode($val, $lx, $name);
	}

	public function jmuncode($s, $lx=0, $na)
	{
		$jmbo = false;
		$s=str_replace("'", '&#39', $s);
		$str = strtolower($s);
		foreach($this->lvlaras as $v1)if($this->contain($str, $v1)){
			$this->debug(''.$na.'《'.$s.'》error:包含非法字符《'.$v1.'》','params');
			$s = str_replace($v1,'', $str);
		}
	
		return $s;
	}

	public function session($name,$dev='')
	{
		$val	= '';
		if(isset($_SESSION[$name]))$val=$_SESSION[$name];
		if($this->isempt($val))$val=$dev;
		return $val;
	}

	public function savesession($arr){
		foreach($arr as $kv=>$vv)$this->setsession($kv,$vv);
	}

	public function setsession($k, $v){

		$_SESSION[$k] = $v;
	}

	public function clearsession($name){
		$arrn=explode(',',$name);
		for($i=0;$i<count($arrn);$i++){
			@$_SESSION[$arrn[$i]]='';
		}
	}

	public function clearallsession(){
		foreach($_SESSION as $key=>$value){
			$this->clearsession($key);
		}
	}

	//保存cookie，默认是7天 一一对应
	public function savecookie($namarr,$valarr,$expire){
		$time = time()+$expire*3600*24;
		$arrn	= explode(',',$namarr);
		$valn	= $valarr;
		if(!is_array($valarr))$valn=explode(',',$valarr);
		for($i=0;$i<count($arrn);$i++){
			if($expire==0) setcookie($arrn[$i],$valn[$i]);
			else setcookie($arrn[$i],$valn[$i], $time);
		}
	}
	//获取cookie
	public function cookie($name,$dev='')
	{
		$val	= '';
		$name 	= $name;
		if(isset($_COOKIE[$name]))$val= addslashes(sprintf("%s",$_COOKIE[$name]));
		if($this->isempt($val))$val=$dev;//用默认值
		return $val;
	}
	
	public function getcookie($namarr)
	{
		$arrn=explode(',',$namarr);
		for($i=0;$i<count($arrn);$i++){
			$val[$arrn[$i]]=$this->cookie($arrn[$i]);
		}
		return $val;
	}
	
	//删除cookie 设置前天过期
	
	//删除所有cookie
	public function clearallcookie()
	{
		foreach($_COOKIE as $key=>$value){
			$this->clearcookie($key);
		}
	}	

	public function post($name,$dev='', $lx=0){
		$val  = '';
		if(isset($_POST[$name])){$val=$_POST[$name];}else{if(isset($_GET[$name]))$val=$_GET[$name];}
		if($this->isempt($val))$val=$dev;
		return $val;
	}
	
	public function contain($str,$a)
	{
		$bool=false;
		if(!$this->isempt($a) && !$this->isempt($str)){
			$ad=strpos($str,$a);
			if($ad>0||!is_bool($ad))$bool=true;
		}
		return $bool;
	}

	//判断是否为空
	public function isempt($str)
	{
		$bool=false;
		if( ($str==''||$str==NULL||empty($str)) && (!is_numeric($str)) )$bool=true;
		return $bool;
	}
	
	
}
