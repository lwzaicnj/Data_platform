<?php
//sql 初始函数，传进对应数据库
class sql{

	public $servername;  
	public $uid;
	public $passwd;
	public $dbname;
	public $conn;

	public function __construct($server,$db){
		$this->servername = $server;
        $this->dbname = $db;
        //freetds上面的实例名
        if($server=='sqlxz2012'){
            $this->uid = '01371818';
            $this->passwd ='01371818';
        }elseif($server=='sql2012'){
            $this->uid = '01196936';
            $this->passwd ='01196936';
        }
        $this->initSql(); 
    }

    protected function initSql(){

    	$this->conn = mssql_connect($this->servername, $this->uid,$this->passwd) or die("链接数据库出错");
    }

    public function query($sql){
    	if($this->conn){
            ini_set('mssql.charset', 'UTF-8');//手动设置mssql编码
            ini_set("memory_limit","-1");//缓存大小无限制
            //选择数据库
            mssql_select_db($this->dbname, $this->conn);
    		return @mssql_query($sql, $this->conn);
        }
    }

    public function fetch_arr($rs){

    	return mssql_fetch_array($rs);
    }

}

// $db = new sql('sql2012','SF_T');

// $rs = $db->query("select top 5 * from dbo.time");

// while ($row=$db->fetch_arr($rs)) {
//    var_dump($row);
// }
