<?php
date_default_timezone_set('Asia/Shanghai');

class manageClass{

	public	$userid;
	public 	$username;
	public 	$userbelong;
	public  $web;
	public  $useraction;
	private $time;

	//id:工号 name:中文名 department:所属部门
	public function __construct($id,$name,$department)
	{
		$this->userid = $id;
		$this->username	= $name;
		$this->userbelong	= $department;
		if(strpos($_SERVER["HTTP_USER_AGENT"],"MSIE 8.0")) 
			$this->web	= 'IE8'; 
		else if(strpos($_SERVER["HTTP_USER_AGENT"],"MSIE 9.0")) 
			$this->web	= 'IE9';  
		else if(strpos($_SERVER["HTTP_USER_AGENT"],"MSIE")) 
			$this->web	= 'IE'; 
		else if(strpos($_SERVER["HTTP_USER_AGENT"],"Firefox")) 
			$this->web	= 'Firefox'; 
		else if(strpos($_SERVER["HTTP_USER_AGENT"],"Chrome")) 
			$this->web	= 'Chrome'; 
		else if(strpos($_SERVER["HTTP_USER_AGENT"],"Safari")) 
			$this->web	= 'Safari';
		else if(strpos($_SERVER["HTTP_USER_AGENT"],"Opera")) 
			$this->web	= 'Opera';
		else $this->web = 'IE';  

		// $this->useraction = '234';
	}
	
	public function saveAction()
	{	
		$this->time	= date('Y-m-d H:i:s');
		include_once 'sql_class.php';
		$sql_db = new sql('sqlxz2012',"IT_test");
		$sql = "INSERT INTO dbo.it_log (userid,username,department,action,web,time) VALUES ('".$this->userid."','".$this->username."','".$this->userbelong."','".addslashes($this->useraction)."','".$this->web."','".$this->time."')";
		$result = $sql_db->query($sql);
		// echo $sql;
		// return $result;
	}
	
}
