<?php
ini_set('date.timezone','Asia/Shanghai');
include_once 'includes/public_inc_func.php';
include_once 'class/mainClass.php';
include_once 'class/jmClass.php';
include_once 'class/sql_class.php';
include_once 'class/manageClass.php';
include_once 'includes/string_convert.php';

$main = new mainClass();
$main->init();

// if(isset($_GET['logout'])){
//     //注销
//     $main->savecookie('unique_id','1',-1);
// }

//临时接口开始
 //$unique_id = uniqid(rand());

 // $main->savecookie('unique_id', 1,0);//设置过期为0才行

 // _location("model/home/index_home.php");
//临时接口结束

$us_name =  $_SESSION['phpCAS']['user'];	
//调用数据库连接类
$sql_db = new sql("sqlxz2012","IT_test");

//临时cookie，判断窗口是否关闭
if(!isset($_COOKIE['unique_id'])){
    //_alert('11');
    $ip = $_SERVER['REMOTE_ADDR'];
  
    $sql = "SELECT username,unique_id,login_count FROM dbo.it_users WHERE username='".$us_name."'";
    $result = $sql_db->query($sql);

    $row = $sql_db->fetch_arr($result);

    $_SESSION['manage'] = new manageClass($us_name,'未知','未知');
    $_SESSION['manage']->useraction = "登录成功";

    $_SESSION['manage']->saveAction();

    if($row['username']!=$us_name){
        //第一次登录 生成唯一id
        $unique_id = uniqid(rand());

        $main->savecookie('unique_id',$unique_id,0.1);//设置过期为0才行,关闭浏览器失效
        //注意插入列数量
        $sql = "INSERT INTO dbo.it_users VALUES('".$us_name."','".md5($unique_id)."','".$unique_id."','".date('Y-m-d H:i:s')."','1','".$ip."','未知','2','未知','4',0,0,'广州区','广州区')";
        // echo $sql;
        $sql_db->query($sql);
    }else{
        //已经登录过，更新时间和次数 ip
        $main->savecookie('unique_id',$row['unique_id'],0.1);
        $sql = "UPDATE dbo.it_users SET login_time='".date('Y-m-d H:i:s')."',login_count='".(addslashes($row['login_count'])+1)."',ip='".$ip."' WHERE username='".$us_name."'";
        $sql_db->query($sql);
    }
    _location("gz");
}else{
    //_alert('222'); 
    //已有 uniqueid:渲染账号密码？
    // var_dump($_COOKIE);
    //记住唯一id的登录，更新登录次数和时间 IP相同
    $unique_id = $main->cookie('unique_id');
    $sql = "UPDATE dbo.it_users SET login_time='".date('Y-m-d H:i:s')."',login_count=login_count+1 WHERE unique_id='".$unique_id."'";
    $sql_db->query($sql);
    _location("gz");
}

?>
