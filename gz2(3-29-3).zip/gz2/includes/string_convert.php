<?php

function gbk2utf8($string){

	return iconv('GBK','UTF-8//IGNORE',$string);
}

function utf82gbk($string){

	return iconv('UTF-8','GB2312//ignore',$string);
}