<link rel="stylesheet" type="text/css" href="../jquery/css/jquery-ui.css" /> 
<script type="text/javascript" src="../jquery/js/jquery-ui.js"></script> 
<script type="text/javascript" src="../jquery/js/jquery-ui-timepicker-addon.js"></script> 