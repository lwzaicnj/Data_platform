<link rel="stylesheet" href="../../bootstrap-3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="../../bootstrap-table-master/src/bootstrap-table.css">

<script src="../../jquery/js/jquery.1.9.1.min.js"></script>
<script src="../../bootstrap-3.3.7/js/bootstrap.min.js"></script>
<script src="../../bootstrap-table-master/src/bootstrap-table.js"></script>
<script src="../../bootstrap-table-master/src/locale/bootstrap-table-zh-CN.js"></script>
<script src="../../bootstrap-table-master/src/extensions/export/bootstrap-table-export.js"></script>
<script src="../../jquery/js/base64-min.js"></script>
<script src="../../js/tableExport.min.js"></script>

<!-- 图表 -->
<script src="../../js/Chart.min.js"></script>
<script src="../../js/echarts.js"></script>


<!--调用等待提示-->
 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="../../css/show_wait.css">

 <!--自定义插件-->
<link rel="stylesheet" href="../../css/cangguan.css" />
<script type="text/javascript" src="../../js/jquery.jedate.js"></script>
<link type="text/css" rel="stylesheet" href="../../css/jedate.css">
<script type="text/javascript" src="../../js/js_func/main_func.js"></script>

<!--首页头文件-->
<link rel="shortcut icon" href="../../images/favicon1.ico">

<!-- Font Awesome CSS -->
<link href="../../fonts/font-awesome/css/font-awesome.css" rel="stylesheet">

<!-- Fontello CSS -->
<link href="../../fonts/fontello/css/fontello.css" rel="stylesheet">

<!-- Plugins -->
<link href="../../plugins/rs-plugin/css/settings.css" media="screen" rel="stylesheet">
<link href="../../plugins/rs-plugin/css/extralayers.css" media="screen" rel="stylesheet">
<link href="../../plugins/magnific-popup/magnific-popup.css" rel="stylesheet">
<link href="../../css/animations.css" rel="stylesheet">
<link href="../../plugins/owl-carousel/owl.carousel.css" rel="stylesheet">

<link href="../../css/style.css" rel="stylesheet">
<link href="../../css/skins/green.css" rel="stylesheet">

<!-- Custom css --> 
<link href="../../css/custom.css" rel="stylesheet">

<script type="text/javascript"  src="../../js/html5shiv.js"></script>
<script type="text/javascript" src="../../js/selectivizr.js"></script>

<!-- Modernizr javascript -->
<script type="text/javascript" src="../../plugins/modernizr.js"></script>

<!-- jQuery REVOLUTION Slider  -->
<script type="text/javascript" src="../../plugins/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="../../plugins/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

<!-- Isotope javascript -->
<script type="text/javascript" src="../../plugins/isotope/isotope.pkgd.min.js"></script>

<!-- Owl carousel javascript -->
<script type="text/javascript" src="../../plugins/owl-carousel/owl.carousel.js"></script>

<!-- Magnific Popup javascript -->
<script type="text/javascript" src="../../plugins/magnific-popup/jquery.magnific-popup.min.js"></script>

<!-- Appear javascript -->
<script type="text/javascript" src="../../plugins/jquery.appear.js"></script>

<!-- Count To javascript -->
<script type="text/javascript" src="../../plugins/jquery.countTo.js"></script>

<!-- Parallax javascript -->
<script src="../../plugins/jquery.parallax-1.1.3.js"></script>

<!-- Contact form -->
<script src="../../plugins/jquery.validate.js"></script>

<!-- Initialization of Plugins -->
<script type="text/javascript" src="../../js/template.js"></script>

<!-- Custom Scripts -->
<script type="text/javascript" src="../../js/custom.js"></script>