<?php
ini_set('date.timezone','Asia/Shanghai');
require 'string_convert.php';
include_once '../../class/sql_class.php'; //基于 table/.._table.php


//调用数据库连接类
$db_y = new sql('sql2012',"营运数据库");
$db_w = new sql('sql2012',"网点代码");
$db_x = new sql('sqlxz2012',"IT_test");

//获取查询得到的数据（一个）
// function get_num($result){
// 	$num = @sqlsrv_fetch_array($result)[0];
// 	return $num;
// }

//去除月份的0
function trim_0($month){

	return strpos($month, '0')===0?substr($month,1):$month;
}

//处理返回的查询数据
function get_data($rs){
	global $db_y;
	$conv = array();
	if($rs){
		while($row=$db_y->fetch_arr($rs)){
			$count=count($row);
			for($i=0;$i<$count;$i++){  
	        	unset($row[$i]);//删除冗余数据  0 1 
	    	}
	    		// var_dump($row);
		 	foreach ($row as $key => $value) {
				if($value!='%' && !empty($value))
		 			$conv[] =$value;//float->string
				else
					$conv[] = '-';
		 	}
		}
	}
	return $conv;
}

//返回所有用户及其所属片区分部
function get_user($unique_id){
	global $db_x;
	$sql = "select * from dbo.it_users where unique_id='".$unique_id."'";
	$rs = $db_x->query($sql);
	$row = $db_x->fetch_arr($rs);
	$user_info = [];
	if($row)
		$user_info = [$row['id'],$row['username'],$row['is_admin'],$row[13],$row[14]];
	return $user_info;

}

//找到所有子网点/分部代码
//key:"收入归属代码" 或者 战队
function get_all_wd($target,$wd,$key){
	//调用数据库连接类
	global $db_w;
	$wd_range = array();
	if($wd){
		$sql = "SELECT $target FROM dbo.网点代码最新 WHERE ".$key."='".$wd."'";
		// echo $sql.'</br>';
		$res = $db_w->query($sql);
		while ($row = $db_w->fetch_arr($res)){
			if(!in_array($row["$target"],$wd_range))
				$wd_range[] = addslashes($row["$target"]);
		}
	}
	return $wd_range;
}

/***********换片区函数***************/
//第二级是分部，不是网点，网点计算归属分部
function get_pq_fb(){
	global $db_w;
	$wd_details = [];
	$each_de = [];

	$sql = "SELECT distinct 最新片区 FROM dbo.网点代码最新";
	$res = $db_w->query($sql);

	if($res){
		while ($row = $db_w->fetch_arr($res)){
			$each_de[] = addslashes($row['最新片区']);
		}
	} 
	$pa_arr = ['小友战队','成钦战队','海山战队','浩昌战队','永超战队','张悦战队'];
	foreach ($each_de as $key => $value) {
		if(in_array($value, $pa_arr)){
			$sql2 = "SELECT * FROM dbo.网点代码最新 WHERE 最新片区='".$value."' order by 最新片区";
			$res = $db_w->query($sql2);
			// echo $sql2.'</br>';
			$one_pq = [];
			if($res){
				while ($row = $db_w->fetch_arr($res)){
					$wd_de = [];
					$wd_de['分部名称'] = $row[4];
					$wd_de['分部简称'] = $row[5];
					$wd_de['分部代码'] = $row[3];
					if(!in_array($wd_de,$one_pq))
						array_push($one_pq,$wd_de);
				}
			}
			$wd_details[$value] = $one_pq;
		}
		
	}
	return $wd_details;
}

//总的片区中返回对应片区的分部
function get_pqfb($arr,$pq){
	$auth_de = [];
	if($pq!='广州区'){
		foreach ($arr as $key => $value) {
			if($value['所属片区']==$pq){
				$auth_de[] = $value;
			}
		}
	}else{
		$auth_de = $arr;
	}
	
	return $auth_de;
}


/***********换片区函数结束***************/

//找到所有战队
function get_all_zd($target){
	global $db_w;
	$zd_range = [];
	$sql = "SELECT distinct $target FROM dbo.网点代码最新";
	$res = $db_w->query($sql);
	while ($row = $db_w->fetch_arr($res)){
		$zd_range[] = $row[0];
	}
	return $zd_range;
}

//仅获取分部代码和名称+简称
function get_infos(){
	global $db_x;
	$sql = "SELECT * FROM dbo.it_wangdian order by id";
	$res = $db_x->query($sql);
	$wd_detail = [];
	if($res){
		while ($row = $db_x->fetch_arr($res)){
				$wd_de = [];
				$wd_de['分部名称'] = $row['1'];
				$wd_de['分部简称'] = $row['2'];
				$wd_de['分部代码'] = $row['3'];
				$wd_de['所属片区'] = $row['4'];
				array_push($wd_detail,$wd_de);
			}
		}
	return $wd_detail;
}

//返回目标指标
function get_targets(){
	global $db_x;

	$sql = "SELECT * FROM dbo.it_target order by id";

	$result = $db_x->query($sql);

	$rs_arr = array();

	if($result){
		while($row=$db_x->fetch_arr($result)){
			$rs = array();
			$rs[] = addslashes($row['4']);
			$rs[] = addslashes($row['5']);
			$rs[] = addslashes($row['6']);
			$rs[] = addslashes($row['7']);
			$rs[] = addslashes($row['8']);//网点代码字段名
			$rs[] = addslashes($row['9']);
			$rs[] =(float)(addslashes($row['3']))/100;
			$rs_arr[$row['1']] = $rs;
			// array_push($rs_arr,$rs);
		}
	}
	return $rs_arr;
}

//获取件量和收入的目标值
//根本分部名称获取（含大区和片区）
function get_my_targets($name){
	global $db_x;

	$sql = "SELECT * FROM dbo.it_report where 分部代码=$name";

	$result = $db_x->query($sql);

	$rs_arr = array();

	// echo $sql;
	if($result){
		while($row=$db_x->fetch_arr($result)){
			$rs = array();
			$rs[] = $row['6'];
			$rs[] = $row['7'];
			$rs[] = $row['8'];
			$rs[] = $row['9'];
			$rs[] = $row['10'];//网点代码字段名
			$rs[] = $row['11'];
			$rs[] = $row['12'];
			$rs[] = $row['13'];
			$rs[] = $row['14'];
			$rs[] = $row['15'];
			$rs_arr[$row['4']] = $rs;
		}
	}
	return $rs_arr;
}


$db_s = new sql("sql2012","产品月报管报");
//查找上月市场数据 得到0.9几的参数
//param：2017-12
function get_base_rate($t){
	global $db_s;
	$year =  date("Y",strtotime("$t"));
	$month =  date("m",strtotime("$t"));
	$sql = "SELECT isnull(cast(sum([折后收入（RMB）])/nullif(sum([折前收入（RMB）]),0) as numeric(10,3)),0) as rate FROM dbo.产品月报管报2017 WHERE 月份='".$year.$month."'";

	$result = $db_s->query($sql);

	if($result)
		return $db_s->fetch_arr($result)['rate'];
	else
		return 1;//折前
}


$db_r = new sql("sql2012","保价日报");
//获取每个月工作日指标
//去计算每天达成率
//param1:2018-01-25
//param2:本月总目标
//p3:$tag: 1:本日  0：本月已过
//纯粹求比例
function get_work_day_rate($t,$tag){
	global $db_r;
	$firstday = get_fl_day($t)[0];
	$lastday =  get_fl_day($t)[1];
	$year_firstday =date("Y-01-01",strtotime("$t"));//年第一天
	$year_lastday =date("Y-12-31",strtotime("$t"));//年最后一天
	if($tag==1){
		$sql = "SELECT (SELECT 工作日  FROM [dbo].[营运工作日]  WHERE 日期='".$t."')/(SELECT sum(工作日) FROM [dbo].[营运工作日]  WHERE 日期>='".$firstday."' and 日期<='".$lastday."')";
	}elseif($tag==0){
		$sql = "SELECT (SELECT sum(工作日) FROM [dbo].[营运工作日]  WHERE 日期>='".$firstday."' and 日期<='".$t."')/(SELECT sum(工作日) FROM [dbo].[营运工作日]  WHERE 日期>='".$firstday."' and 日期<='".$lastday."')";
	}else{
		$sql = "SELECT (SELECT sum(工作日) FROM [dbo].[营运工作日]  WHERE 日期>='".$year_firstday."' and 日期<='".$t."')/(SELECT sum(工作日) FROM [dbo].[营运工作日]  WHERE 日期>='".$year_firstday."' and 日期<='".$year_lastday."')";
	}

	$result = $db_r->query($sql);
	if($result)
		return $db_r->fetch_arr($result)[0];
}


//获取日均收入
//$t:截止时间
//$income：年或月总收入/总票数
//$tag:1 月均  $tag：0 年均
function get_daily_income($t,$income,$tag){
	global $db_r;
	if($tag) $firstday = get_fl_day($t)[0];
	else $firstday =date("Y-01-01",strtotime("$t"));//年第一天
	
	$sql = "SELECT ".addslashes($income)."/sum(工作日) FROM [dbo].[营运工作日]  WHERE 日期>='".$firstday."' and 日期<='".$t."'";
	// echo $sql.'</br>';
	$result = $db_r->query($sql);
	if($result)
		return $db_r->fetch_arr($result)[0];
}


$db_e = new sql("sql2012","产品日报管报");
//获取当日、当月、当年实际收入/票数
//param1:2018-01-25
//param2:计算的字段
//[折前收入（RMB）] /票
function get_income($t,$target,$pq=NULL){
	global $db_e;
	$firstday = get_fl_day($t)[0];
	$year_first =  date("Y-01-01",strtotime("$t"));
	$condition = '';
	if($pq && $pq!='020') $condition = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码 WHERE B.最新片区='$pq'";
	$sql = "SELECT 
			SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.$target ELSE 0 END)[日],
		 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.$target ELSE 0 END)[月],
		 	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.$target ELSE 0 END)[年]
			FROM [产品日报管报].[dbo].[产品日报管报2017] A  $condition";
	// echo $sql.'</br>';
	$result = $db_e->query($sql);
	if($result)
		return $db_e->fetch_arr($result);
}

//获取7天收入
function get_week_income($t,$where=NULL){
	global $db_e;
	$day_arr = [];
	foreach (range(6,1) as $key => $value) {
		$ts = date("Y-m-d",strtotime("$t -$value day"));
		$day_arr[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.[折前收入（RMB）] ELSE 0 END)[d$key],";
	}
	$sql = "SELECT {$day_arr[0]} {$day_arr[1]} {$day_arr[2]} {$day_arr[3]} {$day_arr[4]} {$day_arr[5]} 
		 	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[d7]
			FROM [产品日报管报].[dbo].[产品日报管报2017] A ";
	// echo $sql.'</br>';
	$result = $db_e->query($sql);
	if($result)
		return $db_e->fetch_arr($result);
}

//t2页面的独立方法
//获取年月日的票数和收入
function get_t2_one($t,$pq=NULL){
	global $db_e;
	$firstday = get_fl_day($t)[0];//月初
	$year_first =  date("Y-01-01",strtotime("$t"));//年初
	$last_y_d = date("Y-m-d",strtotime("$t -1 year"));//上年同日
	$last_y_f = date("Y-m-01",strtotime("$last_y_d"));//上年同月月初
	$last_y_y = date("Y-01-01",strtotime("$last_y_d"));//上年年初
	$last_m_d = date("Y-m-d",strtotime("$t -1 month"));//上月同日
	$last_m_f = date("Y-m-01",strtotime("$last_m_d"));//上月月初
	$last_m_y = date("Y-01-01",strtotime("$last_m_d"));//上月对应年初
	
	$condition = "";
	if($pq) $condition = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码 WHERE B.最新片区='$pq'";

	$sql = "SELECT 
			SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.票数 ELSE 0 END)[日票数],
		 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.票数 ELSE 0 END)[月票数],
		 	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.票数 ELSE 0 END)[年票数],
		   	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[日收入],
		   	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[月收入],
		   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[年收入],
		   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_f' AND '$last_y_d' THEN A.票数 ELSE 0 END)[上年同月票数],
		 	SUM(CASE WHEN A.日期 BETWEEN '$last_y_y' AND '$last_y_d' THEN A.票数 ELSE 0 END)[上年截止票数],
		 	SUM(CASE WHEN A.日期 BETWEEN '$last_y_f' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上年同月收入],
		   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_y' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上年截止收入],
		   	SUM(CASE WHEN A.日期 BETWEEN '$last_m_f' AND '$last_m_d' THEN A.票数 ELSE 0 END)[上月总票数],
		 	SUM(CASE WHEN A.日期 BETWEEN '$last_m_y' AND '$last_m_d' THEN A.票数 ELSE 0 END)[上月年截止总票数],
		 	SUM(CASE WHEN A.日期 BETWEEN '$last_m_f' AND '$last_m_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上月总收入],
		 	SUM(CASE WHEN A.日期 BETWEEN '$last_m_y' AND '$last_m_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上月年截止总收入]
			FROM [产品日报管报].[dbo].[产品日报管报2017] A $condition ";

	// echo $sql;
	$result = $db_e->query($sql);
	if($result)
		return $db_e->fetch_arr($result);
}


//$target:网点或者分部
//一次处理所有网点的查询
//一个单独 SELECT B.$target 的没有重复
function get_t2_two($t,$target,$pq=NULL){
	global $db_e;
	$firstday = get_fl_day($t)[0];
	$year_first =  date("Y-01-01",strtotime("$t"));
	$last_y_d = date("Y-m-d",strtotime("$t -1 year"));//上年同日
	$last_y_f = date("Y-m-01",strtotime("$last_y_d"));//上年同月月初
	$last_y_y = date("Y-01-01",strtotime("$last_y_d"));//上年年初
	
	$condition = '';
	if($pq) $condition = "WHERE B.最新片区='$pq'";
	
	$sql = " SELECT B.$target,
 	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.票数 ELSE 0 END)[日票数],
 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.票数 ELSE 0 END)[月票数],
 	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.票数 ELSE 0 END)[年票数],
   	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[日收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[月收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[年收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_f' AND '$last_y_d' THEN A.票数 ELSE 0 END)[上年同月票数],
 	SUM(CASE WHEN A.日期 BETWEEN '$last_y_y' AND '$last_y_d' THEN A.票数 ELSE 0 END)[上年截止总票数],
 	SUM(CASE WHEN A.日期 BETWEEN '$last_y_f' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上年同月收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_y' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上年截止收入],
   	B.最新片区,B.[对应分部名称]
   FROM [产品日报管报].[dbo].[产品日报管报2017] A LEFT JOIN 网点代码.DBO.网点代码最新 B
   ON A.收件网点代码=B.网点代码  $condition 
   GROUP BY    B.$target,B.最新片区,B.[对应分部名称]";
   // echo $sql;
   $result = $db_e->query($sql);
   $rows = [];
   if($result){
   	  while ($row=$db_e->fetch_arr($result)) {
   	  	if($row[0]){
   	  		$rows[$row[0]] = $row;
   	  		}
   	  	}
   }
   return $rows;
}

//获取月收件量。来计算前十的进度排名
function get_t2_top($t,$wh,$pq=NULL){
	global $db_e;
	$firstday = get_fl_day($t)[0];
	$where = "";
	if($wh){
		$where = "where $wh";
	}
	if($wh && $pq)	$where = "where $wh AND B.最新片区='$pq' ";
	if(!$wh && $pq) $where = "where B.最新片区='$pq' ";

	$sql = " SELECT A.收件网点代码,B.网点名称,
 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.票数 ELSE 0 END)[月票数]
   FROM [产品日报管报].[dbo].[产品日报管报2017] A LEFT JOIN 网点代码.DBO.网点代码最新 B
   ON A.收件网点代码=B.网点代码 $where GROUP BY  A.收件网点代码,B.网点名称";
   // echo $sql;
   $result = $db_e->query($sql);
   $rows = [];
   if($result){
   	  while ($row=$db_e->fetch_arr($result)) {
   	  	if($row[0] && $row[1]){
   	  			$row[1] = $row[1];
   	  			$rows[] = $row;
   	  		}
   	  	}
   }
   return $rows;
}

//保价top
function get_t2_top_b($t,$wh,$pq=NULL){
	global $db_r;
	$firstday = get_fl_day($t)[0];
	$where = '';
	if($wh){
		$where = "where $wh";
	}
	if($wh && $pq)	$where = "where $wh AND B.最新片区='$pq' ";
	if(!$wh && $pq) $where = "where B.最新片区='$pq' ";

	$sql = " SELECT A.收件网点代码,B.网点名称,
 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[增值服务票数] ELSE 0 END)[月票数]
   FROM [保价日报].[dbo].[保价日报清单] A LEFT JOIN 网点代码.DBO.网点代码最新 B
   ON A.收件网点代码=B.网点代码 $where GROUP BY  A.收件网点代码,B.网点名称";
   // echo $sql;
   $result = $db_r->query($sql);
   $rows = [];
   if($result){
   	  while ($row=$db_r->fetch_arr($result)) {
   	  	if($row[0] && $row[1]){
   	  			$row[1] = $row[1];
   	  			$rows[] = $row;
   	  		}
   	  	}
   }
   return $rows;
}

//代收服务费top 最低一级的网点，不是分部的排序
function get_t2_top_s($t,$pq=NULL){
	global $db_r;
	$firstday = get_fl_day($t)[0];
	$where = "";
	if($pq) $where = "WHERE B.最新片区='$pq' ";
	$sql = " SELECT A.原寄地网点,B.网点名称,
 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[成功票数] ELSE 0 END)[月票数]
   FROM [保价日报].[dbo].[代收货款2017] A LEFT JOIN 网点代码.DBO.网点代码最新 B
   ON A.原寄地网点=B.网点代码 $where GROUP BY  A.原寄地网点,B.网点名称";
   // echo $sql;
   $result = $db_r->query($sql);
   $rows = [];
   if($result){
   	  while ($row=$db_r->fetch_arr($result)) {
   	  	if($row[0] && $row[1]){
   	  			$row[1] = $row[1];
   	  			$rows[] = $row;
   	  		}
   	  	}
   }
   return $rows;
}

//把重复的叠加
//求月结和散单
function get_t2_three($t,$target=0,$pq=NULL){
	global $db_e;
	$firstday = get_fl_day($t)[0];
	$year_first =  date("Y-01-01",strtotime("$t"));
	$last_m_d = date("Y-m-d",strtotime("$t -1 month"));//上月同日
	$last_y_d = date("Y-m-d",strtotime("$t -1 year"));//上年同日
	
	$condition = "";
	if($pq) $condition = "WHERE B.最新片区='$pq'";

	$day_arr = [];
	$day_arr_m = [];$day_arr_y = [];
	$day_arr_j = [];
	foreach (range(6,1) as $key => $value) {
		$ts = date("Y-m-d",strtotime("$t -$value day"));
		$tms = date("Y-m-d",strtotime("$last_m_d -$value day"));
		$tys = date("Y-m-d",strtotime("$last_y_d -$value day"));
		$day_arr[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.[折前收入（RMB）] ELSE 0 END)[d$key]";
		$day_arr_m[] = "SUM(CASE WHEN A.日期 BETWEEN '$tms' AND '$tms' THEN A.[折前收入（RMB）] ELSE 0 END)[dm$key]";
		$day_arr_y[] = "SUM(CASE WHEN A.日期 BETWEEN '$tys' AND '$tys' THEN A.[折前收入（RMB）] ELSE 0 END)[dy$key]";
		$day_arr_j[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.票数 ELSE 0 END)[dj$key]";
	}
	
	$c1=$c2=$c3="";
	if($target){
		$c1 = "B.$target,";
		$c2= "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码  $condition GROUP BY    A.客户类型,B.$target,B.最新片区";
		$c3= ",B.最新片区";
	}else{
		$c2 = "GROUP BY  A.客户类型";
	}

	$sql = " SELECT A.客户类型,$c1
 	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.票数 ELSE 0 END)[日票数],
 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.票数 ELSE 0 END)[月票数],
   	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[日收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[月收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.票数 ELSE 0 END)[年票数],
   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[年收入],
	{$day_arr[0]},{$day_arr[1]},{$day_arr[2]},{$day_arr[3]},{$day_arr[4]},{$day_arr[5]},
   	{$day_arr_m[0]},{$day_arr_m[1]},{$day_arr_m[2]},{$day_arr_m[3]},{$day_arr_m[4]},{$day_arr_m[5]},
   	SUM(CASE WHEN A.日期 BETWEEN '$last_m_d' AND '$last_m_d' THEN A.[折前收入（RMB）] ELSE 0 END)[dm6],
   	{$day_arr_y[0]},{$day_arr_y[1]},{$day_arr_y[2]},{$day_arr_y[3]},{$day_arr_y[4]},{$day_arr_y[5]},
   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_d' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[dy6],
	{$day_arr_j[0]},{$day_arr_j[1]},{$day_arr_j[2]},{$day_arr_j[3]},{$day_arr_j[4]},{$day_arr_j[5]} $c3 
   FROM [产品日报管报].[dbo].[产品日报管报2017] A $c2";
   // echo $sql.'</br>';
   $result = $db_e->query($sql);
   $rows = [];
   if($result){
	   	 if($target){
		   	 while ($row=$db_e->fetch_arr($result)) {
		   	  	$row[0] = $row[0];
		   	  	$row[1] = $row[1];
		   	  	if($row[0] && $row[1]){
		   	  		if(!$rows) array_push($rows,$row);
		   	  		else{
		   	  			$i = 0;
		   	  			foreach ($rows as $key => $value) {
		   	  				//战队和客户类型一样
		   	  				if($value[0]==$row[0] && $value[1]==$row[1]){
		   	  					//叠加
		   	  					$i = 1;
		   	  					$rows[$key][2] += $row[2];
		   	  					$rows[$key][3] += $row[3];
		   	  					$rows[$key][4] += $row[4];
		   	  					$rows[$key][5] += $row[5];
		   	  				}
		   	  			}
		   	  			if(!$i) array_push($rows,$row);
		   	  		}
		   	  	}
		   	  }
		 }else{
		 	while ($row=$db_e->fetch_arr($result)){
		 		$row[0] = $row[0];

		 		if($row[0])
		 			array_push($rows,$row);
		 	}	
		 }
   }
   return $rows;//同一类别返回散客和月结各一
}


//获取业务数据
//$target:片区、分部字段
//$name:片区、分部的名字
function get_t2_four($t,$target,$name){
	global $db_e;
	$firstday = get_fl_day($t)[0];//月初
	$last_w_d =  date("Y-m-d",strtotime("$t -7 day"));//上周同日
	$last_w_f =  date("Y-m-01",strtotime("$last_w_d"));//上周对应的月初
	$last_m_d = date("Y-m-d",strtotime("$t -1 month"));//上月同日
	$last_m_f = date("Y-m-01",strtotime("$last_m_d"));//上月月初
	$last_y_d = date("Y-m-d",strtotime("$t -1 year"));//上年同日
	$last_y_f = date("Y-m-01",strtotime("$last_y_d"));//上年同月月初

 	$sql = " SELECT B.$target,A.产品名称,A.产品所属版块名称,
 	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[当日收入],
 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[当月截止收入],
 	SUM(CASE WHEN A.日期 BETWEEN '$last_w_f' AND '$last_w_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上周截止收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$last_m_f' AND '$last_m_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上月截止收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_f' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上年同月截止收入]
   FROM [产品日报管报].[dbo].[产品日报管报2017] A  LEFT JOIN 网点代码.DBO.网点代码最新 B
   ON A.收件网点代码=B.网点代码 WHERE $target='$name'
   GROUP BY B.$target,A.产品名称,A.产品所属版块名称";

   // echo $sql.'</br>';
   $result = $db_e->query($sql);
   $rows = [];
   if($result){
   	  while ($row=$db_e->fetch_arr($result)) {
   	  	if($row[0]){
	   	  		$row[0] = $row[0];
	   	  		$row[1] = $row[1];
	   	  		$row[2] = $row[2];
	   	  		array_push($rows,$row);
   	  		}
   	  	}
   }
   return $rows;
}

//c2和t6重复
//获取大区数据
//$tag:1 :获取有条件的大区数据
// function get_t2_four_all($t,$tag=0){
// 	$db_e = new sql("","产品日报管报");
// 	$firstday = get_fl_day($t)[0];//月初
// 	$year_first =  date("Y-01-01",strtotime("$t"));//年初
// 	$last_w_d =  date("Y-m-d",strtotime("$t -7 day"));//上周同日
// 	$last_w_f =  date("Y-m-01",strtotime("$last_w_d"));//上周对应的月初
// 	$last_m_d = date("Y-m-d",strtotime("$t -1 month"));//上月同日
// 	$last_m_f = date("Y-m-01",strtotime("$last_m_d"));//上月月初
// 	$last_y_d = date("Y-m-d",strtotime("$t -1 year"));//上年同日
// 	$last_y_f = date("Y-m-01",strtotime("$last_y_d"));//上年同月月初
// 	//求七日收入（加上上月和上年的）
// 	$day_arr = [];
// 	$day_arr_m = [];$day_arr_y = [];
// 	$day_arr_jl = [];
// 	// $month_aver = [];//求月总收入
// 	// $month_aver_j = [];//求月总件量
// 	foreach (range(6,1) as $key => $value) {
// 		$ts = date("Y-m-d",strtotime("$t -$value day"));
// 		$tms = date("Y-m-d",strtotime("$last_m_d -$value day"));
// 		$tys = date("Y-m-d",strtotime("$last_y_d -$value day"));
// 		$day_arr[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.[折前收入（RMB）] ELSE 0 END)[d$key]";
// 		$day_arr_m[] = "SUM(CASE WHEN A.日期 BETWEEN '$tms' AND '$tms' THEN A.[折前收入（RMB）] ELSE 0 END)[dm$key]";
// 		$day_arr_y[] = "SUM(CASE WHEN A.日期 BETWEEN '$tys' AND '$tys' THEN A.[折前收入（RMB）] ELSE 0 END)[dy$key]";
// 		$day_arr_jl[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.票数 ELSE 0 END)[dj$key]";
// 		// $month_f = get_fl_day($ts)[0];
// 		// $month_aver[] = "SUM(CASE WHEN A.日期 BETWEEN '$month_f' AND '$ts' THEN A.[折前收入（RMB）] ELSE 0 END)[dp$key]";
// 		// $month_aver_j[] = "SUM(CASE WHEN A.日期 BETWEEN '$month_f' AND '$ts' THEN A.票数 ELSE 0 END)[dpj$key]";
// 	}
// 	$where = "";
// 	if($tag) $where = " WHERE $tag";
// 	//新增四个
//  	$sql = " SELECT 
//  	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[当日收入],
//  	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[当月截止收入],
//  	SUM(CASE WHEN A.日期 BETWEEN '$last_w_f' AND '$last_w_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上周截止收入],
//    	SUM(CASE WHEN A.日期 BETWEEN '$last_m_f' AND '$last_m_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上月截止收入],
//    	SUM(CASE WHEN A.日期 BETWEEN '$last_y_f' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上年同月截止收入],
//    	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[年收入],
//    	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.票数 ELSE 0 END)[日票数],
//    	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.票数 ELSE 0 END)[月票数],
//    	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.票数 ELSE 0 END)[年票数],
//    	{$day_arr[0]},{$day_arr[1]},{$day_arr[2]},{$day_arr[3]},{$day_arr[4]},{$day_arr[5]},
//    	{$day_arr_m[0]},{$day_arr_m[1]},{$day_arr_m[2]},{$day_arr_m[3]},{$day_arr_m[4]},{$day_arr_m[5]},
//    	SUM(CASE WHEN A.日期 BETWEEN '$last_m_d' AND '$last_m_d' THEN A.[折前收入（RMB）] ELSE 0 END)[dm6],
//    	{$day_arr_y[0]},{$day_arr_y[1]},{$day_arr_y[2]},{$day_arr_y[3]},{$day_arr_y[4]},{$day_arr_y[5]},
//    	SUM(CASE WHEN A.日期 BETWEEN '$last_y_d' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[dy6],
//    	{$day_arr_jl[0]},{$day_arr_jl[1]},{$day_arr_jl[2]},{$day_arr_jl[3]},{$day_arr_jl[4]},{$day_arr_jl[5]}

//    FROM [产品日报管报].[dbo].[产品日报管报2017] A $where";

//    // echo $sql.'</br>';
//    $result = $db_e->query(utf82gbk($sql));
//    if($result)
//    	  return $db_e->fetch_arr($result);
// }

//合并大区的重货和国际件等
function get_t6_all($t,$pq=NULL){
	global $db_e;
	$where_arr = [''," WHERE A.产品名称='重货快运'"," WHERE (A.产品名称='物流普运' or A.产品名称='重货包裹' or A.产品名称='小票零担' or A.产品名称='专线普运')"," WHERE A.产品所属版块名称='国际'"];

	$condition = $condition1 = '';
	if($pq && $pq!='020'){
		$condition = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码 ";
		$condition1 =  " AND B.最新片区='$pq'";
	} 
	$firstday = get_fl_day($t)[0];//月初
	$year_first =  date("Y-01-01",strtotime("$t"));//年初
	$last_w_d =  date("Y-m-d",strtotime("$t -7 day"));//上周同日
	$last_w_f =  date("Y-m-01",strtotime("$last_w_d"));//上周对应的月初
	$last_m_d = date("Y-m-d",strtotime("$t -1 month"));//上月同日
	$last_m_f = date("Y-m-01",strtotime("$last_m_d"));//上月月初
	$last_y_d = date("Y-m-d",strtotime("$t -1 year"));//上年同日
	$last_y_f = date("Y-m-01",strtotime("$last_y_d"));//上年同月月初
	//求七日收入（加上上月和上年的）
	$day_arr = [];
	$day_arr_m = [];$day_arr_y = [];
	$day_arr_jl = [];
	foreach (range(6,1) as $key => $value) {
		$ts = date("Y-m-d",strtotime("$t -$value day"));
		$tms = date("Y-m-d",strtotime("$last_m_d -$value day"));
		$tys = date("Y-m-d",strtotime("$last_y_d -$value day"));
		$day_arr[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.[折前收入（RMB）] ELSE 0 END)[d$key]";
		$day_arr_m[] = "SUM(CASE WHEN A.日期 BETWEEN '$tms' AND '$tms' THEN A.[折前收入（RMB）] ELSE 0 END)[dm$key]";
		$day_arr_y[] = "SUM(CASE WHEN A.日期 BETWEEN '$tys' AND '$tys' THEN A.[折前收入（RMB）] ELSE 0 END)[dy$key]";
		$day_arr_jl[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.票数 ELSE 0 END)[dj$key]";
	}

	$sql_arr = [];
	foreach ($where_arr as $k => $where) {
		if($condition1){
			if($k==0) $condition1 =  " WHERE B.最新片区='$pq'";
			else $condition1 =  " AND B.最新片区='$pq'";
		} 
		$sql = " SELECT 
	 	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[当日收入],
	 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[当月截止收入],
	 	SUM(CASE WHEN A.日期 BETWEEN '$last_w_f' AND '$last_w_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上周截止收入],
	   	SUM(CASE WHEN A.日期 BETWEEN '$last_m_f' AND '$last_m_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上月截止收入],
	   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_f' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[上年同月截止收入],
	   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.[折前收入（RMB）] ELSE 0 END)[年收入],
	   	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.票数 ELSE 0 END)[日票数],
	   	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.票数 ELSE 0 END)[月票数],
	   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.票数 ELSE 0 END)[年票数],
	   	{$day_arr[0]},{$day_arr[1]},{$day_arr[2]},{$day_arr[3]},{$day_arr[4]},{$day_arr[5]},
	   	{$day_arr_m[0]},{$day_arr_m[1]},{$day_arr_m[2]},{$day_arr_m[3]},{$day_arr_m[4]},{$day_arr_m[5]},
	   	SUM(CASE WHEN A.日期 BETWEEN '$last_m_d' AND '$last_m_d' THEN A.[折前收入（RMB）] ELSE 0 END)[dm6],
	   	{$day_arr_y[0]},{$day_arr_y[1]},{$day_arr_y[2]},{$day_arr_y[3]},{$day_arr_y[4]},{$day_arr_y[5]},
	   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_d' AND '$last_y_d' THEN A.[折前收入（RMB）] ELSE 0 END)[dy6],
	   	{$day_arr_jl[0]},{$day_arr_jl[1]},{$day_arr_jl[2]},{$day_arr_jl[3]},{$day_arr_jl[4]},{$day_arr_jl[5]},$k as list

	   FROM [产品日报管报].[dbo].[产品日报管报2017] A $condition  $where $condition1";
	   $sql_arr[] = $sql;
	}
 	//union 逆向排序
 	$sqls = "{$sql_arr[0]} union {$sql_arr[1]} union {$sql_arr[2]} union {$sql_arr[3]} order by list desc"; 
    // echo $sqls.'</br>';
    $result = $db_e->query($sqls);
    $rs_a = [];
    if($result){
    	while ($row=$db_e->fetch_arr($result)) 
	   	  	$rs_a[] = $row;
    }
   	return $rs_a;
}


//保价，怎么这么懒。。。
//获取保价数据
//$target,$name：对应片区和分部的 字段和名称
//$tag:0 广州区  1：片区和分部
function get_t2_baojia($t,$target=NULL,$name=NULL){
	global $db_r;
	$firstday = get_fl_day($t)[0];//月初
	$year_first =  date("Y-01-01",strtotime("$t"));//年初
	$last_w_d =  date("Y-m-d",strtotime("$t -7 day"));//上周同日
	$last_w_f =  date("Y-m-01",strtotime("$last_w_d"));//上周对应的月初
	$last_m_d = date("Y-m-d",strtotime("$t -1 month"));//上月同日
	$last_m_f = date("Y-m-01",strtotime("$last_m_d"));//上月月初
	$last_y_d = date("Y-m-d",strtotime("$t -1 year"));//上年同日
	$last_y_f = date("Y-m-01",strtotime("$last_y_d"));//上年同月月初

	$key = "[增值服务折前收入RMB]";

	$day_arr = [];
	$day_arr_m = [];$day_arr_y = [];$day_arr_jl = [];
	// $month_aver = [];//求月总收入
	// $month_aver_j = [];//求月总件量
	foreach (range(6,1) as $k => $value) {
		$ts = date("Y-m-d",strtotime("$t -$value day"));
		$tms = date("Y-m-d",strtotime("$last_m_d -$value day"));
		$tys = date("Y-m-d",strtotime("$last_y_d -$value day"));
		$day_arr[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.$key ELSE 0 END)[d$k]";
		$day_arr_m[] = "SUM(CASE WHEN A.日期 BETWEEN '$tms' AND '$tms' THEN A.$key ELSE 0 END)[dm$k]";
		$day_arr_y[] = "SUM(CASE WHEN A.日期 BETWEEN '$tys' AND '$tys' THEN A.$key ELSE 0 END)[dy$k]";
		$day_arr_jl[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.[增值服务票数] ELSE 0 END)[dj$k]";
		// $month_f = get_fl_day($ts)[0];
		// $month_aver[] = "SUM(CASE WHEN A.日期 BETWEEN '$month_f' AND '$ts' THEN A.$key ELSE 0 END)[dp$k]";
		// $month_aver_j[] = "SUM(CASE WHEN A.日期 BETWEEN '$month_f' AND '$ts' THEN A.[增值服务票数] ELSE 0 END)[dpj$k]";
	}

	$c1=$c2=$c3="";
	if($target){
		$c1 = "B.$target,A.增值服务名称,";
		$c2 = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码";
		$c3 = " and $target='$name' GROUP BY B.$target,A.增值服务名称";
	}
 	$sql = " SELECT  $c1
 	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.$key ELSE 0 END)[当日收入],
 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.$key ELSE 0 END)[当月截止收入],
 	SUM(CASE WHEN A.日期 BETWEEN '$last_w_f' AND '$last_w_d' THEN A.$key ELSE 0 END)[上周截止收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$last_m_f' AND '$last_m_d' THEN A.$key ELSE 0 END)[上月截止收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_f' AND '$last_y_d' THEN A.$key ELSE 0 END)[上年同月截止收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.$key ELSE 0 END)[年收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.[增值服务票数] ELSE 0 END)[日票数],
   	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[增值服务票数] ELSE 0 END)[月票数],
   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.[增值服务票数] ELSE 0 END)[年票数],
   	{$day_arr[0]},{$day_arr[1]},{$day_arr[2]},{$day_arr[3]},{$day_arr[4]},{$day_arr[5]},
   	{$day_arr_m[0]},{$day_arr_m[1]},{$day_arr_m[2]},{$day_arr_m[3]},{$day_arr_m[4]},{$day_arr_m[5]},
   	SUM(CASE WHEN A.日期 BETWEEN '$last_m_d' AND '$last_m_d' THEN A.$key ELSE 0 END)[dm6],
   	{$day_arr_y[0]},{$day_arr_y[1]},{$day_arr_y[2]},{$day_arr_y[3]},{$day_arr_y[4]},{$day_arr_y[5]},
   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_d' AND '$last_y_d' THEN A.$key ELSE 0 END)[dy6],
   	{$day_arr_jl[0]},{$day_arr_jl[1]},{$day_arr_jl[2]},{$day_arr_jl[3]},{$day_arr_jl[4]},{$day_arr_jl[5]}
   	
   FROM [保价日报].[dbo].[保价日报清单] A  $c2 WHERE (增值服务名称='保价' or 增值服务名称='特安服务' or 增值服务名称='特殊保价' or 增值服务名称='易碎件') $c3 ";

   // echo $sql.'</br>';
   $result = $db_r->query($sql);
   $rs = [];
   if($result){
   		if($target){
   			while ($row=$db_r->fetch_arr($result)){
   				$row[0] = $row[0];
   				$row[1] = $row[1];
   				if(!$rs) $rs = $row;
   				else{
   					$rs[2] += $row[2];//合并增值服务名称类别
   					$rs[3] += $row[3];
   					$rs[4] += $row[4];
   					$rs[5] += $row[5];
   					$rs[6] += $row[6];
					$rs[7] += $row[7];
   					$rs[8] += $row[8];
   					$rs[9] += $row[9];
   					$rs[10] += $row[10];
   				}

   			}
   			return $rs;
   		}else return $db_r->fetch_arr($result);	
   }
}

//代收服务费
function get_service($t,$target=NULL,$name=NULL){
	global $db_r;
	$firstday = get_fl_day($t)[0];//月初
	$year_first =  date("Y-01-01",strtotime("$t"));//年初
	$last_w_d =  date("Y-m-d",strtotime("$t -7 day"));//上周同日
	$last_w_f =  date("Y-m-01",strtotime("$last_w_d"));//上周对应的月初
	$last_m_d = date("Y-m-d",strtotime("$t -1 month"));//上月同日
	$last_m_f = date("Y-m-01",strtotime("$last_m_d"));//上月月初
	$last_y_d = date("Y-m-d",strtotime("$t -1 year"));//上年同日
	$last_y_f = date("Y-m-01",strtotime("$last_y_d"));//上年同月月初

	$key = "A.[实收寄付货款服务费]+A.[实收到付货款服务费]";

	$day_arr = [];
	$day_arr_m = [];$day_arr_y = [];$day_arr_jl = [];
	foreach (range(6,1) as $k => $value) {
		$ts = date("Y-m-d",strtotime("$t -$value day"));
		$tms = date("Y-m-d",strtotime("$last_m_d -$value day"));
		$tys = date("Y-m-d",strtotime("$last_y_d -$value day"));
		$day_arr[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN $key ELSE 0 END)[d$k]";
		$day_arr_m[] = "SUM(CASE WHEN A.日期 BETWEEN '$tms' AND '$tms' THEN $key ELSE 0 END)[dm$k]";
		$day_arr_y[] = "SUM(CASE WHEN A.日期 BETWEEN '$tys' AND '$tys' THEN $key ELSE 0 END)[dy$k]";
		$day_arr_jl[] = "SUM(CASE WHEN A.日期 BETWEEN '$ts' AND '$ts' THEN A.[成功票数] ELSE 0 END)[dj$k]";
	}

	$c1=$c2=$c3="";
	if($target){
		$c1 = "B.$target,";
		$c2 = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.[原寄地网点]=B.网点代码";
		$c3 = " WHERE $target='$name' GROUP BY B.$target";
	}
 	$sql = " SELECT  $c1
 	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN $key ELSE 0 END)[当日收入],
 	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN $key ELSE 0 END)[当月截止收入],
 	SUM(CASE WHEN A.日期 BETWEEN '$last_w_f' AND '$last_w_d' THEN $key ELSE 0 END)[上周截止收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$last_m_f' AND '$last_m_d' THEN $key ELSE 0 END)[上月截止收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_f' AND '$last_y_d' THEN $key ELSE 0 END)[上年同月截止收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN $key ELSE 0 END)[年收入],
   	SUM(CASE WHEN A.日期 BETWEEN '$t' AND '$t' THEN A.[成功票数] ELSE 0 END)[日票数],
   	SUM(CASE WHEN A.日期 BETWEEN '$firstday' AND '$t' THEN A.[成功票数] ELSE 0 END)[月票数],
   	SUM(CASE WHEN A.日期 BETWEEN '$year_first' AND '$t' THEN A.[成功票数] ELSE 0 END)[年票数],
   	{$day_arr[0]},{$day_arr[1]},{$day_arr[2]},{$day_arr[3]},{$day_arr[4]},{$day_arr[5]},
   	{$day_arr_m[0]},{$day_arr_m[1]},{$day_arr_m[2]},{$day_arr_m[3]},{$day_arr_m[4]},{$day_arr_m[5]},
   	SUM(CASE WHEN A.日期 BETWEEN '$last_m_d' AND '$last_m_d' THEN $key ELSE 0 END)[dm6],
   	{$day_arr_y[0]},{$day_arr_y[1]},{$day_arr_y[2]},{$day_arr_y[3]},{$day_arr_y[4]},{$day_arr_y[5]},
   	SUM(CASE WHEN A.日期 BETWEEN '$last_y_d' AND '$last_y_d' THEN $key ELSE 0 END)[dy6],
   	{$day_arr_jl[0]},{$day_arr_jl[1]},{$day_arr_jl[2]},{$day_arr_jl[3]},{$day_arr_jl[4]},{$day_arr_jl[5]}
   	
   FROM [保价日报].[dbo].[代收货款2017] A  $c2 $c3 ";

   // echo $sql.'</br>';
   $result = $db_r->query($sql);
   $rs = [];
   if($result){
   		while ($row=$db_r->fetch_arr($result)){
   			$row[0] = $row[0];
   			return $row;
   		}	
   }
}

//获取每个模块本月收入
function get_model_income($t,$pq=NULL){
	global $db_e;
	$first_day = get_fl_day($t)[0];
	$condition = '';
	if($pq!='广州区') $condition = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码 WHERE B.最新片区='$pq'";
	$sql = "select distinct A.[产品所属版块名称],SUM(CASE WHEN A.日期 BETWEEN '$first_day' AND '$t'  THEN A.票数 ELSE 0 END) 
   FROM [产品日报管报].[dbo].[产品日报管报2017] A $condition  group by A.[产品所属版块名称]";
   $result = $db_e->query($sql);
   $model_ar = [];
   if($result){
   		while ($row=$db_e->fetch_arr($result)){
   			if($row[1]){
   				$model_ar[] =[$row[0],$row[1]];
   			}
   		}
   }
   return $model_ar;
}


//只获取日的
function get_d_income($t,$target){
	global $db_e;
	$firstday = get_fl_day($t)[0];
	$year_first =  date("Y-01-01",strtotime("$t"));
	$sql = "SELECT sum(".$target.") FROM dbo.产品日报管报2017 WHERE 日期='".$t."'";
	// echo $sql.'</br>';
	$result = $db_e->query($sql);

	if($result)
		return $db_e->fetch_arr($result)[0];
}


function get_c5($time,$pq=NULL){
	global $db_e;
	$t_arr = [];
	$t_l_arr =[];
	$condition = "";
	if($pq && $pq!='020') $condition = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码 WHERE B.最新片区='$pq'";	

	foreach (range(0,10) as $value) {
		$temp_time =  date("Y-m-d",strtotime("$time -$value day"));
		$temp_last_time =  date("Y-m-d",strtotime("$temp_time -1 year"));
		$t_arr[] = "SUM(CASE WHEN A.日期 BETWEEN '$temp_time' AND '$temp_time' THEN A.[折前收入（RMB）] ELSE 0 END)[$temp_time]";
		$t_l_arr[] = "SUM(CASE WHEN A.日期 BETWEEN '$temp_last_time' AND '$temp_last_time' THEN A.[折前收入（RMB）] ELSE 0 END)[$temp_last_time]";
	}
	$sql = "SELECT {$t_arr[0]},{$t_arr[1]},{$t_arr[2]},{$t_arr[3]},{$t_arr[4]},{$t_arr[5]},{$t_arr[6]},{$t_arr[7]},{$t_arr[8]},{$t_arr[9]},{$t_arr[10]},{$t_l_arr[0]},{$t_l_arr[1]},{$t_l_arr[2]},{$t_l_arr[3]},{$t_l_arr[4]},{$t_l_arr[5]},{$t_l_arr[6]},{$t_l_arr[7]},{$t_l_arr[8]},{$t_l_arr[9]},{$t_l_arr[10]} FROM [产品日报管报].[dbo].[产品日报管报2017] A $condition";
	// echo $sql.'</br>';
	$result = $db_e->query($sql);
    if($result)
    	return $db_e->fetch_arr($result);
}

//转化数据成万
function trans($count){

	return round($count/10000,2)."万";
}

//小数转化成百分比
function trans_p($count){

	return round($count*100,2).'%';
}

//获取本月第一和最后一天
function get_fl_day($t){
	$firstday = date("Y-m-01",strtotime("$t"));
	$lastday = date("Y-m-d", strtotime("$firstday +1 month -1 day"));
	return [$firstday,$lastday];
}

//获取含本日在内的七日
function get_seven_day($t){
	$day_arr = [];
	foreach (range(6,1) as $key => $value) {
		$ts = date("Y-m-d",strtotime("$t -$value day"));
		$day_arr[] = $ts;
	}

	$day_arr[] = $t;
	return $day_arr;
}

//为空返回 -
function trimp($str){
	if($str=='%' || empty($str)){
		return '-';
	}else return $str;

}

//简单防止sql注入
function sql_trim($str){
	if(is_array($str)){
		foreach ($str as $key => $value) {
			$str[$key] =  addslashes(sprintf("%s",$value));
		}
	}
	else $str = addslashes(sprintf("%s",$str));

	return $str;
}

//xss防注入
function html_trim($str){
	return htmlspecialchars_decode(htmlEntities($str,ENT_QUOTES));
}


//月报函数 全部获取折后收入
//$db_r = new sql("","保价日报");
//$db_s = new sql("","产品月报管报");
//收入和票数一起

//获取月的目标
//$name:片区名
function get_month_targets($t,$name){
	global $db_x;

	$mt = date('Ym',strtotime("$t"));

	$sql = "SELECT * FROM dbo.it_month_report where 分部代码='$name' and 月份='$mt'";

	$result = $db_x->query($sql);

	$rs_arr = array();

	// echo $sql;
	if($result){
		while($row=$db_x->fetch_arr($result)){
			$rs = array();
			$rs[] = $row['7'];
			$rs[] = $row['8'];
			$rs[] = $row['9'];
			$rs[] = $row['10'];
			$rs[] = $row['11'];
			$rs[] = $row['12'];
			$rs[] = $row['13'];
			$rs[] = $row['14'];
			$rs[] = $row['15'];
			$rs_arr[$row['5']] = $rs;//网点代码字段名
		}
	}
	return $rs_arr;
}

//p1:月份2018-03
//p2:片区
//$tag:客户类别或者其他需要的
function get_month_t1($t,$pq=NULL,$tag=NULL){
	global $db_s;
	$mt = date('Ym',strtotime("$t"));//参数本月
	$lmt = date('Ym',strtotime("$t -1 month"));//上月
	$ymt = date('Ym',strtotime("$t -1 year"));//上年同月
	$fir_m = date('Y01',strtotime("$t"));//今年第一个月

	$condition = "";
	if($pq && $pq!='020') $condition = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码 WHERE B.最新片区='$pq'";
	$c1 = $c2 = "";
	if($tag) {
		$c1 = "A.$tag,";
		$c2 = "GROUP BY A.$tag";
	}

	$sql = "SELECT $c1
			SUM(CASE WHEN A.月份='$mt' THEN A.[折后收入（RMB）] ELSE 0 END)[本月收入],
			SUM(CASE WHEN A.月份='$lmt' THEN A.[折后收入（RMB）] ELSE 0 END)[上月收入],
			SUM(CASE WHEN A.月份='$ymt' THEN A.[折后收入（RMB）] ELSE 0 END)[上年同月收入],
			SUM(CASE WHEN A.月份='$mt' THEN A.[票数] ELSE 0 END)[本月票数],
			SUM(CASE WHEN A.月份='$lmt' THEN A.[票数] ELSE 0 END)[上月票数],
			SUM(CASE WHEN A.月份='$ymt' THEN A.[票数] ELSE 0 END)[上年同月票数],
			SUM(CASE WHEN A.月份 BETWEEN '$fir_m' AND '$mt' THEN A.[折后收入（RMB）] ELSE 0 END)[本年总收入],
			SUM(CASE WHEN A.月份 BETWEEN '$fir_m' AND '$mt' THEN A.[票数] ELSE 0 END)[本年总票数]
			FROM [产品月报管报].[dbo].[产品月报管报2017] A $condition $c2";
	// echo $sql .'</br>';
	$result = $db_s->query($sql);
	$rs = [];
    if($result){
    	while ($row=$db_s->fetch_arr($result)){
   			if($row[0]){
   				
   				$rs[] = $row;
   			}
   		}
    	return $rs;
    }
}

//获取产品的数据
function get_pro($t,$pq){
	global $db_s;

	$mt = date('Ym',strtotime("$t"));//参数本月
	$ymt = date('Ym',strtotime("$t -1 year"));//上年同月
	$fir_m = date('Y01',strtotime("$t"));//今年第一个月

	$where_arr = [''," WHERE A.客户类型='月结'"," WHERE A.客户类型='散客'"," WHERE A.产品名称='重货快运'"," WHERE (A.产品名称='物流普运' or A.产品名称='重货包裹' or A.产品名称='小票零担' or A.产品名称='专线普运')"," WHERE A.产品所属版块名称='国际'"];

	$condition = $condition1 = '';
	if($pq && $pq!='020'){
		$condition = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码 ";
		$condition1 =  " AND B.最新片区='$pq'";
	}

	$sql_arr = [];
	foreach ($where_arr as $k => $where) {
		if($condition1){
			if($k==0) $condition1 =  " WHERE B.最新片区='$pq'";
			else $condition1 =  " AND B.最新片区='$pq'";
		} 
		$sql = "SELECT $k as list,
				SUM(CASE WHEN A.月份='$mt' THEN A.[折后收入（RMB）] ELSE 0 END)[本月收入],
				SUM(CASE WHEN A.月份='$ymt' THEN A.[折后收入（RMB）] ELSE 0 END)[上年同月收入],
				nullif(cast((SUM(CASE WHEN A.月份='$mt' THEN A.[折后收入（RMB）] ELSE 0 END)/SUM(CASE WHEN A.月份='$mt' THEN A.[折前收入（RMB）] ELSE 0 END)) as numeric(10,3)),0)
				FROM [产品月报管报].[dbo].[产品月报管报2017] A $condition  $where $condition1";
		$sql_arr[] = $sql;
		// echo $sql.'</br>';
	}

	//union 逆向排序
 	$sqls = "{$sql_arr[0]} union {$sql_arr[1]} union {$sql_arr[2]} union {$sql_arr[3]} union {$sql_arr[4]} union {$sql_arr[5]} order by list"; 
    // echo $sqls.'</br>';
    $result = $db_s->query($sqls);
    $rs_a = [];
    if($result){
    	while ($row=$db_s->fetch_arr($result)) 
	   	  	$rs_a[] = $row;
    }
   	return $rs_a;
}

//月报-保价
function get_b_pro($t,$pq){
	global $db_r;

	$mt = date('Ym',strtotime("$t"));//参数本月
	$ymt = date('Ym',strtotime("$t -1 year"));//上年同月
	$fir_m = date('Y01',strtotime("$t"));//今年首月

	$condition = $condition1 = '';
	if($pq && $pq!='020'){
		$condition = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.收件网点代码=B.网点代码 ";
		$condition1 =  " AND B.最新片区='$pq'";
	}

	$sql = "SELECT 
			SUM(CASE WHEN A.月份='$mt' THEN A.[增值服务折后收入RMB] ELSE 0 END)[本月收入],
			SUM(CASE WHEN A.月份='$ymt' THEN A.[增值服务折后收入RMB] ELSE 0 END)[上年同月收入],
			nullif(cast((SUM(CASE WHEN A.月份='$mt' THEN A.[增值服务折后收入RMB] ELSE 0 END)/SUM(CASE WHEN A.月份='$mt' THEN A.[增值服务折前收入RMB] ELSE 0 END)) as numeric(10,3)),0)
			FROM [保价日报].[dbo].[保价CS_VAS月报管报] A $condition  WHERE (增值服务名称='保价' or 增值服务名称='特安服务' or 增值服务名称='特殊保价' or 增值服务名称='易碎件') $condition1";
	// echo $sql.'</br>';
	$result = $db_r->query($sql);
	if($result)
    	return  $db_r->fetch_arr($result);
}


//月报-代收服务费
function get_d_pro($t,$pq){
	global $db_r;

	$mt = date('Ym',strtotime("$t"));//参数本月
	$ymt = date('Ym',strtotime("$t -1 year"));//上年同月
	$fir_m = date('Y01',strtotime("$t"));//今年首月

	$condition = '';
	if($pq && $pq!='020'){
		$condition = "LEFT JOIN 网点代码.DBO.网点代码最新 B ON A.[原寄地网点]=B.网点代码 WHERE B.最新片区='$pq'";
	}
	$key = "A.[折前寄付货款服务费]+A.[折前到付货款服务费]";

	$sql = "SELECT 
			SUM(CASE WHEN A.月份='$mt' THEN $key ELSE 0 END)[本月收入],
			SUM(CASE WHEN A.月份='$ymt' THEN $key ELSE 0 END)[上年同月收入],
			nullif(cast((SUM(CASE WHEN A.月份='$mt' THEN A.[实际服务费] ELSE 0 END)/SUM(CASE WHEN A.月份='$mt' THEN $key ELSE 0 END)) as numeric(10,3)),0)
			FROM [保价日报].[dbo].[代收货款月报2018（含折后）] A $condition ";
	// echo $sql.'</br>';
	$result = $db_r->query($sql);
	if($result)
    	return  $db_r->fetch_arr($result);
}


