<?php
function cookie_location($url){
	if(!isset($_COOKIE['unique_id'])) 
		header("Location:".$url."?r=".rand()."&logout=1");
}

function _alert_back($info){

	echo "<script type='text/javascript'> alert('".$info."');history.back();</script>";
	exit();
}

function _location($url){

	echo "<script type='text/javascript'> location.href='".$url."';</script>";
}

function _alert($info){

	echo "<script type='text/javascript'> alert('".$info."')</script>";
}

function yurenzheng($name,$passwd){
	$ldapconn = ldap_connect("10.116.219.9");        //连接ad服务
    ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3); //设置参数
    $name_add = "sf\\" . $name;
    $bd = @ldap_bind($ldapconn, $name_add, $passwd);
    $info_arr = [];
    if($bd){
	    //获取个人信息
	    $filter = "samaccountname=$name";
	    $infos = array('sn','givenname','mail','department');
	    $result = ldap_search($ldapconn,'OU=sf-express,dc=sf,dc=com' ,$filter, $infos);  
	    $info = ldap_get_entries($ldapconn, $result);
	    $info_arr['rs'] = $bd;
	    $info_arr['cn_name'] = $info[0]['sn'][0];
	    $info_arr['en_name'] = $info[0]['givenname'][0];
	    $info_arr['mail'] = $info[0]['mail'][0];
	    $info_arr['department'] = $info[0]['department'][0];
	}

    return $info_arr;
}
